# Engly — контекст проекта (для AI-ассистента)

Telegram Mini App «английский за 5 минут»: 6 миров по уровням CEFR (A1–C2), уроки из 5 типов заданий
(перевод RU→EN, EN→RU, аудирование через Web Speech API, сборка фразы, говорение с микрофоном — можно пропустить),
стрик, XP, слово дня, разбор ошибок (1 бесплатно в день), подписка за Telegram Stars (49/89/149 ⭐ за 7/14/30 дней,
новым −20%), рефералка (+5 заданий/день обоим на неделю), напоминания о стрике.

## Стек
- Backend: Python 3.12, FastAPI, aiogram 3 (polling через SOCKS-прокси WARP — провайдер блокирует Telegram),
  SQLite (aiosqlite), python-dotenv. Порт 8002.
- Frontend: React 19 + Vite, single-file App.jsx (все экраны), theme.css, telegram-web-app.js (self-hosted,
  т.к. telegram.org заблокирован). base = '/engly/'.
- Инфра: Caddy проксирует https://домен/engly/* → 127.0.0.1:8002 (handle_path срезает префикс).
  Рядом на порту 8000 живёт другой проект (ПДД-тренажёр) — не путать.

## Структура
```
engly/
├── backend/
│   ├── .env.example          # шаблон конфига (реальный .env не включён — там токен)
│   ├── requirements.txt
│   ├── scripts/setup_bot.py  # команды бота, описание, кнопка меню «🚀 Учиться»
│   └── app/
│       ├── config.py         # Settings из .env
│       ├── content.py        # ★ ГЛАВНОЕ: 6 миров CEFR + банк 240 слов/фраз + входной тест
│       ├── db.py             # SQLite: users, daily_usage, answers_log, lesson_progress, payments, events
│       ├── auth.py           # проверка подписи Telegram initData (HMAC)
│       ├── plans.py          # тарифы 49/89/149 ⭐, скидка первым
│       ├── bot.py            # aiogram: /start, /word, оплата Stars, рефералка
│       ├── api.py            # ★ REST: placement, worlds, lesson start/answer/finish, mistakes/analysis,
│       │                     #   wordofday, profile, plans, invoice
│       └── main.py           # lifespan: polling, напоминания (слово дня 12:00, спасение стрика 20:00),
│                             #   раздача фронта, healthz
└── frontend/
    ├── package.json, vite.config.js (base '/engly/'), index.html
    └── src/
        ├── App.jsx           # ★ все экраны: Onboarding(тест), Worlds(карта), Lesson(5 типов заданий),
        │                     #   SpeakTask(микрофон), Mistakes(разбор ошибок), Paywall, Profile
        ├── api.js            # fetch с X-Init-Data; BASE = import.meta.env.BASE_URL ('/engly')
        ├── tg.js             # Telegram WebApp, haptic, speak() через speechSynthesis
        └── theme.css         # тёмная тема
```

## Ключевые решения
- Лимит: 12 бесплатных заданий/день (daily_usage), у подписчика — безлимит.
- Разбор ошибок: `free_analysis_day` в users; 1 раз/день бесплатно, дальше 402 analysis_limit → пейвол.
- Урок генерируется из банка: 6 случайных слов темы → 4 типа заданий по кругу + speak в конце.
- DEV-режим (только локально): DEV_MODE=1 + заголовок X-Dev-User, работает при hostname localhost и
  BOT_MODE=webhook (защита в main.py: polling + DEV_MODE запрещён).
- Диалог с Claude: изменения в content.py (банк слов) и App.jsx (экраны) — самые частые.

## Известные места для доработки
- Банк контента: по 8 слов на тему — расширять до 20–30.
- Лиги/дуэли по XP между друзьями — не реализовано (рефералка есть).
- AI-генерация фраз под интересы пользователя — нет (нужен API-ключ LLM).
- Говорение: запись + самопроверка, без оценки произношения (нужен speech-to-text API).

## Обновление (аудит + апгрейд) — см. AUDIT.md
- Логика вынесена в `backend/app/services.py`; новые модули: `adaptive.py` + `placement_bank.py` (адаптивный тест), `srs.py`, `lessons.py`, `gamify.py`, `locations.py`.
- Тест, уроки и локации — серверные сессии (`sessions`), клиент не знает правильных ответов. Новые таблицы: `srs_cards`, `sessions`, `achievements`, `location_progress`.
- Фронтенд разбит на `screens/*` и `components/*`; глобус — собственный Canvas (`components/Globe.jsx`, `data/world.js`).
- Тесты: `cd backend && pytest`.
