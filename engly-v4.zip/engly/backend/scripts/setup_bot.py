"""Настройка бота Engly: команды, описание, кнопка меню, вебхук (если нужен)."""
import asyncio
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aiogram import Bot  # noqa: E402
from aiogram.client.session.aiohttp import AiohttpSession  # noqa: E402
from aiogram.types import (  # noqa: E402
    BotCommand,
    MenuButtonWebApp,
    WebAppInfo,
)

from app.config import settings  # noqa: E402


async def main() -> None:
    session = AiohttpSession(proxy=settings.tg_proxy_url) if settings.tg_proxy_url else None
    bot = Bot(settings.bot_token, session=session)
    await bot.set_my_commands(
        [
            BotCommand(command="start", description="Открыть Engly — английский с нуля"),
            BotCommand(command="word", description="Слово дня"),
            BotCommand(command="paysupport", description="Поддержка по платежам"),
        ]
    )
    print("команды установлены")
    await bot.set_my_short_description(
        "Английский с нуля: слова с картинками и звуком, умные повторения, путешествия по миру. 12 заданий в день бесплатно."
    )
    await bot.set_my_description(
        # ВАЖНО: описание бота — простой текст (HTML-теги Telegram показывает как есть); лимит — 512 символов
        "🦉 Engly — английский с нуля, по одному слову\n\n"
        "• Новое слово: картинка, звук и пример — без зубрёжки\n"
        "• Короткие уроки по 3 слова, понятные новичку\n"
        "• Умные повторения: слова возвращаются, пока не запомнятся\n"
        "• 10 локаций мира: Париж, Токио, Нью-Йорк — живые диалоги\n"
        "• Серии, XP, билеты ✈️, светлая и тёмная тема\n\n"
        "Бесплатно — 12 заданий в день. Подписка снимает лимит.\n\n"
        "Нажмите «Запустить» — начнём с первого слова."
    )
    print("описание обновлено")
    if settings.webapp_url:
        await bot.set_chat_menu_button(
            menu_button=MenuButtonWebApp(text="🚀 Учиться", web_app=WebAppInfo(url=settings.webapp_url))
        )
        print(f"кнопка меню -> {settings.webapp_url}")
    if "--webhook" in sys.argv and settings.base_url:
        await bot.set_webhook(
            f"{settings.base_url}/tg/webhook",
            secret_token=settings.webhook_secret,
            drop_pending_updates=True,
        )
        print(f"вебхук -> {settings.base_url}/tg/webhook")
    me = await bot.get_me()
    print(f"бот: @{me.username}")
    await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
