"""Engly: FastAPI + aiogram (polling через WARP-прокси) + напоминания-стрики."""
import asyncio
import logging
import random
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.client.session.aiohttp import AiohttpSession
from aiogram.enums import ParseMode
from aiogram.exceptions import TelegramForbiddenError
from aiogram.utils.token import TokenValidationError
from fastapi import FastAPI, HTTPException, Request, Response
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import api
from .services import ApiError
from .bot import router as bot_router
from .config import settings
from .content import BANK, items_for, topics_for
from .db import MSK, database, ensure_db_file

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("engly.main")

bot: Bot | None = None
dp: Dispatcher | None = None
polling_task: asyncio.Task | None = None
reminder_task: asyncio.Task | None = None

FRONTEND_DIST = Path(__file__).resolve().parent.parent.parent / "frontend" / "dist"


@asynccontextmanager
async def lifespan(app: FastAPI):
    global bot, dp, polling_task, reminder_task
    ensure_db_file()
    await database.connect()
    log.info("DB ok: %s", settings.db_path)

    if settings.dev_mode and (settings.bot_mode == "polling" or not settings.dev_allowed):
        log.critical("DEV_MODE=1 вне локальной машины: dev-вход принудительно выключен (иначе любой мог бы войти под чужим id)")
        settings.dev_mode = False

    bot = None
    try:
        bot = Bot(
            settings.bot_token,
            default=DefaultBotProperties(parse_mode=ParseMode.HTML),
            session=AiohttpSession(proxy=settings.tg_proxy_url) if settings.tg_proxy_url else None,
        )
    except TokenValidationError:
        log.error("BOT_TOKEN пуст или неверного формата")

    dp = Dispatcher()
    dp.include_router(bot_router)
    api.set_bot(bot)

    try:
        if bot is None:
            pass
        elif settings.bot_mode == "polling":
            polling_task = asyncio.create_task(run_polling())
            log.info("Bot started in POLLING mode")
        elif settings.webhook_secret in ("", "change-me"):
            log.error("WEBHOOK_SECRET не задан (или остался «change-me»): вебхук не установлен. Задайте длинный случайный секрет.")
        else:
            await bot.set_webhook(
                f"{settings.base_url}/tg/webhook",
                secret_token=settings.webhook_secret,
                drop_pending_updates=True,
                request_timeout=10,
            )
            log.info("Webhook set: %s/tg/webhook", settings.base_url)
    except Exception as e:  # noqa: BLE001
        log.warning("Telegram недоступен (%s: %s). API работает без бота.", type(e).__name__, e)
        polling_task = None

    if bot is not None:
        reminder_task = asyncio.create_task(run_reminders())
        log.info("Reminders task started")

    yield

    for t in (reminder_task, polling_task):
        if t:
            t.cancel()
            try:
                await t
            except BaseException:  # noqa: BLE001
                pass
    if bot:
        await bot.session.close()
    await database.close()


async def run_polling() -> None:
    while True:
        try:
            try:
                await bot.delete_webhook(drop_pending_updates=False, request_timeout=15)
            except Exception:  # noqa: BLE001
                log.warning("delete_webhook не удался, пробуем поллить всё равно")
            await dp.start_polling(bot, handle_signals=False)
        except asyncio.CancelledError:
            return
        except Exception:
            log.exception("polling crashed, retry in 5s")
            await asyncio.sleep(5)


async def run_reminders() -> None:
    """Дважды в день:
    • ~12:00 МСК — «слово дня» активным ученикам (за последние 7 дней);
    • ~20:00 МСК — спасение стрика тем, кто сегодня не занимался.
    От дублей защищают события wordday_sent/streak_nudge с датой.
    """
    while True:
        try:
            now_msk = datetime.now(MSK)
            today = now_msk.date().isoformat()
            await database.session_cleanup()   # сессии тестов/уроков старше 3 дней не нужны

            if 11 <= now_msk.hour < 13 and bot:
                for row in await database.active_learners(7):
                    if await database.has_event_date(row["tg_id"], "wordday_sent", today) \
                            or await database.has_event(row["tg_id"], "bot_blocked"):
                        continue
                    try:
                        level = row["level"]
                        topics = topics_for(level)
                        en, ru, ph, ph_ru = random.choice(items_for(level, random.choice(topics)))
                        due = (await database.srs_stats(row["tg_id"]))["due"]
                        review = f"\n🔁 На повторение ждут слов: <b>{due}</b> — это займёт 2 минуты." if due else ""
                        await bot.send_message(
                            row["tg_id"],
                            f"📖 <b>Слово дня ({level})</b>\n\n<b>{en}</b> — {ru}\n<i>{ph}</i>\n({ph_ru})\n"
                            f"{review}\n\nПоддержи стрик 🔥{row['streak_days']} — один урок это 5 минут!",
                        )
                        await database.log_event("wordday_sent", row["tg_id"], {"day": today})
                    except TelegramForbiddenError:   # пользователь заблокировал бота — больше не пишем
                        await database.log_event("bot_blocked", row["tg_id"])
                    except Exception as e:  # noqa: BLE001
                        log.warning("wordday -> %s: %s", row["tg_id"], e)

            if 19 <= now_msk.hour < 21 and bot:
                cur = await database.db.execute(
                    "SELECT tg_id, streak_days FROM users "
                    "WHERE last_study_day = ? AND streak_days >= 2",       # серия жива только у тех, кто занимался вчера
                    ((now_msk.date() - timedelta(days=1)).isoformat(),),
                )
                for row in await cur.fetchall():
                    if await database.has_event_date(row["tg_id"], "streak_nudge", today) \
                            or await database.has_event(row["tg_id"], "bot_blocked"):
                        continue
                    try:
                        await bot.send_message(
                            row["tg_id"],
                            f"🔥 Твой стрик <b>{row['streak_days']} дн.</b> под угрозой!\n"
                            f"Успей пройти один урок до полуночи — 5 минут, и серия продолжится.",
                        )
                        await database.log_event("streak_nudge", row["tg_id"], {"day": today})
                    except TelegramForbiddenError:
                        await database.log_event("bot_blocked", row["tg_id"])
                    except Exception as e:  # noqa: BLE001
                        log.warning("nudge -> %s: %s", row["tg_id"], e)
        except Exception:
            log.exception("reminders loop failed")
        await asyncio.sleep(1800)


app = FastAPI(title="Engly", lifespan=lifespan)
app.include_router(api.router)
# напрямую на порту (без Caddy, который срезает /engly) — те же маршруты с префиксом
app.include_router(api.router, prefix="/engly")


@app.get("/healthz")
async def healthz():
    return {"ok": True, "app": "engly"}


@app.post("/tg/webhook")
async def tg_webhook(request: Request):
    import hmac as _hmac

    secret = request.headers.get("X-Telegram-Bot-Api-Secret-Token", "")
    if settings.webhook_secret in ("", "change-me") or not _hmac.compare_digest(secret.encode(), settings.webhook_secret.encode()):
        raise HTTPException(status_code=403, detail="bad secret")
    if bot is None or dp is None:
        raise HTTPException(status_code=503, detail="bot not ready")
    await dp.feed_webhook_update(bot, await request.json())
    return Response()


@app.exception_handler(ApiError)
async def api_exc(request: Request, exc: ApiError):
    return JSONResponse(status_code=exc.status, content={"error": exc.detail})


@app.exception_handler(RequestValidationError)
async def validation_exc(request: Request, exc: RequestValidationError):
    return JSONResponse(status_code=422, content={"error": "bad_request"})


@app.exception_handler(HTTPException)
async def http_exc(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"error": exc.detail})


if FRONTEND_DIST.exists():
    from fastapi.staticfiles import StaticFiles as _SF
    app.mount("/assets", _SF(directory=str(FRONTEND_DIST / "assets")), name="assets")
    app.mount("/engly/assets", _SF(directory=str(FRONTEND_DIST / "assets")), name="assets_prefixed")

    async def _index():
        return FileResponse(FRONTEND_DIST / "index.html", headers={"Cache-Control": "no-cache"})

    async def _tg_js():
        p = FRONTEND_DIST / "telegram-web-app.js"
        if p.exists():
            return FileResponse(p, media_type="application/javascript", headers={"Cache-Control": "no-cache"})
        raise HTTPException(status_code=404, detail="нет файла")

    # через Caddy префикс /engly срезается (маршруты в корне); напрямую на порту — с префиксом
    app.get("/")(_index)
    app.get("/engly")(_index)
    app.get("/engly/")(_index)
    app.get("/telegram-web-app.js")(_tg_js)
    app.get("/engly/telegram-web-app.js")(_tg_js)
else:

    @app.get("/")
    async def index():
        return {"status": "engly backend работает", "hint": "фронтенд не собран"}
