"""Путь обучения: уровни CEFR → темы (юниты) → уроки по 3 новых слова. Чистые функции без БД.

Правило: внутри текущего уровня темы идут по порядку (следующая открывается после предыдущей);
уровни ниже текущего открыты свободно (повторить), выше — закрыты. Когда пройдены все темы уровня — уровень растёт.
"""
from .content import LEVELS, WORLDS, items_for, topics_for
from .lessons import CHUNK, chunk_words, n_chunks
from .visuals import emoji_of, topic_emoji

GOAL_PRIORITY = {
    "travel": {"A1": ["Еда и напитки", "Места в городе", "Числа и цвета"], "A2": ["Транспорт", "Кафе и ресторан", "Покупки"], "B1": ["Путешествия"]},
    "work": {"A1": ["Числа и цвета", "Действия", "Места в городе"], "A2": ["Время и планы", "Покупки"], "B1": ["Работа и учёба", "Small talk"],
             "B2": ["Деловой английский", "Обсуждение и аргументы"], "C1": ["Деловая среда"]},
    "study": {"A1": ["Действия", "Числа и цвета"], "A2": ["Время и планы", "Хобби и спорт"], "B1": ["Работа и учёба"], "B2": ["Образование", "Технологии"], "C1": ["Академический стиль"]},
    "relocate": {"A1": ["Дом", "Места в городе", "Семья"], "A2": ["Семья и дом", "Покупки", "Транспорт"], "B1": ["Здоровье", "Small talk"], "C1": ["Жизнь за рубежом"]},
    "fun": {"A1": ["Животные", "Погода", "Действия"], "A2": ["Хобби и спорт", "Погода и сезоны"], "B1": ["Чувства и мнения", "Small talk"], "B2": ["Общество и медиа"], "C1": ["Идиомы и нюансы"]},
}
FIXED_A1 = ("Приветствия", "Знакомство", "Я и ты")   # база для всех: сначала здороваемся и представляемся

PASS_ACCURACY = 0.6   # ниже — урок не засчитывается в путь (повторить), чтобы не «пролетать» тему с кучей ошибок


def ordered_topics(level: str, goal: str | None) -> list[str]:
    """Порядок тем уровня: базовые темы A1 — всегда первыми, затем темы под цель пользователя, затем остальные."""
    base = list(topics_for(level))
    pri = GOAL_PRIORITY.get(goal or "", {}).get(level, [])
    fixed = [t for t in FIXED_A1 if level == "A1" and t in base]
    rest = [t for t in base if t not in fixed]
    return fixed + sorted(rest, key=lambda t: (pri.index(t) if t in pri else len(pri), base.index(t)))


def unit_lessons(level: str, topic: str) -> int:
    return n_chunks(level, topic)


def build_path(user_level: str, done: dict[tuple[str, str], int], goal: str | None = None) -> dict:
    ui = LEVELS.index(user_level) if user_level in LEVELS else 0
    levels, current = [], None
    for li, w in enumerate(WORLDS):
        units, blocked = [], False
        for topic in ordered_topics(w["id"], goal):
            total = unit_lessons(w["id"], topic)
            d = min(done.get((w["id"], topic), 0), total)
            finished = d >= total
            if li > ui:
                status = "locked"
            elif li < ui:
                status = "done" if finished else "open"
            elif finished:
                status = "done"
            elif blocked:
                status = "locked"
            else:
                status = "current"
                blocked = True
                if current is None:
                    current = {"level": w["id"], "topic": topic, "lesson": d}
            nxt = chunk_words(w["id"], topic, d) if not finished else []
            units.append({
                "topic": topic, "emoji": topic_emoji(topic), "words": len(items_for(w["id"], topic)),
                "lessons": total, "done": d, "status": status, "goal_pick": topic in GOAL_PRIORITY.get(goal or "", {}).get(w["id"], []),
                "next_words": [{"en": c["en"], "ru": c["ru"], "emoji": emoji_of(c["en"])} for c in nxt],
                "all_words": [{"en": c[0], "emoji": emoji_of(c[0])} for c in items_for(w["id"], topic)],
            })
        state = "locked" if li > ui else "current" if li == ui else "done"
        levels.append({"id": w["id"], "title": w["title"], "emoji": w["emoji"], "desc": w["desc"], "state": state,
                       "units_done": sum(1 for u in units if u["status"] == "done"), "units": units})
    return {"level": user_level, "levels": levels, "current": current}


def level_complete(level: str, done: dict[tuple[str, str], int]) -> bool:
    return all(done.get((level, t), 0) >= unit_lessons(level, t) for t in topics_for(level))


def topic_done(level: str, topic: str, done: dict[tuple[str, str], int]) -> bool:
    return done.get((level, topic), 0) >= unit_lessons(level, topic)
