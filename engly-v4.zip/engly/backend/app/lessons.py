"""Сборка уроков. Принцип «по одному слову»: новое слово → карточка-знакомство → два лёгких задания → только потом
вспоминание, правописание и фразы. Чем выше знакомство со словом (reps) и уровень, тем сложнее задания.

Типы заданий:
  intro      карточка нового слова (картинка, перевод, озвучка, пример) — без оценки
  pick_emoji «выбери картинку» (для A1: читать по-русски не нужно)
  en_ru      слово → перевод;  ru_en  перевод → слово;  listen  слышу → выбираю
  match      соедини пары (сервер проверяет каждую пару)
  type_word  собери слово из букв
  scramble   собери фразу из слов
  speak      произнеси вслух (необязательно)
Чистые функции — легко тестировать.
"""
import math
import random
import re

from .content import items_for, topics_for
from .visuals import emoji_of

PUNCT = re.compile(r"[!?,.;:\"“”]")
XP = {"intro": 0, "pick_emoji": 8, "en_ru": 8, "ru_en": 10, "listen": 10, "match": 12, "type_word": 15, "scramble": 15, "speak": 8}
CHUNK = 3                      # новых слов в одном уроке пути
LESSON_SIZE = 6                # слов в свободной практике
MAX_REVIEW_IN_PRACTICE = 3
UNSCORED = ("intro", "speak")


def norm_phrase(s: str) -> list[str]:
    return PUNCT.sub("", s).lower().split()


def topic_cards(level: str, topic: str) -> list[dict]:
    return [dict(en=a, ru=b, phrase=c, phrase_ru=d, level=level, topic=topic) for a, b, c, d in items_for(level, topic)]


def n_chunks(level: str, topic: str) -> int:
    return max(1, math.ceil(len(items_for(level, topic)) / CHUNK))


def chunk_words(level: str, topic: str, i: int) -> list[dict]:
    return topic_cards(level, topic)[i * CHUNK:(i + 1) * CHUNK]


# ------------------------------------------------------------ варианты ответов
def _field_pool(level: str, field: str, exclude: str, n: int, topic: str | None) -> list[str]:
    def collect(topics):
        seen, out = {exclude}, []
        for t in topics:
            for it in items_for(level, t):
                v = it[0] if field == "en" else it[1]
                if v not in seen:
                    seen.add(v); out.append(v)
        return out
    same = collect([topic] if topic else [])
    random.shuffle(same)
    if len(same) >= n:
        return same[:n]
    rest = [v for v in collect(topics_for(level)) if v not in same]
    random.shuffle(rest)
    return (same + rest)[:n]


def _emoji_pool(level: str, exclude: str, n: int, topic: str | None) -> list[str]:
    def collect(topics):
        seen, out = {exclude}, []
        for t in topics:
            for it in items_for(level, t):
                e = emoji_of(it[0])
                if e and e not in seen:
                    seen.add(e); out.append(e)
        return out
    same = collect([topic] if topic else [])
    random.shuffle(same)
    if len(same) >= n:
        return same[:n]
    rest = [v for v in collect(topics_for(level)) if v not in same]
    random.shuffle(rest)
    return (same + rest)[:n]


def _mix(correct: str, wrong: list[str], n: int) -> list[str]:
    opts = [correct, *wrong[:n - 1]]
    random.shuffle(opts)
    return opts


# ------------------------------------------------------------ задачи
def _can_type(card: dict) -> bool:
    w = card["en"]
    return " " not in w and 3 <= len(w) <= 9 and w.isalpha()


def make_task(card: dict, kind: str, level: str, topic: str | None = None, n: int = 3) -> dict:
    """card: {en, ru, phrase, phrase_ru}. Возвращает серверную задачу (с ответом) — клиенту уйдёт public_task()."""
    en, ru, ph, ph_ru = card["en"], card["ru"], card["phrase"], card["phrase_ru"]
    emo = emoji_of(en)
    base = {"item": en, "ru": ru, "phrase": ph, "phrase_ru": ph_ru, "level": level, "type": kind, "topic": topic or "", "emoji": emo}
    if kind == "intro":
        return {**base, "xp": XP["intro"]}
    if kind in ("pick_emoji", "listen") and emo and (kind == "pick_emoji" or level == "A1" and card.get("reps", 0) < 2 and n <= 3):
        k = max(1, min(n, 4) - 1)
        wrong = _emoji_pool(level, emo, k, topic)
        if len(wrong) >= k:
            return {**base, "type": kind, "by": "emoji", "options": _mix(emo, wrong, k + 1), "xp": XP[kind]}
    if kind == "pick_emoji":
        kind = base["type"] = "en_ru"
    if kind == "type_word":
        if not _can_type(card):
            kind = base["type"] = "ru_en"
        else:
            w = en.lower()
            extra = random.sample([c for c in "abcdefghijklmnoprstuvwy" if c not in w], 2)
            letters = list(w) + extra
            random.shuffle(letters)
            return {**base, "letters": letters, "xp": XP["type_word"]}
    if kind == "scramble":
        words = PUNCT.sub("", ph).split()
        if len(words) < 2:
            kind = base["type"] = "en_ru"
        else:
            sh = words[:]
            for _ in range(5):
                random.shuffle(sh)
                if sh != words:
                    break
            return {**base, "words": sh, "xp": XP["scramble"]}
    if kind == "ru_en":
        return {**base, "options": _mix(en, _field_pool(level, "en", en, n - 1, topic), n), "xp": XP["ru_en"]}
    # en_ru и listen: варианты — русские переводы
    return {**base, "by": "ru", "options": _mix(ru, _field_pool(level, "ru", ru, n - 1, topic), n), "xp": XP[kind if kind in XP else "en_ru"]}


def make_match(cards: list[dict], level: str) -> dict:
    left = [c["en"] for c in cards]
    right = [c["ru"] for c in cards]
    random.shuffle(left); random.shuffle(right)
    return {"type": "match", "item": cards[0]["en"], "ru": cards[0]["ru"], "phrase": cards[0]["phrase"], "phrase_ru": cards[0]["phrase_ru"],
            "level": level, "topic": cards[0].get("topic", ""), "xp": XP["match"],
            "pairs": [{"en": c["en"], "ru": c["ru"], "phrase": c["phrase"], "phrase_ru": c["phrase_ru"], "topic": c.get("topic", ""), "level": c.get("level", level)} for c in cards],
            "left": left, "right": right, "matched": [], "bad": []}


def public_task(t: dict, idx: int) -> dict:
    """Что видит клиент: никаких правильных ответов до ответа пользователя."""
    out = {"idx": idx, "type": t["type"], "review": bool(t.get("review")), "xp": t["xp"]}
    k = t["type"]
    if k == "intro":
        out.update(item=t["item"], ru=t["ru"], phrase=t["phrase"], phrase_ru=t["phrase_ru"], emoji=t.get("emoji"))
    elif k == "pick_emoji":
        out.update(item=t["item"], options=t["options"], by="emoji")
    elif k == "ru_en":
        out.update(ru=t["ru"], emoji=t.get("emoji"), options=t["options"])
    elif k == "en_ru":
        out.update(item=t["item"], phrase=t["phrase"], emoji=t.get("emoji"), options=t["options"])
    elif k == "listen":
        out.update(tts=t["item"] if t.get("by") == "emoji" else t["phrase"], options=t["options"], by=t.get("by", "ru"))
    elif k == "type_word":
        out.update(ru=t["ru"], emoji=t.get("emoji"), letters=t["letters"], length=len(t["item"]), tts=t["item"])
    elif k == "scramble":
        out.update(phrase_ru=t["phrase_ru"], words=t["words"], tts=t["phrase"])
    elif k == "match":
        out.update(left=t["left"], right=t["right"])
    elif k == "speak":
        out.update(item=t["item"], phrase=t["phrase"], phrase_ru=t["phrase_ru"], emoji=t.get("emoji"), skippable=True)
    return out


def check_answer(t: dict, answer: str) -> bool | None:
    k, a = t["type"], (answer or "").strip()
    if k == "ru_en":
        return a.lower() == t["item"].lower()
    if k in ("en_ru", "listen", "pick_emoji"):
        right = t["emoji"] if t.get("by") == "emoji" else t["ru"]
        return a.lower() == right.lower()
    if k == "type_word":
        return a.lower() == t["item"].lower()
    if k == "scramble":
        return a.lower().split() == norm_phrase(t["phrase"])
    return None   # intro, speak, match (match проверяет сервис по состоянию)


def correct_text(t: dict) -> str:
    k = t["type"]
    if k == "ru_en" or k == "type_word":
        return t["item"]
    if k == "scramble":
        return t["phrase"]
    if t.get("by") == "emoji":
        return f'{t["emoji"]} {t["item"]}'
    return t["ru"]


def correct_value(t: dict) -> str:
    """Значение правильного варианта ровно так, как оно лежит в options — клиент подсвечивает его точным сравнением
    (раньше сравнивал «хвост» строки и мог подсветить не тот вариант)."""
    if t["type"] in ("en_ru", "listen", "pick_emoji"):
        return t["emoji"] if t.get("by") == "emoji" else t["ru"]
    return correct_text(t)


def retry_task(t: dict) -> dict:
    """Повтор ошибки в конце урока: самое лёгкое задание (2 варианта) — слово уже показали в разборе."""
    card = {"en": t["item"], "ru": t["ru"], "phrase": t["phrase"], "phrase_ru": t["phrase_ru"], "reps": 0}
    return {**make_task(card, "pick_emoji" if t.get("emoji") and t["level"] == "A1" else "en_ru", t["level"], t.get("topic") or None, n=2), "retry": True}


# ------------------------------------------------------------ сборка уроков
def _review_kind(card: dict, level: str) -> str:
    reps = card.get("reps", 0)
    if reps >= 2:
        return "type_word" if (level in ("A1", "A2") and _can_type(card) and random.random() < .5) else "ru_en"
    return "listen" if random.random() < .5 else "en_ru"


def build_path_lesson(level: str, topic: str, chunk: int, due: list[dict], pool: list[dict], known_total: int) -> list[dict]:
    """Урок пути: 3 новых слова. due — просроченные карточки (до 2 в разминку), pool — знакомые для пар/добивки."""
    words = chunk_words(level, topic, chunk)
    wset = {w["en"] for w in words}
    tasks: list[dict] = []
    warm = [c for c in due if c["en"] not in wset][:2]
    for c in warm:
        t = make_task(c, _review_kind(c, c["level"]), c["level"], c.get("topic"), n=3)
        t["review"] = True
        tasks.append(t)
    beginner = level == "A1"
    for w in words:
        tasks.append(make_task(w, "intro", level, topic))
        tasks.append(make_task(w, "pick_emoji" if (beginner and emoji_of(w["en"])) else "en_ru", level, topic, n=2))
        tasks.append(make_task(w, "listen", level, topic, n=3))
    # закрепление: пары, вспоминание, правописание, фраза
    pair_cards = words + [c for c in pool if c["en"] not in wset][: max(0, 3 - len(words))]
    if len(pair_cards) >= 2:
        tasks.append(make_match(pair_cards[:4], level))
    for w in random.sample(words, len(words)):
        tasks.append(make_task(w, "ru_en", level, topic, n=3))
    typeable = sorted([w for w in words if _can_type(w)], key=lambda w: len(w["en"]))
    if typeable and level in ("A1", "A2"):
        tasks.append(make_task(typeable[0], "type_word", level, topic))
    phrase_ok = [w for w in words if 2 <= len(norm_phrase(w["phrase"])) <= (4 if beginner else 7)]
    if phrase_ok and (not beginner or known_total >= 12):
        tasks.append(make_task(phrase_ok[0], "scramble", level, topic))
    sp = words[0]
    tasks.append({**sp, "item": sp["en"], "level": level, "topic": topic, "type": "speak", "xp": XP["speak"], "emoji": emoji_of(sp["en"])})
    return tasks


def _practice_kind(i: int, card: dict, level: str) -> str:
    reps = card.get("reps", 0)
    if reps >= 2:
        order = ["ru_en", "type_word", "listen", "scramble"] if level != "A1" or reps >= 3 else ["ru_en", "type_word", "listen", "en_ru"]
    else:
        order = ["en_ru", "listen", "ru_en", "pick_emoji" if level == "A1" else "en_ru"]
    return order[i % 4]


def build_topic_lesson(level: str, topic: str, due: list[dict], known: dict[str, dict]) -> list[dict]:
    """Свободная практика темы: 6 слов, знакомые — активное вспоминание; просроченные подмешиваются."""
    topic_items = topic_cards(level, topic)
    review = [c for c in due if c["level"] == level and c["topic"] == topic][:MAX_REVIEW_IN_PRACTICE]
    review += [c for c in due if c not in review and c["level"] == level][: MAX_REVIEW_IN_PRACTICE - len(review)]
    review_keys = {c["en"] for c in review}
    fresh = [c for c in topic_items if c["en"] not in known and c["en"] not in review_keys]
    learning = [c for c in topic_items if c["en"] in known and c["en"] not in review_keys]
    random.shuffle(fresh); random.shuffle(learning)
    chosen = review + (learning + fresh)[: LESSON_SIZE - len(review)]
    random.shuffle(chosen)
    tasks = []
    for i, c in enumerate(chosen):
        c = {**c, "reps": (known.get(c["en"]) or c).get("reps", 0)}
        t = make_task(c, _practice_kind(i, c, level), level, topic)
        t["review"] = c["en"] in review_keys
        tasks.append(t)
    sp = random.choice(topic_items)
    tasks.append({**sp, "item": sp["en"], "level": level, "topic": topic, "type": "speak", "xp": XP["speak"], "emoji": emoji_of(sp["en"])})
    return tasks


def build_review_lesson(due: list[dict], size: int = 8) -> list[dict]:
    """Повторение: самые просроченные карточки из любых тем."""
    tasks = []
    for c in due[:size]:
        t = make_task(c, _review_kind(c, c["level"]), c["level"], c.get("topic"), n=3 if c.get("reps", 0) < 2 else 4)
        t["review"] = True
        tasks.append(t)
    return tasks


DRILLS = {
    "listen": ("Аудирование", lambda c: True),
    "type_word": ("Правописание", _can_type),
    "pick_emoji": ("Угадай картинку", lambda c: bool(emoji_of(c["en"]))),
    "scramble": ("Собери фразу", lambda c: 2 <= len(norm_phrase(c["phrase"])) <= 7),
    "match": ("Найди пару", lambda c: True),
    "ru_en": ("Переведи на английский", lambda c: True),
}


def build_drill(kind: str, cards: list[dict], size: int = 8) -> list[dict]:
    """Тренировка одного типа на знакомых словах. Бросает ValueError, если слов меньше трёх."""
    ok = DRILLS[kind][1]
    cards = [c for c in cards if ok(c)]
    if len(cards) < 3:
        raise ValueError("need_words")
    random.shuffle(cards)
    if kind == "match":
        rounds = [cards[i:i + 4] for i in range(0, min(len(cards), 12), 4)]
        return [make_match(r, r[0]["level"]) for r in rounds if len(r) >= 3]
    return [make_task(c, kind, c["level"], c.get("topic"), n=4) for c in cards[:size]]
