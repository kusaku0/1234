"""Тарифы Engly (звёзды, разовые платежи на период) — как в pdd-trainer."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Plan:
    id: str
    days: int
    stars: int
    title: str


PLANS: dict[str, Plan] = {
    "d7": Plan(id="d7", days=7, stars=49, title="7 дней"),
    "d14": Plan(id="d14", days=14, stars=89, title="14 дней"),
    "d30": Plan(id="d30", days=30, stars=149, title="30 дней"),
}

BEST_PLAN = "d30"
FIRST_DISCOUNT_PERCENT = 20


def first_price(stars: int) -> int:
    return stars * (100 - FIRST_DISCOUNT_PERCENT) // 100
