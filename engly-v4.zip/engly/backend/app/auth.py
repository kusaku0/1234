"""Проверка подписи initData (как в pdd-trainer) + простой лимит запросов на пользователя."""
import hashlib
import hmac
import json
import logging
import time
from collections import defaultdict, deque
from urllib.parse import parse_qsl

from fastapi import Header, HTTPException

from .config import settings
from .db import database

log = logging.getLogger("engly.auth")

RATE_LIMIT, RATE_WINDOW = 150, 60.0      # запросов на пользователя за окно (защита от скриптов/фарма)
_hits: dict[int, deque] = defaultdict(deque)


def check_rate(user_id: int, now: float | None = None) -> bool:
    now = time.monotonic() if now is None else now
    q = _hits[user_id]
    while q and q[0] <= now - RATE_WINDOW:
        q.popleft()
    if len(q) >= RATE_LIMIT:
        return False
    q.append(now)
    if len(_hits) > 50000:   # не даём словарю расти бесконечно
        for k in [k for k, v in _hits.items() if not v or v[-1] < now - RATE_WINDOW][:10000]:
            _hits.pop(k, None)
    return True


def verify_init_data(init_data: str, bot_token: str, max_age: int) -> dict | None:
    try:
        data = dict(parse_qsl(init_data, keep_blank_values=True))
    except Exception:
        return None
    received_hash = data.pop("hash", None)
    if not received_hash:
        return None
    check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calculated = hmac.new(secret_key, check_string.encode(), hashlib.sha256).hexdigest()
    # encode: не-ASCII символы в hash раньше давали 500 вместо 401
    if not hmac.compare_digest(calculated.encode(), received_hash.lower().encode()):
        return None
    try:
        auth_date = int(data.get("auth_date", "0"))
    except ValueError:   # раньше мусор в auth_date давал 500 вместо 401
        return None
    if auth_date < time.time() - max_age:
        return None
    return data


async def current_user(
    x_init_data: str | None = Header(default=None, alias="X-Init-Data"),
    x_dev_user: int | None = Header(default=None, alias="X-Dev-User"),
) -> dict:
    if settings.dev_allowed and x_dev_user:
        user = {"id": x_dev_user, "username": f"dev_{x_dev_user}"}
    else:
        user = await _verified_user(x_init_data)
    await database.ensure_user(int(user["id"]), user.get("username"))   # один раз на пользователя, а не при каждом запросе
    return user


async def _verified_user(x_init_data: str | None) -> dict:
    if not x_init_data or not settings.bot_token:
        log.warning("401 no auth: X-Init-Data=%s", bool(x_init_data))
        raise HTTPException(status_code=401, detail="no auth")
    data = verify_init_data(x_init_data, settings.bot_token, settings.auth_max_age_sec)
    if not data or "user" not in data:
        raise HTTPException(status_code=401, detail="bad signature")
    try:
        user = json.loads(data["user"])
    except (ValueError, KeyError):
        raise HTTPException(status_code=401, detail="bad user")
    if not user.get("id"):
        raise HTTPException(status_code=401, detail="no id")
    if not check_rate(int(user["id"])):
        raise HTTPException(status_code=429, detail="too_many_requests")
    return user
