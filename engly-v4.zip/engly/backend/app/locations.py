"""Локации «Глобус»: интерактивные диалоги с ветвлением сюжета.

Структура локации:
  id, city, country, place, emoji, lat, lon, level, title, goal, npc{name, emoji}, theme{a, b}, props[emoji…]
  nodes: {node_id: {"npc": en, "ru": ru, "choices": [{"en","ru","q","fb","next","react"?}]}}
      q: качество реплики (2 — отлично, 1 — приемлемо, 0 — ошибка); next: id узла или "END"
  endings: {3|2|1: (en, ru)} — финальная реплика NPC по числу звёзд
  vocab: [(en, ru, phrase_en, phrase_ru)] — ключевые фразы → в SRS-карточки пользователя
Клиент никогда не получает q/fb до выбора реплики; сервер сам ведёт прохождение (см. services.py).
"""

def _c(en, ru, q, nxt, fb="", react=None):
    d = {"en": en, "ru": ru, "q": q, "next": nxt, "fb": fb}
    if react:
        d["react"] = {"en": react[0], "ru": react[1]}
    return d


def _n(npc, ru, *choices):
    return {"npc": npc, "ru": ru, "choices": list(choices)}


LOCATIONS: list[dict] = [
    # ---------------------------------------------------------------- A1
    {
        "id": "nyc_park", "needs": ["Приветствия", "Еда и напитки"], "city": "New York", "country": "США", "place": "Центральный парк", "emoji": "🗽",
        "lat": 40.78, "lon": -73.97, "level": "A1", "title": "Кофе в Центральном парке",
        "goal": "Закажи кофе и узнай, как дойти до фонтана",
        "npc": {"name": "Emma", "emoji": "👩‍🍳"}, "theme": {"a": "#7dd3fc", "b": "#fde68a"}, "props": ["🌳", "☕", "🍂"],
        "start": "n1",
        "nodes": {
            "n1": _n("Hi! Welcome to Park Coffee. What would you like?", "Привет! Добро пожаловать в Park Coffee. Что желаете?",
                     _c("A coffee, please.", "Кофе, пожалуйста.", 2, "n2", "Идеально: коротко и вежливо."),
                     _c("I want coffee.", "Я хочу кофе.", 1, "n2", "Понятно, но звучит резко. Лучше: «A coffee, please.»", ("Sure!", "Конечно!")),
                     _c("Coffee you are.", "Кофе вы есть.", 0, "n2", "Так не говорят. Правильно: «A coffee, please.»", ("Sorry? A coffee?", "Простите? Кофе?"))),
            "n2": _n("Small or large?", "Маленький или большой?",
                     _c("Large, please.", "Большой, пожалуйста.", 2, "n3", "Верно: на вопрос с выбором называем вариант."),
                     _c("Small, thank you.", "Маленький, спасибо.", 2, "n3", "Отлично!"),
                     _c("Yes, please.", "Да, пожалуйста.", 0, "n3", "На «A or B?» не отвечают «yes» — называют вариант.", ("Hmm… small or large?", "Хм… маленький или большой?"))),
            "n3": _n("That's four dollars. Cash or card?", "С вас четыре доллара. Наличными или картой?",
                     _c("Card, please.", "Картой, пожалуйста.", 2, "n4card", "Отлично!"),
                     _c("Here you are.", "Вот, держите.", 2, "n4cash", "Так говорят, когда протягивают деньги."),
                     _c("I am four dollars.", "Я есть четыре доллара.", 0, "n4cash", "Цена не «am», а «it is»: «It is four dollars».", ("Ha! Cash, then.", "Ха! Значит, наличные."))),
            "n4card": _n("Beep! Paid. Here's your coffee. Have a nice day!", "Пик! Оплачено. Вот ваш кофе. Хорошего дня!",
                         _c("Thank you, you too!", "Спасибо, и вам!", 2, "n5", "Идеальный ответ на пожелание."),
                         _c("Thanks!", "Спасибо!", 2, "n5", "Хорошо!"),
                         _c("Goodbye coffee.", "Пока, кофе.", 0, "n5", "Ответь человеку: «Thank you, you too!»")),
            "n4cash": _n("Thanks! Here's your change and your coffee. Have a nice day!", "Спасибо! Вот ваша сдача и кофе. Хорошего дня!",
                         _c("Thank you, you too!", "Спасибо, и вам!", 2, "n5", "Идеальный ответ на пожелание."),
                         _c("Thanks!", "Спасибо!", 2, "n5", "Хорошо!"),
                         _c("Goodbye coffee.", "Пока, кофе.", 0, "n5", "Ответь человеку: «Thank you, you too!»")),
            "n5": _n("Enjoy the park! Do you need anything else?", "Наслаждайтесь парком! Вам ещё что-нибудь нужно?",
                     _c("Where is the fountain, please?", "Где фонтан, пожалуйста?", 2, "n6", "Верная конструкция: «Where is …?»"),
                     _c("Fountain where?", "Фонтан где?", 1, "n6", "Поймут, но порядок слов другой: «Where is the fountain?»", ("Oh, the fountain? Sure.", "А, фонтан? Конечно.")),
                     _c("I need a fountain.", "Мне нужен фонтан.", 0, "n6", "Ты хочешь узнать дорогу: «Where is …?»", ("A fountain? Let me help.", "Фонтан? Сейчас помогу."))),
            "n6": _n("Go straight, then turn left. It's next to the big tree.", "Идите прямо, потом налево. Это рядом с большим деревом.",
                     _c("Thank you very much!", "Большое спасибо!", 2, "END", "Отлично!"),
                     _c("Straight and left. Great, thanks!", "Прямо и налево. Отлично, спасибо!", 2, "END", "Ты повторил маршрут — так лучше запоминается!"),
                     _c("I don't understand.", "Я не понимаю.", 1, "n6b", "Честно — тоже нормально. Сейчас повторят медленнее.")),
            "n6b": _n("No problem! Straight… then left. OK?", "Без проблем! Прямо… потом налево. Понятно?",
                      _c("OK, thank you!", "Хорошо, спасибо!", 2, "END", "Теперь всё понятно!"),
                      _c("Yes, I understand now.", "Да, теперь понимаю.", 2, "END", "Отлично!")),
        },
        "endings": {3: ("You speak great English! Enjoy the fountain!", "Вы отлично говорите! Наслаждайтесь фонтаном!"),
                    2: ("Good job! Have fun in the park!", "Хорошая работа! Приятной прогулки!"),
                    1: ("Okay, see you! Practice makes perfect.", "Ладно, до встречи! Практика — путь к успеху.")},
        "vocab": [("a coffee, please", "кофе, пожалуйста", "A coffee, please.", "Кофе, пожалуйста."),
                  ("small or large", "маленький или большой", "Small or large?", "Маленький или большой?"),
                  ("cash or card", "наличные или карта", "Cash or card?", "Наличными или картой?"),
                  ("here you are", "вот, держите", "Here you are.", "Вот, держите."),
                  ("where is the", "где находится", "Where is the fountain, please?", "Где фонтан, пожалуйста?")],
    },
    # ---------------------------------------------------------------- A2
    {
        "id": "london_hotel", "needs": ["Время и планы"], "city": "London", "country": "Великобритания", "place": "Отель в Кенсингтоне", "emoji": "🎡",
        "lat": 51.50, "lon": -0.18, "level": "A2", "title": "Заселение в отель",
        "goal": "Получи ключ от номера и узнай про завтрак",
        "npc": {"name": "Oliver", "emoji": "🧑‍💼"}, "theme": {"a": "#a78bfa", "b": "#1e293b"}, "props": ["🛎️", "🧳", "☔"],
        "start": "n1",
        "nodes": {
            "n1": _n("Good evening! Welcome to the Kensington Hotel. How can I help you?", "Добрый вечер! Добро пожаловать в отель «Кенсингтон». Чем могу помочь?",
                     _c("Hello, I have a reservation under the name Petrov.", "Здравствуйте, у меня бронь на фамилию Петров.", 2, "n2res", "Безупречно!"),
                     _c("Hi. I want a room.", "Привет. Я хочу номер.", 1, "n2walk", "Можно, но резко. Вежливее: «I'd like a room, please.»", ("Of course. Do you have a reservation?", "Конечно. У вас есть бронь?")),
                     _c("Give me my key.", "Дайте мне мой ключ.", 0, "n2res", "Слишком грубо. Начни с приветствия и фамилии.", ("Could I have your name first, please?", "Можно сначала узнать вашу фамилию?"))),
            "n2res": _n("Let me check… Yes, Mr Petrov. Two nights, double room. Could I see your passport, please?", "Сейчас проверю… Да, мистер Петров. Две ночи, двухместный номер. Можно ваш паспорт?",
                        _c("Of course. Here you are.", "Конечно. Вот, пожалуйста.", 2, "n3", "Отлично!"),
                        _c("Why do you need it?", "Зачем он вам?", 1, "n3", "Допустимо, но проще и вежливее просто подать паспорт.", ("It's the law. Thank you.", "Так положено по закону. Спасибо.")),
                        _c("No, sorry.", "Нет, извините.", 0, "n3", "В отеле паспорт нужен для регистрации.", ("I'm afraid I need it to check you in.", "Боюсь, он нужен для заселения."))),
            "n2walk": _n("We have a single room for 120 pounds per night. How many nights?", "Есть одноместный номер за 120 фунтов в сутки. На сколько ночей?",
                         _c("Two nights, please.", "Две ночи, пожалуйста.", 2, "n3", "Отлично!"),
                         _c("For two night.", "На две ночь.", 1, "n3", "После two — множественное число: «two nights».", ("Two nights. Lovely.", "Две ночи. Прекрасно.")),
                         _c("I have two.", "У меня два.", 0, "n3", "Скажи, сколько ночей: «Two nights, please.»", ("Two nights, I assume?", "Две ночи, полагаю?"))),
            "n3": _n("Thank you. Your room is 304, on the third floor. Breakfast is from seven to ten.", "Спасибо. Ваш номер 304, на третьем этаже. Завтрак с семи до десяти.",
                     _c("What time is check-out?", "Во сколько выселение?", 2, "n4", "Полезный вопрос!"),
                     _c("Is breakfast included?", "Завтрак включён в стоимость?", 2, "n4b", "Отлично — именно так спрашивают."),
                     _c("Where breakfast?", "Где завтрак?", 0, "n4", "Нужен глагол: «Where is breakfast?»", ("In the restaurant, downstairs.", "В ресторане, внизу."))),
            "n4": _n("Check-out is at eleven. Would you like a wake-up call tomorrow?", "Выселение в одиннадцать. Хотите звонок-будильник на утро?",
                     _c("Yes, at seven, please.", "Да, в семь, пожалуйста.", 2, "END", "Отлично!"),
                     _c("No, thank you. I have an alarm.", "Нет, спасибо. У меня есть будильник.", 2, "END", "Вежливый отказ."),
                     _c("Yes. Seven.", "Да. Семь.", 1, "END", "Понятно, но лучше полным предложением и с «please».")),
            "n4b": _n("Yes, it's included. Check-out is at eleven. Would you like a wake-up call?", "Да, включён. Выселение в одиннадцать. Хотите звонок-будильник?",
                      _c("Yes, at seven, please.", "Да, в семь, пожалуйста.", 2, "END", "Отлично!"),
                      _c("No, thank you. I have an alarm.", "Нет, спасибо. У меня есть будильник.", 2, "END", "Вежливый отказ."),
                      _c("Yes. Seven.", "Да. Семь.", 1, "END", "Понятно, но лучше полным предложением и с «please».")),
        },
        "endings": {3: ("Perfect. Enjoy your stay, Mr Petrov!", "Превосходно. Приятного пребывания, мистер Петров!"),
                    2: ("Here is your key. Enjoy your stay!", "Вот ваш ключ. Приятного пребывания!"),
                    1: ("Here is your key. Let me know if you need anything.", "Вот ваш ключ. Обращайтесь, если что-то понадобится.")},
        "vocab": [("reservation", "бронь", "I have a reservation.", "У меня есть бронь."),
                  ("check-out", "выселение", "What time is check-out?", "Во сколько выселение?"),
                  ("double room", "двухместный номер", "A double room for two nights.", "Двухместный номер на две ночи."),
                  ("wake-up call", "звонок-будильник", "A wake-up call at seven, please.", "Звонок-будильник в семь, пожалуйста."),
                  ("included", "включено", "Is breakfast included?", "Завтрак включён?")],
    },
    # ---------------------------------------------------------------- B1
    {
        "id": "sydney_bistro", "city": "Sydney", "country": "Австралия", "place": "Ресторан у гавани", "emoji": "🦘",
        "lat": -33.86, "lon": 151.21, "level": "B1", "title": "Ужин в Сиднее",
        "goal": "Закажи еду с учётом аллергии и оплати счёт",
        "npc": {"name": "Jack", "emoji": "🧑‍🍳"}, "theme": {"a": "#fb923c", "b": "#7c3aed"}, "props": ["🌉", "🍽️", "🌅"],
        "start": "n1",
        "nodes": {
            "n1": _n("Hi, welcome to Harbour Bistro! Table for how many?", "Привет, добро пожаловать в Harbour Bistro! Столик на сколько человек?",
                     _c("A table for two, please.", "Столик на двоих, пожалуйста.", 2, "n2", "Идеально."),
                     _c("We are two persons.", "Мы есть две персоны.", 1, "n2", "Естественнее: «Table for two, please.»", ("Right this way!", "Прошу за мной!")),
                     _c("I am hungry two.", "Я голодный два.", 0, "n2", "Скажи: «A table for two, please.»", ("Two guests? Right this way!", "Двое гостей? Прошу за мной!"))),
            "n2": _n("Here are your menus. Can I get you something to drink while you decide?", "Вот меню. Принести вам что-нибудь выпить, пока выбираете?",
                     _c("Just tap water for me, please. And a lemonade for my friend.", "Мне просто воды из-под крана. А другу лимонад.", 2, "n3", "Отлично: чётко и вежливо."),
                     _c("Do you have any local wines you'd recommend?", "Есть ли местные вина, которые вы посоветуете?", 2, "n2w", "Вопрос в стиле носителя!"),
                     _c("Bring drinks.", "Несите напитки.", 0, "n3", "Слишком прямолинейно: «Could we have …, please?»", ("Sure. Water for the table?", "Конечно. Воды на стол?"))),
            "n2w": _n("Our Hunter Valley white is very popular. Shall I bring a glass?", "Наше белое из долины Хантер очень популярно. Принести бокал?",
                      _c("Yes, a glass of that sounds great.", "Да, бокал звучит отлично.", 2, "n3", "Отлично!"),
                      _c("Actually, I'll stick with water, thanks.", "Пожалуй, останусь на воде, спасибо.", 2, "n3", "Вежливый отказ."),
                      _c("Is it dry or sweet?", "Оно сухое или сладкое?", 2, "n3", "Хороший уточняющий вопрос!", ("Dry and crisp — very refreshing.", "Сухое и свежее — очень освежает."))),
            "n3": _n("Are you ready to order? And are there any allergies I should know about?", "Готовы заказать? И есть ли аллергии, о которых мне нужно знать?",
                     _c("I'm allergic to nuts, so could you check the salad?", "У меня аллергия на орехи, не могли бы вы проверить салат?", 2, "n4a", "Очень важная и точная фраза!"),
                     _c("No allergies. I'll have the grilled fish, please.", "Аллергий нет. Я возьму рыбу гриль.", 2, "n4b", "Отлично."),
                     _c("I am allergy nuts.", "Я есть аллергия орехи.", 0, "n4a", "Верно: «I'm allergic to nuts».", ("Nuts — got it. Let me help you.", "Орехи — понял. Сейчас помогу."))),
            "n4a": _n("Good that you told me! The salad has walnuts, so I'd suggest the grilled barramundi. How does that sound?", "Хорошо, что сказали! В салате грецкие орехи, так что советую барамунди на гриле. Как вам?",
                      _c("That sounds perfect, I'll take it.", "Звучит отлично, беру.", 2, "n5", "Отлично!"),
                      _c("Is it spicy? I don't like spicy food.", "Оно острое? Я не люблю острое.", 2, "n5", "Полезный вопрос.", ("Not at all — it's very mild.", "Совсем нет — очень мягкое.")),
                      _c("No. Other.", "Нет. Другое.", 0, "n5", "Вежливее: «Do you have anything else?»", ("Of course, let me find something else.", "Конечно, подберу что-нибудь ещё."))),
            "n4b": _n("Excellent choice. How would you like your side — chips or salad?", "Отличный выбор. Какой гарнир — картофель фри или салат?",
                      _c("Salad, please.", "Салат, пожалуйста.", 2, "n5", "Отлично!"),
                      _c("I'd prefer chips, if that's okay.", "Я бы предпочёл фри, если можно.", 2, "n5", "Очень вежливо!"),
                      _c("Chips salad.", "Фри салат.", 0, "n5", "Выбери один: «Chips, please.»", ("Which one — chips or salad?", "Что именно — фри или салат?"))),
            "n5": _n("How was everything?", "Как всё было?",
                     _c("Delicious, thank you! Could we have the bill, please?", "Очень вкусно, спасибо! Можно счёт?", 2, "n6", "Идеально."),
                     _c("It was fine. The bill, please.", "Нормально. Счёт, пожалуйста.", 1, "n6", "Нормально, но добавь «Could we have…»"),
                     _c("Bill.", "Счёт.", 0, "n6", "Одно слово звучит грубо: «Could we have the bill, please?»")),
            "n6": _n("Of course. Would you like to pay together or separately?", "Конечно. Вы будете платить вместе или раздельно?",
                     _c("Separately, please.", "Раздельно, пожалуйста.", 2, "END", "Отлично!"),
                     _c("Together, I'll get this one.", "Вместе, я заплачу за всех.", 2, "END", "Приятный жест!"),
                     _c("We pay… together separately.", "Мы платим… вместе раздельно.", 0, "END", "Выбери одно: «together» или «separately».")),
        },
        "endings": {3: ("What a lovely evening! Come back soon, mate!", "Какой чудесный вечер! Приходите ещё, приятель!"),
                    2: ("Thanks for dining with us. See you!", "Спасибо, что были у нас. До встречи!"),
                    1: ("Thanks. Hope you enjoyed it — see you next time.", "Спасибо. Надеюсь, вам понравилось — до следующего раза.")},
        "vocab": [("allergic to", "аллергия на", "I'm allergic to nuts.", "У меня аллергия на орехи."),
                  ("to recommend", "рекомендовать", "What would you recommend?", "Что бы вы порекомендовали?"),
                  ("the bill", "счёт", "Could we have the bill, please?", "Можно счёт, пожалуйста?"),
                  ("separately", "раздельно", "We'd like to pay separately.", "Мы хотели бы платить раздельно."),
                  ("grilled", "на гриле", "I'll have the grilled fish.", "Я возьму рыбу на гриле.")],
    },
    # ---------------------------------------------------------------- B2
    {
        "id": "sf_interview", "city": "San Francisco", "country": "США", "place": "Офис стартапа", "emoji": "🌁",
        "lat": 37.77, "lon": -122.42, "level": "B2", "title": "Собеседование в стартапе",
        "goal": "Пройди интервью на позицию продуктового дизайнера",
        "npc": {"name": "Dana", "emoji": "👩‍💻"}, "theme": {"a": "#34d399", "b": "#0f172a"}, "props": ["💻", "📈", "☕"],
        "start": "n1",
        "nodes": {
            "n1": _n("Thanks for coming in. Please, have a seat. So, tell me a little about yourself.", "Спасибо, что пришли. Присаживайтесь. Расскажите немного о себе.",
                     _c("Thank you for having me. I'm a product designer with five years of experience, mostly in fintech.", "Спасибо за приглашение. Я продуктовый дизайнер с пятилетним опытом, в основном в финтехе.", 2, "n2", "Структурно и по делу."),
                     _c("I am a designer. I worked many years.", "Я дизайнер. Я работал много лет.", 1, "n2", "Слишком общо: добавь цифры и сферу.", ("Could you be a bit more specific?", "Можете конкретнее?")),
                     _c("Well, what do you want to know?", "Ну, что вы хотите узнать?", 0, "n2", "Лучше сразу кратко представиться.", ("Let's start with your background.", "Давайте начнём с вашего опыта."))),
            "n2": _n("Why do you want to work for our company?", "Почему вы хотите работать в нашей компании?",
                     _c("I admire how you put users first, and I'd like to contribute to that mission.", "Я восхищаюсь тем, что вы ставите пользователей на первое место, и хочу вложиться в эту миссию.", 2, "n3", "Сильный ответ."),
                     _c("I've been following your growth, and your approach to accessibility really stands out.", "Я слежу за вашим ростом, и ваш подход к доступности действительно выделяется.", 2, "n3", "Конкретика впечатляет."),
                     _c("Because the salary is high.", "Потому что зарплата высокая.", 0, "n2p", "Зарплата — не лучший первый аргумент.")),
            "n2p": _n("Okay… but beyond the salary, what excites you about the work itself?", "Хорошо… но кроме зарплаты, что вас привлекает в самой работе?",
                      _c("Fair point. Honestly, the chance to work on products that reach millions of people excites me.", "Справедливо. Честно, меня привлекает шанс работать над продуктами для миллионов людей.", 2, "n3", "Хорошо исправились!"),
                      _c("Nothing else, really.", "Больше ничего, если честно.", 0, "n3", "Это закрывает дверь.", ("I see. Let's move on.", "Понятно. Двигаемся дальше."))),
            "n3": _n("Can you describe a time you faced a major challenge at work, and how you handled it?", "Опишите случай, когда вы столкнулись с серьёзной трудностью на работе, и как вы справились.",
                     _c("Last year our launch was delayed. I reorganised priorities, communicated openly with the team, and we shipped two weeks later.", "В прошлом году запуск задержался. Я перестроил приоритеты, открыто говорил с командой, и мы выпустили продукт на две недели позже.", 2, "n4", "Метод STAR: ситуация, действия, результат."),
                     _c("We had a delay, but it was fine.", "У нас была задержка, но всё было нормально.", 1, "n4", "Не хватает ваших действий и результата."),
                     _c("I never have challenges.", "У меня никогда не бывает трудностей.", 0, "n4", "Звучит неискренне.", ("Everyone does, though. Let's continue.", "Они бывают у всех. Продолжим."))),
            "n4": _n("What would you say is your biggest weakness?", "Что вы назвали бы своей главной слабостью?",
                     _c("I tend to take on too much, so I've started using a weekly planning routine to prioritise.", "Я склонен брать слишком много, поэтому начал еженедельно планировать и расставлять приоритеты.", 2, "n5", "Слабость + решение."),
                     _c("I work too hard. That's my only weakness.", "Я слишком много работаю. Это моя единственная слабость.", 1, "n5", "Шаблонный ответ, интервьюеры его не любят."),
                     _c("I don't have any.", "У меня их нет.", 0, "n5", "Это признак отсутствия самокритики.")),
            "n5": _n("Great. Do you have any questions for me?", "Отлично. У вас есть вопросы ко мне?",
                     _c("Yes — what does success look like in this role during the first six months?", "Да — как выглядит успех на этой позиции в первые полгода?", 2, "END", "Вопрос, который запоминается."),
                     _c("How much vacation do I get?", "Сколько будет отпуска?", 1, "END", "Не лучший первый вопрос."),
                     _c("No questions.", "Вопросов нет.", 0, "END", "Всегда имеет смысл задать хотя бы один вопрос.")),
        },
        "endings": {3: ("That was impressive. We'll be in touch very soon!", "Впечатляюще. Мы свяжемся с вами очень скоро!"),
                    2: ("Thanks for your time. We'll be in touch.", "Спасибо за время. Мы свяжемся с вами."),
                    1: ("Thank you for coming. We'll let you know.", "Спасибо, что пришли. Мы сообщим о решении.")},
        "vocab": [("to contribute to", "вносить вклад в", "I'd like to contribute to your mission.", "Я хочу внести вклад в вашу миссию."),
                  ("a challenge", "сложная задача", "Describe a challenge you faced.", "Опишите сложную задачу, с которой вы столкнулись."),
                  ("to prioritise", "расставлять приоритеты", "I prioritise my tasks every week.", "Я расставляю приоритеты каждую неделю."),
                  ("a weakness", "слабая сторона", "What is your biggest weakness?", "Какая у вас главная слабость?"),
                  ("what does success look like", "как выглядит успех", "What does success look like here?", "Как выглядит успех на этой позиции?")],
    },
    # ---------------------------------------------------------------- C1
    {
        "id": "singapore_deal", "city": "Singapore", "country": "Сингапур", "place": "Переговорная в Marina Bay", "emoji": "🦁",
        "lat": 1.28, "lon": 103.86, "level": "C1", "title": "Переговоры о контракте",
        "goal": "Добейся скидки за долгосрочный контракт, не уступив слишком много",
        "npc": {"name": "Ms Tan", "emoji": "👩‍💼"}, "theme": {"a": "#f472b6", "b": "#0b1220"}, "props": ["🏙️", "📑", "🌃"],
        "start": "n1",
        "nodes": {
            "n1": _n("Thank you for flying in. Shall we get straight to the point? Your proposal is, frankly, above our budget.", "Спасибо, что прилетели. Перейдём к сути? Ваше предложение, откровенно говоря, превышает наш бюджет.",
                     _c("I appreciate your candour. Perhaps we could walk through where the gap lies?", "Ценю вашу откровенность. Может, разберём, где именно разрыв?", 2, "n2", "Дипломатично и конструктивно."),
                     _c("I understand your concern. Let's see what we can do.", "Понимаю ваши опасения. Посмотрим, что можно сделать.", 1, "n2", "Мягко, но слишком расплывчато."),
                     _c("Our price is fair. Take it or leave it.", "Наша цена справедлива. Берите или нет.", 0, "n2", "Ультиматум сразу закрывает переговоры.", ("I'd rather not be pressured.", "Я бы не хотела, чтобы на меня давили."))),
            "n2": _n("We'd need a fifteen percent reduction to proceed.", "Нам нужно снижение на пятнадцать процентов, чтобы двигаться дальше.",
                     _c("A cut of that size would compromise quality. However, I could offer a volume-based discount if you extend the contract.", "Такое снижение скажется на качестве. Но я могу предложить скидку за объём, если вы продлите контракт.", 2, "n3", "Уступка в обмен на условие."),
                     _c("Fifteen percent is out of the question.", "Пятнадцать процентов — исключено.", 1, "n3", "Отказ без альтернативы."),
                     _c("Fine, fifteen percent.", "Хорошо, пятнадцать процентов.", 0, "n3", "Согласие без встречных условий — ошибка.", ("That was easy. Thank you.", "Как легко. Спасибо."))),
            "n3": _n("A longer contract is interesting, but we have concerns about delivery timelines.", "Более длинный контракт интересен, но нас беспокоят сроки поставки.",
                     _c("That's a fair point. We could include a penalty clause for delays, which would put your mind at ease.", "Справедливо. Мы можем добавить штраф за задержки, это вас успокоит.", 2, "n4", "Снимает риск для партнёра."),
                     _c("Our delivery has never been an issue.", "С поставками у нас никогда не было проблем.", 1, "n4", "Защищаетесь, а не решаете проблему."),
                     _c("Then maybe we shouldn't continue.", "Тогда, возможно, не стоит продолжать.", 0, "n4", "Слишком резко.", ("Let's not be hasty.", "Не будем спешить."))),
            "n4": _n("That's reassuring. What would the discount look like on a three-year term?", "Это обнадёживает. Как будет выглядеть скидка при трёхлетнем сроке?",
                     _c("Eight percent, provided the volume commitment is met in the first year.", "Восемь процентов при условии выполнения объёма в первый год.", 2, "n5", "Конкретно и с условием."),
                     _c("Around eight to ten percent, subject to final terms.", "Примерно от восьми до десяти процентов, с учётом окончательных условий.", 1, "n5", "Вилка размывает позицию."),
                     _c("Maybe some percent, I don't know yet.", "Может, какой-то процент, пока не знаю.", 0, "n5", "Нужны цифры.", ("Hmm. I need a number.", "Хм. Мне нужна цифра."))),
            "n5": _n("Eight is lower than I hoped, but we may have common ground. Shall we draft the terms?", "Восемь меньше, чем я надеялась, но, возможно, мы найдём общий язык. Составим условия?",
                     _c("Absolutely. I'll have our legal team circulate a draft by Friday.", "Конечно. Наша юридическая команда пришлёт проект к пятнице.", 2, "END", "Чёткие следующие шаги."),
                     _c("Yes, but I'll need to run it by my director first.", "Да, но сначала мне нужно согласовать с директором.", 1, "END", "Приемлемо, но звучит неуверенно."),
                     _c("Let's just sign now.", "Давайте просто подпишем сейчас.", 0, "END", "Подписывать без юристов рискованно.")),
        },
        "endings": {3: ("A pleasure doing business with you. Let's make it official.", "Приятно иметь с вами дело. Оформим всё официально."),
                    2: ("Good. Let's see what the lawyers say.", "Хорошо. Посмотрим, что скажут юристы."),
                    1: ("We'll consider it and get back to you.", "Мы рассмотрим и вернёмся к вам.")},
        "vocab": [("candour", "откровенность", "I appreciate your candour.", "Ценю вашу откровенность."),
                  ("to compromise", "ставить под угрозу; идти на компромисс", "That would compromise quality.", "Это поставит под угрозу качество."),
                  ("a penalty clause", "штрафная оговорка", "We could add a penalty clause.", "Мы можем добавить штрафную оговорку."),
                  ("subject to", "при условии, с учётом", "The price is subject to final terms.", "Цена зависит от окончательных условий."),
                  ("common ground", "общая позиция", "I think we have common ground.", "Думаю, у нас есть общая позиция.")],
    },
    # ---------------------------------------------------------------- новые локации
    {
        "id": "paris_bakery", "needs": ["Приветствия", "Числа и цвета"], "city": "Paris", "country": "Франция", "place": "Булочная на Монмартре", "emoji": "🥐",
        "lat": 48.86, "lon": 2.34, "level": "A1", "title": "Круассан в Париже",
        "goal": "Закажи выпечку и расплатись",
        "npc": {"name": "Lucie", "emoji": "👩‍🍳"}, "theme": {"a": "#fbcfe8", "b": "#fcd34d"}, "props": ["🥐", "🥖", "🧁"],
        "start": "n1",
        "nodes": {
            "n1": _n("Hello! Welcome! What would you like?", "Здравствуйте! Добро пожаловать! Что желаете?",
                     _c("A croissant, please.", "Круассан, пожалуйста.", 2, "n2", "Идеально: коротко и вежливо."),
                     _c("Hello! One croissant, please.", "Здравствуйте! Один круассан, пожалуйста.", 2, "n2", "Отлично: поздоровался и заказал."),
                     _c("Me croissant.", "Я круассан.", 0, "n2", "Правильно: «A croissant, please.»", ("A croissant? Yes!", "Круассан? Да!"))),
            "n2": _n("One croissant. Anything else?", "Один круассан. Что-нибудь ещё?",
                     _c("A baguette, please.", "Багет, пожалуйста.", 2, "n3", "Отлично!"),
                     _c("No, thank you.", "Нет, спасибо.", 2, "n3", "Вежливый отказ."),
                     _c("I am baguette.", "Я есть багет.", 0, "n3", "«I am» — «я есть». Для заказа: «A baguette, please.»", ("Ha! A baguette?", "Ха! Багет?"))),
            "n3": _n("That is three euros.", "С вас три евро.",
                     _c("Here you are.", "Вот, держите.", 2, "n4", "Так говорят, когда протягивают деньги."),
                     _c("Sorry, how much?", "Простите, сколько?", 1, "n3b", "Вопрос уместен, но цена уже названа: «three euros».")),
            "n3b": _n("Three euros. Three!", "Три евро. Три!",
                      _c("OK, here you are.", "Хорошо, вот, держите.", 2, "n4", "Отлично!"),
                      _c("Thank you.", "Спасибо.", 1, "n4", "Вежливо, но сначала отдай деньги: «Here you are.»")),
            "n4": _n("Thank you! Have a nice day!", "Спасибо! Хорошего дня!",
                     _c("Thank you, goodbye!", "Спасибо, до свидания!", 2, "END", "Отлично!"),
                     _c("You too! Goodbye!", "И вам! До свидания!", 2, "END", "Идеальный ответ на пожелание."),
                     _c("Hello.", "Здравствуйте.", 0, "END", "Прощаемся: «Goodbye!»")),
        },
        "endings": {3: ("Merci! Your English is lovely!", "Спасибо! У тебя прекрасный английский!"),
                    2: ("Good job! See you tomorrow!", "Молодец! До завтра!"),
                    1: ("Nice try! Come back soon.", "Хорошая попытка! Заходи ещё.")},
        "vocab": [("croissant", "круассан", "A croissant, please.", "Круассан, пожалуйста."),
                  ("baguette", "багет", "One baguette, please.", "Один багет, пожалуйста."),
                  ("how much", "сколько", "How much is it?", "Сколько это стоит?"),
                  ("here you are", "вот, держите", "Here you are.", "Вот, держите."),
                  ("have a nice day", "хорошего дня", "Have a nice day!", "Хорошего дня!")],
    },
    {
        "id": "rio_beach", "needs": ["Знакомство", "Я и ты"], "city": "Rio de Janeiro", "country": "Бразилия", "place": "Пляж Копакабана", "emoji": "🏖️",
        "lat": -22.97, "lon": -43.18, "level": "A1", "title": "Знакомство на пляже",
        "goal": "Представься и расскажи о себе",
        "npc": {"name": "Carlos", "emoji": "🧑‍🎤"}, "theme": {"a": "#67e8f9", "b": "#fde047"}, "props": ["🏖️", "🌴", "🍹"],
        "start": "n1",
        "nodes": {
            "n1": _n("Hi! I am Carlos. What is your name?", "Привет! Я Карлос. Как тебя зовут?",
                     _c("My name is Alex.", "Меня зовут Алекс.", 2, "n2", "Идеально!"),
                     _c("I am Alex.", "Я Алекс.", 2, "n2", "Тоже правильно!"),
                     _c("Alex name.", "Алекс имя.", 0, "n2", "Порядок слов: «My name is Alex.»", ("Alex? Nice!", "Алекс? Здорово!"))),
            "n2": _n("Nice to meet you! Where are you from?", "Приятно познакомиться! Откуда ты?",
                     _c("I am from Russia.", "Я из России.", 2, "n3", "Верная конструкция: «I am from …»"),
                     _c("Nice to meet you! I am from Russia.", "Приятно познакомиться! Я из России.", 2, "n3", "Вежливо и по делу!"),
                     _c("Russia from I.", "Россия из я.", 0, "n3", "Порядок слов: «I am from Russia.»", ("Sorry?", "Простите?"))),
            "n3": _n("Cool! How old are you?", "Круто! Сколько тебе лет?",
                     _c("I am twenty-five years old.", "Мне двадцать пять лет.", 2, "n4", "Отлично!"),
                     _c("I am twenty-five.", "Мне двадцать пять.", 2, "n4", "Так говорят чаще всего."),
                     _c("I have twenty-five.", "Я имею двадцать пять.", 0, "n4", "В английском возраст — «I am 25», не «I have».", ("You have…? Ah, you are 25!", "Ты… а, тебе 25!"))),
            "n4": _n("Are you thirsty? Water or juice?", "Хочешь пить? Воды или сока?",
                     _c("Water, please.", "Воды, пожалуйста.", 2, "n5", "Отлично!"),
                     _c("Juice, please.", "Сока, пожалуйста.", 2, "n5", "Отлично!"),
                     _c("Yes.", "Да.", 0, "n5", "На вопрос «A or B?» называем вариант.", ("Water or juice?", "Воды или сока?"))),
            "n5": _n("Here you go! Enjoy the beach!", "Держи! Наслаждайся пляжем!",
                     _c("Thank you, Carlos!", "Спасибо, Карлос!", 2, "END", "Отлично!"),
                     _c("Thanks! See you!", "Спасибо! Увидимся!", 2, "END", "Отлично!"),
                     _c("Bye water.", "Пока вода.", 0, "END", "Ответь человеку: «Thank you!»")),
        },
        "endings": {3: ("You are so friendly! See you on the beach!", "Ты такой дружелюбный! Увидимся на пляже!"),
                    2: ("Nice chat! Come again.", "Приятно поболтали! Приходи ещё."),
                    1: ("Good start! Let's practice more.", "Хорошее начало! Потренируемся ещё.")},
        "vocab": [("my name is", "меня зовут", "My name is Alex.", "Меня зовут Алекс."),
                  ("I am from", "я из", "I am from Russia.", "Я из России."),
                  ("how old are you", "сколько тебе лет", "How old are you?", "Сколько тебе лет?"),
                  ("nice to meet you", "приятно познакомиться", "Nice to meet you!", "Приятно познакомиться!"),
                  ("enjoy", "наслаждаться", "Enjoy the beach!", "Наслаждайся пляжем!")],
    },
    {
        "id": "tokyo_station", "needs": ["Транспорт"], "city": "Tokyo", "country": "Япония", "place": "Станция Синдзюку", "emoji": "🚅",
        "lat": 35.69, "lon": 139.70, "level": "A2", "title": "Билет на поезд",
        "goal": "Купи билет и узнай, где платформа",
        "npc": {"name": "Yuki", "emoji": "👩‍💼"}, "theme": {"a": "#f9a8d4", "b": "#a5b4fc"}, "props": ["🚅", "🌸", "🏯"],
        "start": "n1",
        "nodes": {
            "n1": _n("Hello! Can I help you?", "Здравствуйте! Вам помочь?",
                     _c("Yes, please. I need a ticket to Kyoto.", "Да, пожалуйста. Мне нужен билет до Киото.", 2, "n2", "Отлично: вежливо и понятно."),
                     _c("Ticket Kyoto.", "Билет Киото.", 1, "n2", "Поймут, но вежливее: «I need a ticket to Kyoto, please.»", ("Kyoto? OK.", "Киото? Хорошо.")),
                     _c("I want to buy a train.", "Я хочу купить поезд.", 0, "n2", "«Buy a train» — купить сам поезд! Нужен билет: «a ticket».", ("A train? Haha, a ticket!", "Поезд? Ха-ха, билет!"))),
            "n2": _n("One way or return?", "В одну сторону или туда-обратно?",
                     _c("Return, please.", "Туда-обратно, пожалуйста.", 2, "n3", "Отлично!"),
                     _c("One way, please.", "В одну сторону, пожалуйста.", 2, "n3", "Отлично!"),
                     _c("Yes, one.", "Да, один.", 0, "n3", "На «A or B?» называем вариант.", ("Hmm, one way or return?", "Хм, в одну сторону или туда-обратно?"))),
            "n3": _n("That is 14,000 yen. The train leaves at 10:30.", "С вас 14 000 иен. Поезд отправляется в 10:30.",
                     _c("Thank you. Which platform, please?", "Спасибо. Какая платформа?", 2, "n4", "Отличный вопрос!"),
                     _c("Thank you! Where is the platform?", "Спасибо! Где платформа?", 2, "n4", "Отлично!"),
                     _c("Where I go?", "Где я иду?", 0, "n4", "Лучше: «Where is the platform?»", ("Sorry?", "Простите?"))),
            "n4": _n("Platform five. Go up the stairs and turn right.", "Платформа пять. Поднимитесь по лестнице и поверните направо.",
                     _c("Thank you very much!", "Большое спасибо!", 2, "n5", "Отлично!"),
                     _c("Up the stairs, then right. Got it!", "Вверх по лестнице, потом направо. Понял!", 2, "n5", "Повторил маршрут — супер!"),
                     _c("I don't know.", "Я не знаю.", 0, "n5", "Ответь вежливо: «Thank you!»")),
            "n5": _n("Have a nice trip!", "Счастливого пути!",
                     _c("Thank you! Goodbye!", "Спасибо! До свидания!", 2, "END", "Отлично!"),
                     _c("Thanks, you too!", "Спасибо, и вам!", 1, "END", "«You too» — ответ на «Have a nice day»; здесь достаточно «Thank you!»"),
                     _c("See you.", "Увидимся.", 1, "END", "Для кассира лучше «Thank you! Goodbye!»")),
        },
        "endings": {3: ("Arigato! You are ready for Japan!", "Спасибо! Ты готов к Японии!"),
                    2: ("Good job! Safe travels!", "Хорошая работа! Счастливого пути!"),
                    1: ("You made it to the train. Well done!", "Ты успел на поезд. Молодец!")},
        "vocab": [("return ticket", "билет туда-обратно", "A return ticket, please.", "Билет туда-обратно, пожалуйста."),
                  ("one way", "в одну сторону", "One way, please.", "В одну сторону, пожалуйста."),
                  ("platform", "платформа", "Which platform, please?", "Какая платформа?"),
                  ("turn right", "повернуть направо", "Turn right at the stairs.", "Поверните направо у лестницы."),
                  ("have a nice trip", "счастливого пути", "Have a nice trip!", "Счастливого пути!")],
    },
    {
        "id": "toronto_clinic", "city": "Toronto", "country": "Канада", "place": "Городская клиника", "emoji": "🍁",
        "lat": 43.65, "lon": -79.38, "level": "B1", "title": "На приёме у врача",
        "goal": "Опиши симптомы и пойми рекомендации",
        "npc": {"name": "Dr. Lee", "emoji": "🧑‍⚕️"}, "theme": {"a": "#bbf7d0", "b": "#7dd3fc"}, "props": ["🩺", "💊", "🍁"],
        "start": "n1",
        "nodes": {
            "n1": _n("Good morning. What seems to be the problem?", "Доброе утро. Что вас беспокоит?",
                     _c("I've had a headache since yesterday.", "У меня болит голова со вчерашнего дня.", 2, "n2", "Отлично: Present Perfect + since."),
                     _c("My head is hurting me from yesterday.", "Моя голова болит мне со вчера.", 1, "n2", "Поймут, но естественнее: «I've had a headache since yesterday.»", ("I see.", "Понимаю.")),
                     _c("I have headache.", "У меня головная боль.", 0, "n2", "Нужен артикль: «a headache».", ("A headache?", "Головная боль?"))),
            "n2": _n("Do you have a fever or a cough?", "У вас жар или кашель?",
                     _c("No fever, but I feel a bit dizzy.", "Жара нет, но немного кружится голова.", 2, "n3", "Отлично!"),
                     _c("I have a slight fever.", "У меня небольшая температура.", 2, "n3", "Хорошо!"),
                     _c("I am not fever.", "Я не температура.", 0, "n3", "Правильно: «I have a fever / I don't have a fever».", ("You… have no fever?", "У вас… нет жара?"))),
            "n3": _n("Are you allergic to any medicine?", "У вас есть аллергия на лекарства?",
                     _c("No, I'm not allergic to anything.", "Нет, ни на что нет аллергии.", 2, "n4", "Отлично!"),
                     _c("I'm allergic to penicillin.", "У меня аллергия на пенициллин.", 2, "n4", "Важная информация — сказано верно."),
                     _c("I don't know what is allergic.", "Не знаю, что такое аллергичный.", 1, "n4", "Лучше: «I'm not sure. I've never been tested.»")),
            "n4": _n("Take these pills twice a day after meals and get some rest. Any questions?", "Принимайте эти таблетки два раза в день после еды и отдыхайте. Есть вопросы?",
                     _c("Can I go to work tomorrow?", "Можно мне завтра на работу?", 2, "n5", "Отличный вопрос."),
                     _c("How long should I take them?", "Как долго их принимать?", 2, "n5", "Отлично!"),
                     _c("What do you say?", "Что вы говорите?", 0, "n5", "Если не понял, вежливо: «Sorry, could you repeat that?»", ("I said: any questions?", "Я спросил: есть вопросы?"))),
            "n5": _n("Stay home for two days. Come back if it gets worse.", "Побудьте дома два дня. Приходите снова, если станет хуже.",
                     _c("Thank you, doctor. I will.", "Спасибо, доктор. Так и сделаю.", 2, "END", "Отлично!"),
                     _c("OK, thanks for your help.", "Хорошо, спасибо за помощь.", 2, "END", "Отлично!"),
                     _c("Yes yes.", "Да-да.", 1, "END", "Лучше поблагодарить: «Thank you, doctor.»")),
        },
        "endings": {3: ("Take care! You communicate very clearly.", "Берегите себя! Вы очень чётко объясняетесь."),
                    2: ("Good. Get well soon!", "Хорошо. Скорейшего выздоровления!"),
                    1: ("We understood each other. Rest well!", "Мы поняли друг друга. Отдыхайте!")},
        "vocab": [("headache", "головная боль", "I've had a headache since yesterday.", "У меня головная боль со вчера."),
                  ("fever", "жар, температура", "Do you have a fever?", "У вас температура?"),
                  ("allergic to", "аллергия на", "I'm allergic to penicillin.", "У меня аллергия на пенициллин."),
                  ("twice a day", "два раза в день", "Take it twice a day.", "Принимайте два раза в день."),
                  ("could you repeat that", "не могли бы вы повторить", "Sorry, could you repeat that?", "Простите, не могли бы вы повторить?")],
    },
    {
        "id": "berlin_flat", "city": "Berlin", "country": "Германия", "place": "Квартира в Кройцберге", "emoji": "🏢",
        "lat": 52.50, "lon": 13.40, "level": "B2", "title": "Аренда квартиры",
        "goal": "Обсуди условия аренды и договорись о следующем шаге",
        "npc": {"name": "Mr Becker", "emoji": "🧑‍💼"}, "theme": {"a": "#c4b5fd", "b": "#fda4af"}, "props": ["🔑", "🏢", "📄"],
        "start": "n1",
        "nodes": {
            "n1": _n("Thanks for coming. The flat is 55 square metres, and the rent is 900 euros a month, excluding utilities. What do you think?", "Спасибо, что пришли. Квартира 55 кв. м, аренда 900 евро в месяц без коммунальных. Что думаете?",
                     _c("It looks lovely. Are utilities expensive?", "Выглядит замечательно. Коммунальные дорогие?", 2, "n2", "Хорошо: похвала + уточняющий вопрос."),
                     _c("Is it possible to negotiate the rent?", "Можно ли обсудить арендную плату?", 2, "n2", "Вежливо и по делу."),
                     _c("Too expensive for me.", "Слишком дорого для меня.", 1, "n2", "Прямолинейно. Вежливее: «It's a bit above my budget.»", ("I see.", "Понимаю."))),
            "n2": _n("Utilities are around 150 euros. We usually require a two-month deposit.", "Коммунальные около 150 евро. Обычно мы просим залог за два месяца.",
                     _c("That sounds reasonable. When could I move in?", "Звучит разумно. Когда можно въехать?", 2, "n3", "Отлично!"),
                     _c("Could the deposit be paid in instalments?", "Можно ли внести залог частями?", 2, "n3", "Отличный вежливый вопрос."),
                     _c("I give you deposit tomorrow.", "Я даю вам залог завтра.", 0, "n3", "Нужен артикль и модальный глагол: «I can pay the deposit tomorrow.»", ("Tomorrow?", "Завтра?"))),
            "n3": _n("You could move in on the first of next month. Do you have any pets?", "Можете въехать первого числа следующего месяца. У вас есть домашние животные?",
                     _c("No, but I might get a cat. Would that be a problem?", "Нет, но я, возможно, заведу кота. Это проблема?", 2, "n4", "Хорошо: might + вежливый вопрос."),
                     _c("No, I don't have any pets.", "Нет, у меня нет питомцев.", 2, "n4", "Правильно!"),
                     _c("I have not pets.", "Я имею не питомцев.", 0, "n4", "Правильно: «I don't have any pets.»")),
            "n4": _n("Cats are fine. Shall we arrange a second viewing, or would you like to sign now?", "Кошки допускаются. Назначим второй просмотр или хотите подписать сейчас?",
                     _c("I'd like to think it over. Could I get back to you by Friday?", "Я бы хотел подумать. Можно ответить вам к пятнице?", 2, "n5", "Профессионально!"),
                     _c("Let's arrange a second viewing, please.", "Давайте назначим второй просмотр.", 2, "n5", "Отлично!"),
                     _c("I think about it.", "Я думаю об этом.", 1, "n5", "Лучше: «I'd like to think about it.»")),
            "n5": _n("Of course. Take your time.", "Конечно. Не торопитесь.",
                     _c("Thank you for your time, Mr Becker.", "Спасибо за уделённое время, господин Беккер.", 2, "END", "Идеально."),
                     _c("Thanks. Talk to you on Friday!", "Спасибо. Поговорим в пятницу!", 2, "END", "Хорошо!"),
                     _c("OK bye.", "Ладно, пока.", 1, "END", "Слишком небрежно для делового разговора.")),
        },
        "endings": {3: ("A pleasure! I hope to hear from you on Friday.", "Рад был познакомиться! Жду вашего ответа в пятницу."),
                    2: ("Good. Let me know your decision.", "Хорошо. Сообщите ваше решение."),
                    1: ("Thank you for coming. We'll be in touch.", "Спасибо, что пришли. Мы свяжемся.")},
        "vocab": [("rent", "арендная плата", "The rent is 900 euros.", "Аренда — 900 евро."),
                  ("deposit", "залог", "We require a two-month deposit.", "Мы просим залог за два месяца."),
                  ("utilities", "коммунальные услуги", "Are utilities included?", "Коммунальные включены?"),
                  ("negotiate", "договариваться", "Can we negotiate the rent?", "Можем ли мы обсудить аренду?"),
                  ("think it over", "обдумать", "I'd like to think it over.", "Я бы хотел это обдумать.")],
    },
]

LOC_BY_ID = {l["id"]: l for l in LOCATIONS}
LEVEL_ORDER = ["A1", "A2", "B1", "B2", "C1", "C2"]


def public_location(loc: dict) -> dict:
    return {k: loc[k] for k in ("id", "city", "country", "place", "emoji", "lat", "lon", "level", "title", "goal", "npc", "theme", "props")} | {"needs": loc.get("needs", []), "steps": len(_main_path(loc))}


def _main_path(loc: dict) -> list[str]:
    """Типичная длина диалога: идём по первому варианту каждого узла."""
    out, n = [], loc["start"]
    while n != "END" and n not in out:
        out.append(n)
        n = loc["nodes"][n]["choices"][0]["next"]
    return out


def public_node(loc: dict, node_id: str) -> dict:
    n = loc["nodes"][node_id]
    return {"id": node_id, "npc": n["npc"], "ru": n["ru"], "choices": [{"en": c["en"], "ru": c["ru"]} for c in n["choices"]]}


def stars_for(qs: list[int]) -> int:
    if not qs:
        return 1
    r = sum(qs) / (2 * len(qs))
    return 3 if r >= 0.8 else 2 if r >= 0.5 else 1


def validate() -> list[str]:
    """Проверка целостности графа: все next существуют, из каждого узла достижим END, 2–3 реплики."""
    errs = []
    for loc in LOCATIONS:
        nodes = loc["nodes"]
        if loc["start"] not in nodes:
            errs.append(f"{loc['id']}: нет start")
        for nid, n in nodes.items():
            if not 2 <= len(n["choices"]) <= 3:
                errs.append(f"{loc['id']}.{nid}: {len(n['choices'])} реплик")
            for c in n["choices"]:
                if c["next"] != "END" and c["next"] not in nodes:
                    errs.append(f"{loc['id']}.{nid}: next={c['next']} не существует")
                if c["q"] not in (0, 1, 2):
                    errs.append(f"{loc['id']}.{nid}: плохой q")
        reach, stack = set(), [loc["start"]]
        while stack:
            x = stack.pop()
            if x in reach or x == "END":
                continue
            reach.add(x)
            stack += [c["next"] for c in nodes[x]["choices"]]
        if reach != set(nodes):
            errs.append(f"{loc['id']}: недостижимые узлы {set(nodes) - reach}")
        if set(loc["endings"]) != {1, 2, 3}:
            errs.append(f"{loc['id']}: нужны endings 1,2,3")
        if len(loc["vocab"]) < 5:
            errs.append(f"{loc['id']}: мало vocab")
        # детектор циклов
        seen = set()
        def dfs(x, path):
            if x == "END":
                return
            if x in path:
                errs.append(f"{loc['id']}: цикл через {x}")
                return
            if x in seen:
                return
            seen.add(x)
            for c in nodes[x]["choices"]:
                dfs(c["next"], path | {x})
        dfs(loc["start"], frozenset())
    return errs
