"""Бизнес-логика Engly (без FastAPI): всё, что нужно проверять на сервере, а не доверять клиенту.

Принцип: клиент присылает только «что выбрал» (id сессии, индекс задания, текст ответа),
а правильные ответы, XP, билеты и прогресс считает сервер. Сессии (тест, урок, локация) хранятся в БД.
"""
import asyncio
import functools
import random
from datetime import datetime, timezone

from . import adaptive, gamify, lessons
from . import path as pathmod
from .config import settings
from .content import BANK, LEVELS, WORLDS, items_for, topics_for, world
from .db import database as db
from .db import msk_today, streak_view
from .locations import LOC_BY_ID, LOCATIONS, LEVEL_ORDER, public_location, public_node, stars_for
from .placement_bank import BANK as PBANK
from .visuals import emoji_of


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        super().__init__(detail)
        self.status, self.detail = status, detail


# ----------------------------------------------------------------- общее
_locks: dict[int, asyncio.Lock] = {}


def _user_lock(tg_id: int) -> asyncio.Lock:
    lk = _locks.get(tg_id)
    if lk is None:
        if len(_locks) > 5000:                      # не копим замки бесконечно
            for k in [k for k, v in _locks.items() if not v.locked()][:2500]:
                _locks.pop(k, None)
        lk = _locks[tg_id] = asyncio.Lock()
    return lk


def serialized(fn):
    """Операции, которые читают сессию, начисляют награды и сохраняют сессию, выполняются у одного пользователя строго по очереди.
    Без этого двойной тап или повтор запроса после обрыва связи могли начислить XP/билеты дважды."""
    @functools.wraps(fn)
    async def wrapper(tg_id: int, *a, **kw):
        async with _user_lock(tg_id):
            return await fn(tg_id, *a, **kw)
    return wrapper


async def _user(tg_id: int):
    u = await db.get_user(tg_id)
    if not u:
        raise ApiError(404, "no_user")
    return u


async def _require_quota(tg_id: int) -> bool:
    """Лимит бесплатных заданий в день. Возвращает is_premium; бросает 402 при исчерпании."""
    premium = db.is_premium(await db.get_user(tg_id))
    if not premium and await db.tasks_left(tg_id) <= 0:
        await db.log_event("paywall_view", tg_id, {"place": "lesson"})
        raise ApiError(402, "limit")
    return premium


def _lvl_idx(level: str) -> int:
    return LEVEL_ORDER.index(level) if level in LEVEL_ORDER else 0


def _public_ach(have: set[str]) -> list[dict]:
    return [gamify.public_achievement(a, a["code"] in have) for a in gamify.ACHIEVEMENTS]


async def _award_achievements(tg_id: int) -> list[dict]:
    have = await db.ach_have(tg_id)
    new = gamify.newly_earned(await db.stats_for_achievements(tg_id), have)
    out = []
    for a in new:
        if await db.ach_add(tg_id, a["code"]):
            await db.add_tickets(tg_id, a["tickets"])
            out.append(gamify.public_achievement(a, True))
    return out


# ----------------------------------------------------------------- профиль и главная
async def profile(tg_id: int, username: str | None = None) -> dict:
    await db.ensure_user(tg_id, username)
    u = await _user(tg_id)
    streak, studied_today = streak_view(u["streak_days"], u["last_study_day"], u["freezes"])
    premium = db.is_premium(u)
    limit, ref_bonus = db._limit_with_bonus(u)
    tot = await (await db.db.execute(
        "SELECT COUNT(*) n, COALESCE(SUM(is_correct),0) c FROM answers_log WHERE tg_id=?", (tg_id,))).fetchone()
    daily = await db.daily_status(tg_id)
    srs = await db.srs_stats(tg_id)
    have = await db.ach_have(tg_id)
    return {
        "tg_id": tg_id, "is_premium": premium, "premium_until": u["premium_until"],
        "onboarded": bool(u["quiz_done"]), "level": u["level"], "goal": u["goal"], "minutes": u["daily_minutes"],
        "xp": u["xp"], "player": gamify.player_level(u["xp"]), "streak": streak, "studied_today": studied_today,
        "freezes": u["freezes"], "tickets": u["tickets"], "daily": daily,
        "free_left": settings.free_limit if premium else await db.tasks_left(tg_id),
        "free_limit": settings.free_limit if premium else limit, "ref_bonus": ref_bonus,
        "answered": tot["n"], "correct": tot["c"], "srs": srs,
        "analysis_left": 1 if (premium or not await db.analysis_used_today(tg_id)) else 0,
        "achievements": _public_ach(have), "freeze_price": gamify.FREEZE_PRICE,
    }


def _loc_lock(user_level: str, loc: dict, done: dict) -> str | None:
    """None — локация открыта. Иначе подсказка, что сделать. Для A1/A2 нужны темы пути — чтобы новичка не бросали в диалог без слов."""
    li, ui = _lvl_idx(loc["level"]), _lvl_idx(user_level)
    if li > ui:
        return f"Откроется на уровне {loc['level']}"
    if li == ui:
        miss = [t for t in loc.get("needs", []) if not pathmod.topic_done(loc["level"], t, done)]
        if miss:
            return "Сначала пройди тему: " + ", ".join(f"«{t}»" for t in miss)
    return None


async def locations(tg_id: int) -> dict:
    u = await _user(tg_id)
    prog = await db.loc_progress(tg_id)
    done = await db.path_progress(tg_id)
    ui = _lvl_idx(u["level"])
    out = []
    for loc in LOCATIONS:
        lock = _loc_lock(u["level"], loc, done)
        p = prog.get(loc["id"], {"stars": 0, "runs": 0})
        out.append({**public_location(loc), "unlocked": lock is None, "lock_hint": lock, **p})
    cands = [l for l in out if l["unlocked"] and l["runs"] == 0 and _lvl_idx(l["level"]) <= ui]
    rec = (max(cands, key=lambda l: _lvl_idx(l["level"])) if cands else None)
    return {"locations": out, "recommended": rec["id"] if rec else None, "level": u["level"]}


async def word_of_day(tg_id: int) -> dict:
    u = await _user(tg_id)
    level = u["level"]
    rnd = random.Random(int(msk_today().replace("-", "")) + tg_id)
    en, ru, ph, ph_ru = rnd.choice(items_for(level, rnd.choice(topics_for(level))))
    return {"level": level, "en": en, "ru": ru, "phrase": ph, "phrase_ru": ph_ru}


# ----------------------------------------------------------------- адаптивный тест
GOAL_TOPICS = {
    "travel": ["Путешествия", "Транспорт", "Кафе и ресторан", "Места в городе", "Покупки"],
    "work": ["Деловой английский", "Работа и учёба", "Деловая среда"],
    "study": ["Академический стиль", "Образование", "Работа и учёба", "Научный дискурс"],
    "relocate": ["Жизнь за рубежом", "Семья и дом", "Здоровье", "Покупки"],
    "fun": ["Small talk", "Чувства и мнения", "Общество и медиа", "Идиомы и нюансы", "Технологии"],
}
KIND_TITLE = {"tr": "словарный запас", "cloze": "грамматика"}


def _public_q(q: dict, n: int) -> dict:
    opts = [q["correct"], *q["wrong"]]
    random.shuffle(opts)
    return {"id": q["id"], "kind": q["kind"], "prompt": q["prompt"], "instr": q["instr"], "options": opts,
            "n": n, "max": adaptive.MAX_Q, "tts": q["kind"] == "tr"}


async def placement_start(tg_id: int, goal: str | None, minutes: int | None) -> dict:
    await _user(tg_id)
    goal = goal if goal in gamify.GOALS else None
    minutes = minutes if minutes in gamify.GOAL_BY_MINUTES else None
    q = adaptive.pick_next([], set())
    sid = await db.session_create(tg_id, "placement", {
        "answers": [], "cur": q["id"], "goal": goal, "minutes": minutes})
    return {"session_id": sid, "question": _public_q(q, 1)}


async def placement_skip(tg_id: int, goal: str | None, minutes: int | None) -> dict:
    """«Я новичок»: начинаем с A1 без теста (меньше отвала на онбординге). Уже прошедшему онбординг уровень не сбрасывается."""
    u = await _user(tg_id)
    goal = goal if goal in gamify.GOALS else None
    minutes = minutes if minutes in gamify.GOAL_BY_MINUTES else None
    if u["quiz_done"]:
        summary = {"by_kind": {}, "progress_in_level": 0.0}
        return {"level": u["level"], "theta": u["theta"] or 0.5, "sd": None, "confidence": "low", "answered": 0, "correct": 0,
                "plan": make_plan(u["level"], summary, u["goal"], u["daily_minutes"])}
    await db.db.execute(
        "UPDATE users SET level='A1', quiz_done=1, goal=?, daily_minutes=?, daily_goal=? WHERE tg_id=?",
        (goal, minutes, gamify.goal_for_minutes(minutes), tg_id))
    await db.db.commit()
    await db.log_event("placement_skip", tg_id)
    summary = {"by_kind": {}, "progress_in_level": 0.0}
    return {"level": "A1", "theta": 0.5, "sd": None, "confidence": "low", "answered": 0, "correct": 0,
            "plan": make_plan("A1", summary, goal, minutes)}


def make_plan(level: str, summary: dict, goal: str | None, minutes: int | None) -> dict:
    topics = topics_for(level)
    pref = [t for t in GOAL_TOPICS.get(goal or "", []) if t in topics]
    focus_topics = (pref + [t for t in topics if t not in pref])[:3]
    bk = summary["by_kind"]
    weak = None
    if "tr" in bk and "cloze" in bk and abs(bk["tr"] - bk["cloze"]) >= 0.25:
        weak = KIND_TITLE["cloze" if bk["cloze"] < bk["tr"] else "tr"]
    li = _lvl_idx(level)
    return {
        "level": level, "world": world(level),
        "next_level": LEVEL_ORDER[li + 1] if li < 5 else None,
        "progress_in_level": summary["progress_in_level"],
        "daily_goal_xp": gamify.goal_for_minutes(minutes), "minutes": minutes or 5,
        "focus_topics": focus_topics, "weak_area": weak,
        "first_location": next((l["id"] for l in reversed(LOCATIONS) if _lvl_idx(l["level"]) <= li), LOCATIONS[0]["id"]),
        "goal": goal,
    }


@serialized
async def placement_answer(tg_id: int, sid: str, qid: str, answer: str | None) -> dict:
    got = await db.session_get(sid, tg_id, "placement")
    if not got:
        raise ApiError(404, "no_session")
    state, finished = got
    if finished:
        raise ApiError(409, "already_finished")
    if qid != state["cur"] or qid not in PBANK:
        raise ApiError(400, "wrong_question")
    q = PBANK[qid]
    ok = answer is not None and answer == q["correct"]
    state["answers"].append({"id": qid, "b": q["b"], "ok": ok, "kind": q["kind"], "level": q["level"]})
    answers = state["answers"]

    if adaptive.is_finished(answers):
        summary = adaptive.summarize(answers)
        level = summary["level"]
        goal, minutes = state.get("goal"), state.get("minutes")
        await db.db.execute(
            "UPDATE users SET level=?, quiz_done=1, theta=?, placement_sd=?, goal=?, daily_minutes=?, daily_goal=? WHERE tg_id=?",
            (level, summary["theta"], summary["sd"], goal, minutes, gamify.goal_for_minutes(minutes), tg_id))
        await db.db.commit()
        await db.log_event("placement_done", tg_id, {"level": level, "theta": summary["theta"], "sd": summary["sd"], "n": len(answers)})
        await db.session_save(sid, state, finished=True)
        return {"done": True, "ok": ok, "result": {**summary, "plan": make_plan(level, summary, goal, minutes)}}

    nxt = adaptive.pick_next(answers, {a["id"] for a in answers})
    state["cur"] = nxt["id"]
    await db.session_save(sid, state)
    return {"done": False, "ok": ok, "question": _public_q(nxt, len(answers) + 1)}


# ----------------------------------------------------------------- уроки
POOL = 60


async def path(tg_id: int) -> dict:
    """Карта пути: уровни → темы → уроки. Статусы считает сервер."""
    u = await _user(tg_id)
    p = pathmod.build_path(u["level"], await db.path_progress(tg_id), dict(u).get("goal"))
    stats = await db.srs_stats(tg_id)
    p["due"], p["learning"] = stats["due"], stats["total"]
    return p


async def lesson_start(tg_id: int, level: str | None, topic: str | None, mode: str = "path", kind: str | None = None) -> dict:
    u = await _user(tg_id)
    if mode != "review":                 # повторение — бесплатно; лимит ограничивает запуск, а не обрывает начатый урок
        await _require_quota(tg_id)
    due = await db.srs_due(tg_id, 30)
    chunk = None
    if mode == "review":
        if not due:
            raise ApiError(409, "no_due")
        tasks = lessons.build_review_lesson(due)
        level, topic = "review", "Повторение"
    elif mode == "drill":
        if kind not in lessons.DRILLS:
            raise ApiError(400, "bad_kind")
        try:
            tasks = lessons.build_drill(kind, await db.srs_pool(tg_id, POOL))
        except ValueError:
            raise ApiError(409, "need_words")
        level, topic = "drill", lessons.DRILLS[kind][0]
    else:
        if level not in LEVELS or topic not in topics_for(level):
            raise ApiError(400, "нет такого мира/темы")
        done = await db.path_progress(tg_id)
        unit = next(x for lv in pathmod.build_path(u["level"], done, dict(u).get("goal"))["levels"] if lv["id"] == level for x in lv["units"] if x["topic"] == topic)
        if unit["status"] == "locked":
            raise ApiError(403, "locked")
        if mode == "path" and unit["status"] != "done":
            chunk = unit["done"]
            pool = await db.srs_pool(tg_id, 40)
            tasks = lessons.build_path_lesson(level, topic, chunk, due, pool, len(pool))
        else:
            mode = "practice"
            tasks = lessons.build_topic_lesson(level, topic, due, await db.srs_known(tg_id, level, topic))
    state = {"mode": mode, "level": level, "topic": topic, "tasks": tasks, "base": len(tasks), "chunk": chunk,
             "answered": {}, "xp": 0, "retried": [], "quota_ok": True}
    sid = await db.session_create(tg_id, "lesson", state)
    await db.log_event("lesson_start", tg_id, {"level": level, "topic": topic, "mode": mode})
    return {"session_id": sid, "level": level, "topic": topic, "mode": mode, "chunk": chunk,
            "chunks": lessons.n_chunks(level, topic) if chunk is not None else None,
            "tasks": [lessons.public_task(t, i) for i, t in enumerate(tasks)],
            "review_count": sum(1 for t in tasks if t.get("review"))}


async def _lesson_session(tg_id: int, sid: str, idx: int):
    got = await db.session_get(sid, tg_id, "lesson")
    if not got:
        raise ApiError(404, "no_session")
    state, finished = got
    if finished:
        raise ApiError(409, "already_finished")
    if not isinstance(idx, int) or not 0 <= idx < len(state["tasks"]):
        raise ApiError(400, "bad_idx")
    if str(idx) in state["answered"]:
        raise ApiError(409, "already_answered")
    return state


def _lesson_view(sid: str, state: dict) -> dict:
    tasks = state["tasks"]
    nxt = next((i for i in range(len(tasks)) if str(i) not in state["answered"]), len(tasks))
    return {"session_id": sid, "level": state["level"], "topic": state["topic"], "mode": state["mode"], "chunk": state.get("chunk"),
            "chunks": lessons.n_chunks(state["level"], state["topic"]) if state.get("chunk") is not None else None,
            "tasks": [lessons.public_task(t, i) for i, t in enumerate(tasks)], "answered": [int(i) for i in state["answered"]],
            "next": nxt, "review_count": sum(1 for t in tasks if t.get("review")), "base": state["base"]}


async def lesson_state(tg_id: int, sid: str) -> dict:
    """Актуальное состояние урока по session_id — клиент синхронизируется после обрыва связи."""
    got = await db.session_get(sid, tg_id, "lesson")
    if not got:
        raise ApiError(404, "no_session")
    state, finished = got
    return {**_lesson_view(sid, state), "finished": finished}


async def lesson_resume(tg_id: int) -> dict | None:
    """Незавершённый урок (если пользователь закрыл приложение посреди занятия)."""
    got = await db.session_open_latest(tg_id, "lesson")
    if not got:
        return None
    sid, state = got
    if not state["answered"] and state["mode"] != "path":
        return None
    changed = False
    for i, t in enumerate(state["tasks"]):                 # «пары» без ответа начинаем заново
        if t["type"] == "match" and str(i) not in state["answered"] and (t["matched"] or t["bad"]):
            t["matched"], t["bad"], changed = [], [], True
    if changed:
        await db.session_save(sid, state)
    v = _lesson_view(sid, state)
    return v


async def practice(tg_id: int) -> dict:
    """Что доступно в «Практике»: сколько слов подходит под каждую тренировку (клиент и сервер используют одно правило)."""
    pool = await db.srs_pool(tg_id, POOL)
    st = await db.srs_stats(tg_id)
    return {"need": 3, "drills": {k: sum(1 for c in pool if d[1](c)) for k, d in lessons.DRILLS.items()},
            "counts": {**await db.srs_status_counts(tg_id), "due": st["due"]}}


@serialized
async def lesson_pair(tg_id: int, sid: str, idx: int, en: str, ru: str) -> dict:
    """Задание «найди пару»: каждую пару проверяет сервер (клиент не знает правильных соответствий)."""
    state = await _lesson_session(tg_id, sid, idx)
    t = state["tasks"][idx]
    if t["type"] != "match":
        raise ApiError(400, "not_match")
    pair = next((p for p in t["pairs"] if p["en"] == en), None)
    if not pair:
        raise ApiError(400, "bad_pair")
    if en in t["matched"]:
        return {"ok": True, "done": len(t["matched"]) == len(t["pairs"])}
    ok = pair["ru"] == ru
    (t["matched"] if ok else t["bad"]).append(en)
    await db.session_save(sid, state)
    return {"ok": ok, "done": len(t["matched"]) == len(t["pairs"])}


@serialized
async def lesson_answer(tg_id: int, sid: str, idx: int, answer: str | None, ms: int | None) -> dict:
    state = await _lesson_session(tg_id, sid, idx)
    tasks = state["tasks"]
    t = tasks[idx]
    kind = t["type"]
    premium = db.is_premium(await db.get_user(tg_id))
    unscored = kind in lessons.UNSCORED
    # лимит тратят только новые учебные задания: повторение, разминка и исправление ошибок бесплатны
    counted = not unscored and not t.get("review") and not t.get("retry") and state["mode"] != "review"
    if counted and not premium and not state.get("quota_ok") and await db.tasks_left(tg_id) <= 0:
        raise ApiError(402, "limit")

    ms = max(0, min(int(ms), 60000)) if ms is not None else None
    mistakes = 0
    if kind == "match":
        if len(t["matched"]) != len(t["pairs"]):
            raise ApiError(400, "not_matched")
        mistakes = len(t["bad"])
        correct = mistakes <= 1
    else:
        correct = lessons.check_answer(t, answer or "")
    if unscored:    # знакомство/говорение не проверяются: «произнёс» даёт небольшой XP, «пропустить» — 0
        xp = t["xp"] if (kind == "speak" and answer == "done") else 0
    else:
        xp = t["xp"] if correct else 0

    srs = None
    if kind == "intro":
        await db.srs_add_cards(tg_id, [{"en": t["item"], "ru": t["ru"], "phrase": t["phrase"], "phrase_ru": t["phrase_ru"],
                                        "level": t["level"], "topic": t.get("topic", ""), "src": "bank"}])
    elif kind == "match":
        bad = set(t["bad"])
        for p in t["pairs"]:
            ok = p["en"] not in bad
            await db.db.execute("INSERT INTO answers_log(tg_id,item_en,is_correct,mode) VALUES(?,?,?,?)", (tg_id, p["en"], 1 if ok else 0, "match"))
            srs = await db.srs_record(tg_id, {"en": p["en"], "level": p["level"], "topic": p.get("topic", ""), "ru": p["ru"],
                                              "phrase": p["phrase"], "phrase_ru": p["phrase_ru"]}, ok, None)
        await db.db.commit()
        if counted and not premium:
            await db.count_task(tg_id)
    elif kind != "speak":
        await db.db.execute("INSERT INTO answers_log(tg_id,item_en,is_correct,mode) VALUES(?,?,?,?)",
                            (tg_id, t["item"], 1 if correct else 0, kind))
        await db.db.commit()
        if counted and not premium:
            await db.count_task(tg_id)
        srs = await db.srs_record(tg_id, {"en": t["item"], "level": t["level"], "topic": t.get("topic", ""),
                                          "ru": t["ru"], "phrase": t["phrase"], "phrase_ru": t["phrase_ru"]}, bool(correct), ms)
    streak = await db.touch_streak(tg_id) if (kind not in ("intro",) and (kind != "speak" or answer == "done")) else None
    prog = await db.add_xp(tg_id, xp) if xp else await db.daily_status(tg_id)
    tickets_earned = 0
    if prog.get("goal_just_hit"):
        tickets_earned = gamify.TICKET_RULES["daily_goal"]
        await db.add_tickets(tg_id, tickets_earned)

    state["answered"][str(idx)] = {"ok": correct, "xp": xp}
    state["xp"] += xp
    retry = None
    if (correct is False and kind not in ("match",) and not t.get("retry") and t["item"] not in state["retried"]
            and len(state["retried"]) < 3):
        state["retried"].append(t["item"])
        rt = lessons.retry_task(t)
        tasks.append(rt)
        retry = lessons.public_task(rt, len(tasks) - 1)
    await db.session_save(sid, state)

    return {
        "correct": correct, "xp_earned": xp, "correct_answer": "" if kind in ("match", "intro", "speak") else lessons.correct_text(t),
        "correct_value": "" if kind in ("match", "intro", "speak") else lessons.correct_value(t),
        "item": t["item"], "ru": t["ru"], "emoji": t.get("emoji"), "phrase": t["phrase"], "phrase_ru": t["phrase_ru"],
        "retry": retry, "srs": srs, "mistakes": mistakes,
        "streak": (streak or {}).get("streak"), "freeze_used": bool(streak and streak["freeze_used"]),
        "streak_new_day": bool(streak and streak["new_day"]),
        "daily": {"today_xp": prog.get("today_xp"), "goal": prog.get("goal"), "goal_just_hit": bool(prog.get("goal_just_hit"))},
        "tickets_earned": tickets_earned,
        "free_left": settings.free_limit if premium else await db.tasks_left(tg_id),
    }


@serialized
async def lesson_finish(tg_id: int, sid: str) -> dict:
    got = await db.session_get(sid, tg_id, "lesson")
    if not got:
        raise ApiError(404, "no_session")
    state, finished = got
    if finished:
        return state["result"]
    base = state["base"]
    scored = [(int(i), a) for i, a in state["answered"].items() if a["ok"] is not None and int(i) < base]
    required = [i for i, t in enumerate(state["tasks"][:base]) if t["type"] != "speak"]     # говорение можно пропустить
    if any(str(i) not in state["answered"] for i in required):
        raise ApiError(400, "not_finished")
    wrong = sum(1 for _, a in scored if a["ok"] is False)
    perfect = wrong == 0 and len(scored) >= 4
    accuracy = round(1 - wrong / max(1, len(scored)), 2)
    u0 = await _user(tg_id)
    lvl_before = gamify.player_level(u0["xp"])["level"]

    bonus = 10 + (10 if perfect else 0)
    prog = await db.add_xp(tg_id, bonus)
    await db.touch_streak(tg_id)
    tickets = gamify.TICKET_RULES["lesson"] + (gamify.TICKET_RULES["perfect"] if perfect else 0)
    if prog["goal_just_hit"]:
        tickets += gamify.TICKET_RULES["daily_goal"]

    # прогресс пути: урок засчитывается при точности ≥ 60% — иначе его стоит повторить
    path_info, cefr_up = None, None
    if state["mode"] == "path":
        lv, tp = state["level"], state["topic"]
        total = lessons.n_chunks(lv, tp)
        passed = accuracy >= pathmod.PASS_ACCURACY
        if passed:
            await db.db.execute(
                "INSERT INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(?,?,?,1) "
                "ON CONFLICT(tg_id, level, topic) DO UPDATE SET lessons_done=MIN(lessons_done+1, ?)", (tg_id, lv, tp, total))
            await db.db.commit()
        done = await db.path_progress(tg_id)
        unit_done = pathmod.topic_done(lv, tp, done)
        if passed and unit_done and lv == u0["level"] and pathmod.level_complete(lv, done) and _lvl_idx(lv) < len(LEVELS) - 1:
            cefr_up = {"from": lv, "to": LEVELS[_lvl_idx(lv) + 1], "world": world(LEVELS[_lvl_idx(lv) + 1])}
            await db.db.execute("UPDATE users SET level=? WHERE tg_id=?", (cefr_up["to"], tg_id))
            await db.db.commit()
            tickets += 5
        path_info = {"level": lv, "topic": tp, "lesson": (state.get("chunk") or 0) + 1, "of": total, "passed": passed, "unit_done": passed and unit_done}
    await db.add_tickets(tg_id, tickets)
    if perfect:
        await db.db.execute("UPDATE users SET perfect_lessons=perfect_lessons+1 WHERE tg_id=?", (tg_id,))
    await db.db.commit()
    await db.log_event("lesson_finish", tg_id, {"level": state["level"], "topic": state["topic"], "perfect": perfect, "mode": state["mode"]})

    ach = await _award_achievements(tg_id)
    u = await _user(tg_id)
    pl = gamify.player_level(u["xp"])
    result = {
        "xp_lesson": state["xp"] + bonus, "bonus": bonus, "perfect": perfect, "wrong": wrong, "mode": state["mode"],
        "accuracy": accuracy, "tickets_earned": tickets + sum(a["tickets"] for a in ach),
        "achievements": ach, "streak": u["streak_days"], "player": pl, "level_up": pl["level"] > lvl_before,
        "daily": {"today_xp": prog["today_xp"], "goal": prog["goal"]},
        "tickets": u["tickets"], "srs": await db.srs_stats(tg_id), "path": path_info, "cefr_up": cefr_up,
    }
    state["result"] = result
    await db.session_save(sid, state, finished=True)
    return result


async def vocab(tg_id: int) -> dict:
    """Словарь пользователя: все карточки с картинкой и статусом (новое / учу / выучено)."""
    rows = await db.srs_all(tg_id)
    out, cnt = [], await db.srs_status_counts(tg_id)
    for r in rows[:1000]:
        st = "mastered" if r["interval"] >= 21 else "new" if r["reps"] == 0 else "learning"
        out.append({"en": r["en"], "ru": r["ru"], "phrase": r["phrase"], "phrase_ru": r["phrase_ru"], "level": r["level"],
                    "topic": r["topic"], "emoji": emoji_of(r["en"]), "status": st, "strength": round(min(1.0, r["interval"] / 21), 2),
                    "leech": r["lapses"] >= 4})
    return {"cards": out, "counts": cnt}


# ----------------------------------------------------------------- локации (диалоги)
QUALITY_XP = {2: 10, 1: 5, 0: 0}


async def location_start(tg_id: int, loc_id: str) -> dict:
    loc = LOC_BY_ID.get(loc_id)
    if not loc:
        raise ApiError(404, "no_location")
    u = await _user(tg_id)
    if _loc_lock(u["level"], loc, await db.path_progress(tg_id)):
        raise ApiError(403, "locked")
    await _require_quota(tg_id)
    sid = await db.session_create(tg_id, "location", {"loc": loc_id, "node": loc["start"], "qs": [], "xp": 0})
    await db.log_event("location_start", tg_id, {"loc": loc_id})
    return {"session_id": sid, "location": public_location(loc), "node": public_node(loc, loc["start"])}


@serialized
async def location_choose(tg_id: int, sid: str, node_id: str, idx: int) -> dict:
    got = await db.session_get(sid, tg_id, "location")
    if not got:
        raise ApiError(404, "no_session")
    state, finished = got
    if finished:
        raise ApiError(409, "already_finished")
    loc = LOC_BY_ID[state["loc"]]
    if node_id != state["node"]:
        raise ApiError(400, "wrong_node")
    choices = loc["nodes"][node_id]["choices"]
    if not isinstance(idx, int) or not 0 <= idx < len(choices):
        raise ApiError(400, "bad_choice")
    # лимит проверяется один раз — при запуске локации (location_start). Начатый диалог доводим до конца,
    # иначе на 3-й реплике бесплатного пользователя выкидывало на пейвол. Реплики по-прежнему тратят дневные задания.
    premium = db.is_premium(await db.get_user(tg_id))
    ch = choices[idx]
    if not premium:
        await db.count_task(tg_id)
    q = ch["q"]
    xp = QUALITY_XP[q]
    state["qs"].append(q)
    state["xp"] += xp
    streak = await db.touch_streak(tg_id)
    prog = await db.add_xp(tg_id, xp) if xp else await db.daily_status(tg_id)
    tickets = gamify.TICKET_RULES["daily_goal"] if prog.get("goal_just_hit") else 0
    out = {"q": q, "fb": ch["fb"], "react": ch.get("react"), "xp_earned": xp, "you": {"en": ch["en"], "ru": ch["ru"]},
           "streak": streak["streak"], "daily": {"today_xp": prog.get("today_xp"), "goal": prog.get("goal")}}

    if ch["next"] != "END":
        state["node"] = ch["next"]
        if tickets:
            await db.add_tickets(tg_id, tickets)
            state["tickets"] = state.get("tickets", 0) + tickets   # покажем в итоговом экране
        await db.session_save(sid, state)
        return {**out, "done": False, "node": public_node(loc, ch["next"]), "tickets_earned": tickets}

    stars = stars_for(state["qs"])
    first = await db.loc_record(tg_id, loc["id"], stars)
    bonus = stars * 5
    prog = await db.add_xp(tg_id, bonus)
    if prog["goal_just_hit"]:
        tickets += gamify.TICKET_RULES["daily_goal"]
    tickets += gamify.TICKET_RULES["location_first"] if first else gamify.TICKET_RULES["location_repeat"]
    await db.add_tickets(tg_id, tickets)
    added = await db.srs_add_cards(tg_id, [
        {"en": v[0], "ru": v[1], "phrase": v[2], "phrase_ru": v[3], "level": loc["level"],
         "topic": f"📍 {loc['city']}", "src": "location"} for v in loc["vocab"]])
    ach = await _award_achievements(tg_id)
    u = await _user(tg_id)
    result = {**out, "done": True, "stars": stars, "first_time": first, "ending": {"en": loc["endings"][stars][0], "ru": loc["endings"][stars][1]},
              "xp_location": state["xp"] + bonus, "bonus": bonus, "tickets_earned": tickets + state.get("tickets", 0) + sum(a["tickets"] for a in ach),
              "achievements": ach, "vocab": [{"en": v[0], "ru": v[1], "phrase": v[2]} for v in loc["vocab"]], "vocab_added": added,
              "player": gamify.player_level(u["xp"]), "tickets": u["tickets"], "streak": u["streak_days"]}
    await db.log_event("location_finish", tg_id, {"loc": loc["id"], "stars": stars})
    state["result"] = result
    await db.session_save(sid, state, finished=True)
    return result


# ----------------------------------------------------------------- магазин
async def buy_freeze(tg_id: int) -> dict:
    u = await _user(tg_id)
    if u["freezes"] >= gamify.MAX_FREEZES:
        raise ApiError(409, "max_freezes")
    if not await db.spend_tickets(tg_id, gamify.FREEZE_PRICE):
        raise ApiError(402, "not_enough_tickets")
    await db.db.execute("UPDATE users SET freezes=freezes+1 WHERE tg_id=?", (tg_id,))
    await db.db.commit()
    u = await _user(tg_id)
    return {"freezes": u["freezes"], "tickets": u["tickets"]}


# ----------------------------------------------------------------- разбор ошибок
MODE_LABELS = {"ru_en": "Перевод RU→EN", "en_ru": "Перевод EN→RU", "listen": "Аудирование", "scramble": "Сборка фразы",
               "speak": "Говорение", "pick_emoji": "Угадай картинку", "type_word": "Правописание", "match": "Найди пару"}


@serialized
async def mistakes(tg_id: int) -> dict:
    u = await _user(tg_id)
    premium = db.is_premium(u)
    if not premium and await db.analysis_used_today(tg_id):
        await db.log_event("paywall_view", tg_id, {"place": "analysis"})
        raise ApiError(402, "analysis_limit")
    cur = await db.db.execute(
        "SELECT item_en, mode, COUNT(*) AS n FROM answers_log WHERE tg_id=? AND is_correct=0 "
        "GROUP BY item_en ORDER BY n DESC, MAX(id) DESC LIMIT 15", (tg_id,))
    weak = []
    for r in await cur.fetchall():
        c = await db.srs_get(tg_id, r["item_en"])
        weak.append({"en": r["item_en"], "n": r["n"], "mode": MODE_LABELS.get(r["mode"], r["mode"] or ""),
                     "level": c["level"] if c else "", "topic": c["topic"] if c else "",
                     "ru": c["ru"] if c else "", "phrase": c["phrase"] if c else "",
                     "leech": bool(c and c["lapses"] >= 4), "interval": c["interval"] if c else 0})
    cur = await db.db.execute(
        "SELECT mode, COUNT(*) AS n, SUM(is_correct) AS c FROM answers_log WHERE tg_id=? GROUP BY mode", (tg_id,))
    by_mode = [{"mode": MODE_LABELS.get(r["mode"], r["mode"] or ""), "answered": r["n"],
                "accuracy": round(r["c"] / r["n"], 3) if r["n"] else None} for r in await cur.fetchall()]
    tot = await (await db.db.execute(
        "SELECT COUNT(*) AS n, COALESCE(SUM(is_correct),0) AS c FROM answers_log WHERE tg_id=?", (tg_id,))).fetchone()
    if not premium:
        await db.mark_analysis_used(tg_id)
    await db.log_event("analysis_open", tg_id, {"premium": premium, "weak": len(weak)})
    return {"premium": premium, "answered": tot["n"], "correct": tot["c"],
            "accuracy": round(tot["c"] / tot["n"], 3) if tot["n"] else None,
            "weak": weak, "by_mode": by_mode, "free_used": not premium, "srs": await db.srs_stats(tg_id)}


# ----------------------------------------------------------------- аккаунт
@serialized
async def delete_account(tg_id: int) -> dict:
    """Удаляет весь прогресс и профиль пользователя. Записи об оплатах хранятся для учёта и возвратов."""
    await _user(tg_id)
    await db.delete_user(tg_id)
    return {"deleted": True}
