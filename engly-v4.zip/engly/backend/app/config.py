import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

PROJECT_DIR = BASE_DIR.parent


class Settings:
    bot_token: str = os.environ.get("BOT_TOKEN", "")
    base_url: str = os.environ.get("BASE_URL", "").rstrip("/")
    webapp_url: str = os.environ.get("WEBAPP_URL", "").rstrip("/") or os.environ.get("BASE_URL", "").rstrip("/")
    port: int = int(os.environ.get("PORT", "8002"))
    bot_mode: str = os.environ.get("BOT_MODE", "polling")
    dev_mode: bool = os.environ.get("DEV_MODE", "0") == "1"
    db_path: str = os.environ.get("DB_PATH") or str(BASE_DIR / "app.db")
    free_limit: int = int(os.environ.get("FREE_LIMIT", "12"))
    auth_max_age_sec: int = int(os.environ.get("AUTH_MAX_AGE", str(24 * 3600)))
    webhook_secret: str = os.environ.get("WEBHOOK_SECRET", "")
    admin_id: int = int(os.environ.get("ADMIN_ID") or 0)
    tg_proxy_url: str = os.environ.get("TG_PROXY_URL", "")


    @property
    def dev_allowed(self) -> bool:
        """Dev-вход (X-Dev-User) допустим только на локальной машине: пустой BASE_URL или localhost.
        Раньше достаточно было DEV_MODE=1 — при ошибке в .env на проде любой мог войти под чужим id."""
        host = self.base_url.lower()
        return self.dev_mode and (not host or "localhost" in host or "127.0.0.1" in host)


settings = Settings()
