"""Геймификация: уровни игрока, дневная цель, билеты ✈️, достижения."""
import math

GOAL_BY_MINUTES = {5: 20, 10: 40, 15: 60, 20: 80}   # минут в день -> дневная цель XP
DEFAULT_GOAL_XP = 30
TICKET_RULES = {"lesson": 1, "location_first": 2, "location_repeat": 0, "daily_goal": 3, "perfect": 1}
FREEZE_PRICE, MAX_FREEZES = 10, 2

GOALS = {
    "travel": {"title": "Путешествия", "emoji": "✈️"},
    "work": {"title": "Работа и карьера", "emoji": "💼"},
    "study": {"title": "Учёба и экзамены", "emoji": "🎓"},
    "relocate": {"title": "Переезд", "emoji": "🏡"},
    "fun": {"title": "Фильмы и общение", "emoji": "🎬"},
}


def player_level(xp: int) -> dict:
    """Треугольная шкала: уровень n начинается с 50·n·(n−1) XP (2→100, 3→300, 4→600, 5→1000…)."""
    xp = max(0, int(xp))
    n = int((1 + math.sqrt(1 + 8 * xp / 100)) / 2)
    start, end = 50 * n * (n - 1), 50 * (n + 1) * n
    return {"level": n, "xp_in_level": xp - start, "xp_for_level": end - start}


def goal_for_minutes(minutes: int | None) -> int:
    return GOAL_BY_MINUTES.get(minutes or 0, DEFAULT_GOAL_XP)


ACHIEVEMENTS: list[dict] = [
    {"code": "first_lesson", "emoji": "🎒", "title": "Первый урок", "desc": "Заверши свой первый урок", "tickets": 1,
     "test": lambda s: s["lessons"] >= 1},
    {"code": "first_trip", "emoji": "🛫", "title": "Первый рейс", "desc": "Пройди первую локацию", "tickets": 2,
     "test": lambda s: s["locations"] >= 1},
    {"code": "globetrotter", "emoji": "🌍", "title": "Глобтроттер", "desc": "Посети 5 локаций", "tickets": 5,
     "test": lambda s: s["locations"] >= 5},
    {"code": "streak_3", "emoji": "🔥", "title": "Разогрев", "desc": "Стрик 3 дня", "tickets": 1,
     "test": lambda s: s["streak"] >= 3},
    {"code": "streak_7", "emoji": "🚀", "title": "Неделя огня", "desc": "Стрик 7 дней", "tickets": 3,
     "test": lambda s: s["streak"] >= 7},
    {"code": "streak_30", "emoji": "👑", "title": "Железная воля", "desc": "Стрик 30 дней", "tickets": 10,
     "test": lambda s: s["streak"] >= 30},
    {"code": "xp_500", "emoji": "⚡", "title": "500 XP", "desc": "Набери 500 XP", "tickets": 2,
     "test": lambda s: s["xp"] >= 500},
    {"code": "perfect", "emoji": "💎", "title": "Без единой ошибки", "desc": "Пройди урок без ошибок", "tickets": 1,
     "test": lambda s: s["perfect"] >= 1},
    {"code": "words_25", "emoji": "🧠", "title": "Память как у слона", "desc": "Выучи 25 слов (интервал ≥ 21 дня)",
     "tickets": 5, "test": lambda s: s["mastered"] >= 25},
]
ACH_BY_CODE = {a["code"]: a for a in ACHIEVEMENTS}


def newly_earned(stats: dict, have: set[str]) -> list[dict]:
    return [a for a in ACHIEVEMENTS if a["code"] not in have and a["test"](stats)]


def public_achievement(a: dict, earned: bool) -> dict:
    return {"code": a["code"], "emoji": a["emoji"], "title": a["title"], "desc": a["desc"],
            "tickets": a["tickets"], "earned": earned}
