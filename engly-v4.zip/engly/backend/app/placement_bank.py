"""Банк вопросов адаптивного теста уровня.

Шкала сложности θ: A1 = [0,1), A2 = [1,2), B1 = [2,3), B2 = [3,4), C1 = [4,5), C2 = [5,6).
Внутри уровня вопросы разнесены по сложности (b = уровень + 0.15 … +0.85).
Формат: (kind, prompt, instruction, correct, [wrong, wrong, wrong])
  kind: "tr"    — перевод слова/фразы EN → RU
        "cloze" — подставь пропущенное слово (опции на английском)
"""

_TR = "Выбери перевод"
_CL = "Выбери подходящее слово"

RAW: dict[str, list[tuple]] = {
    "A1": [
        ("tr", "apple", _TR, "яблоко", ["стол", "окно", "собака"]),
        ("cloze", "I ___ a student.", _CL, "am", ["is", "are", "be"]),
        ("tr", "Where is the toilet?", _TR, "Где туалет?", ["Сколько это стоит?", "Который час?", "Как тебя зовут?"]),
        ("cloze", "She ___ two brothers.", _CL, "has", ["have", "is", "are"]),
        ("tr", "Nice to meet you", _TR, "Приятно познакомиться", ["Спокойной ночи", "До завтра", "Как дела"]),
        ("cloze", "There ___ three books on the table.", _CL, "are", ["is", "am", "be"]),
        ("tr", "What time is it?", _TR, "Который час?", ["Какой сегодня день?", "Где ты живёшь?", "Что это такое?"]),
        ("cloze", "My sister ___ to school every day.", _CL, "goes", ["go", "going", "is go"]),
        ("cloze", "___ you like tea?", _CL, "Do", ["Does", "Are", "Is"]),
        ("cloze", "I live ___ Moscow.", _CL, "in", ["at", "on", "to"]),
    ],
    "A2": [
        ("tr", "luggage", _TR, "багаж", ["билет", "паспорт", "очередь"]),
        ("cloze", "Yesterday we ___ to the cinema.", _CL, "went", ["go", "goes", "gone"]),
        ("cloze", "My brother is ___ than me.", _CL, "taller", ["more tall", "tallest", "the tall"]),
        ("tr", "Could you tell me the way to the station?", _TR, "Не подскажете, как пройти к вокзалу?",
         ["Во сколько отходит поезд?", "Вы не видели мой билет?", "Где ближайшая остановка автобуса?"]),
        ("cloze", "We ___ dinner when the phone rang.", _CL, "were having", ["have", "had been", "are having"]),
        ("cloze", "How ___ sugar do you want in your coffee?", _CL, "much", ["many", "long", "often"]),
        ("cloze", "I have lived here ___ 2020.", _CL, "since", ["for", "from", "during"]),
        ("tr", "discount", _TR, "скидка", ["чек", "сдача", "касса"]),
        ("cloze", "If it rains tomorrow, we ___ at home.", _CL, "will stay", ["would stay", "stayed", "staying"]),
        ("cloze", "She asked me ___ I was from.", _CL, "where", ["who", "which", "whose"]),
    ],
    "B1": [
        ("tr", "reliable", _TR, "надёжный", ["разумный", "заметный", "доступный"]),
        ("cloze", "If I ___ more time, I would learn Spanish.", _CL, "had", ["have", "will have", "would have"]),
        ("cloze", "The film was so boring that I ___ asleep.", _CL, "fell", ["felt", "fall", "have fallen"]),
        ("cloze", "She suggested ___ to the museum.", _CL, "going", ["to go", "go", "went"]),
        ("tr", "to postpone", _TR, "откладывать", ["отменять", "отправлять", "оставлять"]),
        ("cloze", "I'm not used to ___ up so early.", _CL, "getting", ["get", "got", "have got"]),
        ("cloze", "He asked me what time ___.", _CL, "it was", ["was it", "it is being", "has it been"]),
        ("cloze", "By the time we arrived, the film ___.", _CL, "had already started",
         ["already started", "has already started", "was already start"]),
        ("tr", "to depend on", _TR, "зависеть от", ["настаивать на", "отказываться от", "соглашаться с"]),
        ("cloze", "This is the girl ___ brother works at our school.", _CL, "whose", ["who", "which", "whom"]),
    ],
    "B2": [
        ("cloze", "Had I known about the traffic, I ___ earlier.", _CL, "would have left",
         ["will leave", "would leave", "had left"]),
        ("tr", "to overlook (a detail)", _TR, "упустить из виду", ["тщательно проверить", "строго наказать", "подробно описать"]),
        ("cloze", "She is said ___ the best lawyer in the city.", _CL, "to be", ["being", "be", "that is"]),
        ("cloze", "I'd rather you ___ smoke here.", _CL, "didn't", ["don't", "wouldn't", "not"]),
        ("cloze", "Not only ___ late, but he also forgot the documents.", _CL, "was he", ["he was", "has he", "did he be"]),
        ("tr", "reluctant", _TR, "неохотный", ["упрямый", "осторожный", "нетерпеливый"]),
        ("cloze", "The project, ___ was delayed twice, was finally finished.", _CL, "which", ["what", "who", "whose"]),
        ("cloze", "He insisted that she ___ the meeting.", _CL, "attend", ["attends", "attended", "would attending"]),
        ("cloze", "Despite ___ tired, she kept working.", _CL, "being", ["she was", "to be", "of being"]),
        ("tr", "to make ends meet", _TR, "сводить концы с концами",
         ["выходить на пенсию", "подводить итоги", "находить компромисс"]),
    ],
    "C1": [
        ("tr", "ubiquitous", _TR, "вездесущий", ["двусмысленный", "неизбежный", "устаревший"]),
        ("cloze", "No sooner had she left ___ the phone rang.", _CL, "than", ["when", "as", "before"]),
        ("cloze", "The CEO, ___ resignation shocked everyone, remained silent.", _CL, "whose", ["who's", "of whom", "whom"]),
        ("tr", "to scrutinize", _TR, "тщательно изучать", ["поспешно одобрять", "кратко пересказывать", "публично критиковать"]),
        ("cloze", "It is high time we ___ a decision.", _CL, "made", ["make", "will make", "are making"]),
        ("cloze", "The new law will come ___ effect next month.", _CL, "into", ["in", "at", "on"]),
        ("tr", "to alleviate", _TR, "облегчать, смягчать", ["усугублять", "отрицать", "предвидеть"]),
        ("cloze", "Hardly ___ the room when the lights went out.", _CL, "had she entered",
         ["she had entered", "did she enter", "she entered"]),
        ("cloze", "His argument was ___ flawed; it fell apart under scrutiny.", _CL, "fundamentally",
         ["fundamental", "fundamentals", "fundament"]),
        ("tr", "to be at odds with", _TR, "противоречить, расходиться с",
         ["быть в восторге от", "находиться рядом с", "зависеть от"]),
    ],
    "C2": [
        ("tr", "obsequious", _TR, "подобострастный", ["высокомерный", "дотошный", "словоохотливый"]),
        ("cloze", "The results are, to say the least, ___; nobody expected them.", _CL, "counterintuitive",
         ["counterintuition", "counterintuitively", "counterintuit"]),
        ("tr", "to exacerbate", _TR, "усугублять", ["смягчать", "предвидеть", "исключать"]),
        ("cloze", "Little ___ she know that the truth would soon emerge.", _CL, "did", ["does", "had", "would"]),
        ("tr", "tantamount to", _TR, "равносильный", ["противоположный", "предшествующий", "сопутствующий"]),
        ("cloze", "The committee, together with its advisers, ___ yet to reach a verdict.", _CL, "has", ["have", "are", "were"]),
        ("tr", "equivocal", _TR, "двусмысленный, уклончивый", ["однозначный", "безразличный", "равноправный"]),
        ("cloze", "Notwithstanding the objections, the motion ___ carried.", _CL, "was", ["were", "been", "being"]),
        ("tr", "to eschew", _TR, "избегать, сознательно воздерживаться", ["воспевать", "разрушать", "заимствовать"]),
        ("cloze", "So ___ was the evidence that the jury needed only minutes to decide.", _CL, "compelling",
         ["compellingly", "compelled", "compel"]),
    ],
}

LEVELS = ["A1", "A2", "B1", "B2", "C1", "C2"]


def build_bank() -> dict[str, dict]:
    """id -> вопрос с числовой сложностью b."""
    bank: dict[str, dict] = {}
    for li, lvl in enumerate(LEVELS):
        items = RAW[lvl]
        for k, (kind, prompt, instr, correct, wrong) in enumerate(items):
            qid = f"{lvl}-{k + 1:02d}"
            b = li + 0.15 + 0.7 * k / (len(items) - 1)
            bank[qid] = {"id": qid, "level": lvl, "b": round(b, 3), "kind": kind, "prompt": prompt,
                         "instr": instr, "correct": correct, "wrong": wrong}
    return bank


BANK = build_bank()
