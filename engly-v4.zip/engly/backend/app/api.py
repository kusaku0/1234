"""REST API Engly — тонкий слой над services.py (вся логика и проверки — там)."""
import json

from aiogram import Bot
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from . import services as svc
from .auth import current_user
from .bot import create_invoice_link
from .db import database
from .plans import BEST_PLAN, PLANS, first_price

router = APIRouter(prefix="/api")

_bot: Bot | None = None
_bot_username: str | None = None


def set_bot(bot: Bot) -> None:
    global _bot
    _bot = bot


async def _get_bot_username() -> str | None:
    global _bot_username
    if _bot_username or _bot is None:
        return _bot_username
    try:
        _bot_username = (await _bot.me()).username
    except Exception:  # noqa: BLE001
        return None
    return _bot_username


def uid(user: dict) -> int:
    return int(user["id"])


# ---------- профиль / главная ----------
@router.get("/profile")
async def profile(user: dict = Depends(current_user)):
    p = await svc.profile(uid(user), user.get("username"))
    p["bot_username"] = await _get_bot_username()
    return p


@router.get("/locations")
async def locations(user: dict = Depends(current_user)):
    return await svc.locations(uid(user))


@router.get("/wordofday")
async def word_of_day(user: dict = Depends(current_user)):
    return await svc.word_of_day(uid(user))


# ---------- адаптивный тест ----------
@router.get("/placement")
async def placement_status(user: dict = Depends(current_user)):
    p = await svc.profile(uid(user), user.get("username"))
    return {"done": p["onboarded"]}


class PlacementStart(BaseModel):
    goal: str | None = None
    minutes: int | None = None


@router.post("/placement/start")
async def placement_start(body: PlacementStart, user: dict = Depends(current_user)):
    return await svc.placement_start(uid(user), body.goal, body.minutes)


@router.post("/placement/skip")
async def placement_skip(body: PlacementStart, user: dict = Depends(current_user)):
    return await svc.placement_skip(uid(user), body.goal, body.minutes)


class PlacementAnswer(BaseModel):
    session_id: str
    question_id: str
    answer: str | None = Field(default=None, max_length=200)


@router.post("/placement/answer")
async def placement_answer(body: PlacementAnswer, user: dict = Depends(current_user)):
    return await svc.placement_answer(uid(user), body.session_id, body.question_id, body.answer)


# ---------- уроки ----------
class LessonStart(BaseModel):
    level: str | None = None
    topic: str | None = None
    mode: str = "path"   # path | practice | review | drill
    kind: str | None = None


@router.get("/path")
async def path(user: dict = Depends(current_user)):
    return await svc.path(uid(user))


@router.get("/lesson/resume")
async def lesson_resume(user: dict = Depends(current_user)):
    return {"lesson": await svc.lesson_resume(uid(user))}


@router.get("/lesson/state")
async def lesson_state(session_id: str, user: dict = Depends(current_user)):
    return await svc.lesson_state(uid(user), session_id)


@router.get("/practice")
async def practice(user: dict = Depends(current_user)):
    return await svc.practice(uid(user))


@router.get("/vocab")
async def vocab(user: dict = Depends(current_user)):
    return await svc.vocab(uid(user))


@router.post("/lesson/start")
async def lesson_start(body: LessonStart, user: dict = Depends(current_user)):
    mode = body.mode if body.mode in ("path", "practice", "review", "drill") else "path"
    return await svc.lesson_start(uid(user), body.level, body.topic, mode, body.kind)


class PairIn(BaseModel):
    session_id: str
    idx: int
    en: str = Field(max_length=100)
    ru: str = Field(max_length=100)


@router.post("/lesson/pair")
async def lesson_pair(body: PairIn, user: dict = Depends(current_user)):
    return await svc.lesson_pair(uid(user), body.session_id, body.idx, body.en, body.ru)


class LessonAnswer(BaseModel):
    session_id: str
    idx: int
    answer: str | None = Field(default=None, max_length=300)
    ms: int | None = None   # время ответа, мс — влияет на SRS


@router.post("/lesson/answer")
async def lesson_answer(body: LessonAnswer, user: dict = Depends(current_user)):
    return await svc.lesson_answer(uid(user), body.session_id, body.idx, body.answer, body.ms)


class SessionRef(BaseModel):
    session_id: str


@router.post("/lesson/finish")
async def lesson_finish(body: SessionRef, user: dict = Depends(current_user)):
    return await svc.lesson_finish(uid(user), body.session_id)


# ---------- локации ----------
class LocStart(BaseModel):
    loc_id: str


@router.post("/location/start")
async def location_start(body: LocStart, user: dict = Depends(current_user)):
    return await svc.location_start(uid(user), body.loc_id)


class LocChoose(BaseModel):
    session_id: str
    node_id: str
    idx: int


@router.post("/location/choose")
async def location_choose(body: LocChoose, user: dict = Depends(current_user)):
    return await svc.location_choose(uid(user), body.session_id, body.node_id, body.idx)


# ---------- магазин, ошибки ----------
@router.post("/shop/freeze")
async def shop_freeze(user: dict = Depends(current_user)):
    return await svc.buy_freeze(uid(user))


@router.post("/mistakes/analysis")
async def mistakes_analysis(user: dict = Depends(current_user)):
    return await svc.mistakes(uid(user))


# ---------- аккаунт ----------
@router.delete("/account")
async def delete_account(user: dict = Depends(current_user)):
    """Удаляет прогресс и профиль текущего пользователя (только свои данные: id берётся из подписанного initData)."""
    return await svc.delete_account(uid(user))


# ---------- события ----------
class EventIn(BaseModel):
    name: str
    payload: dict | None = None


ALLOWED_EVENTS = {"app_open", "speak_used", "speak_skipped", "listen_fallback", "paywall_view",
                  "onboarding_step", "globe_flight", "sound_toggle", "theme_toggle", "drill_open"}


@router.post("/event")
async def event(body: EventIn, user: dict = Depends(current_user)):
    if body.name not in ALLOWED_EVENTS:
        raise HTTPException(status_code=400, detail="unknown event")
    payload = body.payload if body.payload and len(json.dumps(body.payload)) < 500 else None
    await database.log_event(body.name, uid(user), payload)
    return {"ok": True}


# ---------- оплата ----------
class InvoiceIn(BaseModel):
    plan: str


@router.post("/invoice")
async def invoice(body: InvoiceIn, user: dict = Depends(current_user)):
    tg_id = uid(user)
    if body.plan not in PLANS or _bot is None:
        raise HTTPException(status_code=400 if body.plan not in PLANS else 503, detail="нет тарифа/бот не запущен")
    await database.log_event("paywall_view", tg_id, {"plan": body.plan})
    stars = None
    if body.plan == BEST_PLAN and not await database.has_payments(tg_id):
        stars = first_price(PLANS[BEST_PLAN].stars)
    try:
        link = await create_invoice_link(_bot, body.plan, tg_id, stars=stars)
    except Exception as e:  # noqa: BLE001
        raise HTTPException(status_code=503, detail=f"бот недоступен: {type(e).__name__}")
    return {"link": link}


@router.get("/plans")
async def plans(user: dict = Depends(current_user)):
    first = not await database.has_payments(uid(user))
    return {
        "plans": [
            {"id": p.id, "days": p.days, "stars": p.stars, "title": p.title,
             "first_price": first_price(p.stars) if (first and p.id == BEST_PLAN) else None}
            for p in PLANS.values()
        ],
        "best": BEST_PLAN,
    }
