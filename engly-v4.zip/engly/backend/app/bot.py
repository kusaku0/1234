"""Бот Engly: /start с онбордингом, рефералка, оплата звёздами, слово дня."""
import logging
import secrets as _secrets
from datetime import datetime, timezone

from aiogram import Bot, F, Router
from aiogram.filters import Command, CommandObject
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    Message,
    PreCheckoutQuery,
    ReplyKeyboardRemove,
    WebAppInfo,
)

from .config import settings
from .db import MSK, database
from .locations import LOCATIONS
from .plans import BEST_PLAN, PLANS, first_price

log = logging.getLogger("engly.bot")

router = Router()

def welcome_text() -> str:
    return (
        "🦉 <b>Engly — английский с нуля, по одному слову</b>\n\n"
        "Привет! Здесь не нужно ничего знать заранее: каждое слово приходит с картинкой, звуком и примером, "
        "а потом закрепляется в простых играх.\n\n"
        "🌱 <b>Короткие уроки</b> — по 3 новых слова, 3–5 минут\n"
        "🔁 <b>Умные повторения</b> — слова возвращаются, пока не запомнятся\n"
        f"🌍 <b>{len(LOCATIONS)} локаций мира</b> — Париж, Токио, Нью-Йорк… говори в живых диалогах\n"
        "🔥 Серии, XP и билеты ✈️ · светлая и тёмная тема\n\n"
        f"Бесплатно — {settings.free_limit} заданий в день. Подписка снимает дневной лимит.\n\n"
        "👇 Жми <b>«🚀 Учиться»</b> — приложение откроется прямо в Telegram. "
        "Можно начать с нуля или пройти тест уровня — как удобнее."
    )


def main_keyboard() -> InlineKeyboardMarkup | None:
    if not settings.webapp_url:
        return None
    return InlineKeyboardMarkup(
        inline_keyboard=[[InlineKeyboardButton(
            text="🚀 Учиться", web_app=WebAppInfo(url=settings.webapp_url)
        )]]
    )


@router.message(Command("start"))
async def cmd_start(m: Message, command: CommandObject):
    source = command.args[:64] if command and command.args else None
    was_new = (await database.get_user(m.from_user.id)) is None
    await database.upsert_user(m.from_user.id, m.from_user.username)
    await database.log_event("start", m.from_user.id, {"source": source})

    if was_new and source and source.startswith("ref_") and source[4:].isdigit():
        ref_id = int(source[4:])
        if ref_id != m.from_user.id and await database.get_user(ref_id):
            await database.grant_ref_bonus(m.from_user.id)
            await database.grant_ref_bonus(ref_id)
            await database.log_event("ref_join", ref_id, {"invited": m.from_user.id})
            try:
                await m.bot.send_message(
                    ref_id,
                    "🎁 По твоей ссылке пришёл друг!\nВам обоим +5 заданий в день на неделю. Приглашай ещё!",
                )
            except Exception:  # noqa: BLE001
                pass

    try:
        gone = await m.answer("\u2063", reply_markup=ReplyKeyboardRemove())
        await gone.delete()
    except Exception:  # noqa: BLE001
        pass
    await m.answer(welcome_text(), reply_markup=main_keyboard())


@router.message(Command("word"))
async def cmd_word(m: Message):
    from .content import BANK

    user = await database.get_user(m.from_user.id)
    level = user["level"] if user else "A1"
    import random

    topics = list(BANK[level].keys())
    en, ru, ph, ph_ru = random.choice(BANK[level][random.choice(topics)])
    await m.answer(f"📖 Слово дня ({level}):\n\n<b>{en}</b> — {ru}\n<i>{ph}</i>\n({ph_ru})")


@router.message(Command("paysupport"))
async def cmd_paysupport(m: Message):
    await m.answer(
        "💳 Поддержка по платежам Engly\n\nЕсли оплата прошла, но доступ не открылся — подождите минуту и "
        "перезапустите приложение. Если это не помогло, пришлите скриншот чека из Telegram (Настройки → Telegram Stars) "
        "в ответ на это сообщение — мы разберёмся и при необходимости вернём звёзды."
    )


def _expected_amounts(plan_id: str, first_time: bool) -> set[int]:
    plan = PLANS[plan_id]
    ok = {plan.stars}
    if plan_id == BEST_PLAN and first_time:
        ok.add(first_price(plan.stars))
    return ok


async def _alert_admin(bot: Bot, text: str) -> None:
    if not settings.admin_id:
        return
    try:
        await bot.send_message(settings.admin_id, text, parse_mode=None)
    except Exception:  # noqa: BLE001
        log.warning("не удалось уведомить администратора")


@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery):
    """Telegram спрашивает «можно списать?». Отвечаем «да» только на счёт, который выставили мы: известный тариф,
    Stars, владелец счёта = плательщик, сумма = цене тарифа (или скидке первой покупки)."""
    try:
        plan_id, _, owner = q.invoice_payload.partition(":")
        ok = (
            plan_id in PLANS and q.currency == "XTR" and owner == str(q.from_user.id)
            and q.total_amount in _expected_amounts(plan_id, not await database.has_payments(q.from_user.id))
        )
    except Exception:  # noqa: BLE001
        ok = False
    await q.answer(ok=ok, error_message=None if ok else "Ошибка тарифа, попробуйте ещё раз")


@router.message(F.successful_payment)
async def paid(m: Message):
    """Деньги уже списаны, поэтому здесь доступ выдаётся всегда, когда платёж распознан. Повторная доставка
    уведомления (тот же charge_id) Premium второй раз не продлевает."""
    sp = m.successful_payment
    plan_id, _, owner = sp.invoice_payload.partition(":")
    plan = PLANS.get(plan_id)
    if not plan or sp.currency != "XTR":
        log.error("неизвестный платёж: %s %s %s", sp.invoice_payload, sp.currency, sp.total_amount)
        await _alert_admin(m.bot, f"⚠️ Платёж не распознан: user={m.from_user.id} payload={sp.invoice_payload} "
                                  f"{sp.total_amount} {sp.currency} charge={sp.telegram_payment_charge_id}")
        await m.answer("Платёж получен, но тариф не распознан. Напишите /paysupport — мы разберёмся и вернём звёзды.")
        return
    if owner != str(m.from_user.id):
        log.warning("плательщик %s ≠ владелец счёта %s", m.from_user.id, owner)
    until = await database.apply_payment(m.from_user.id, plan_id, plan.days, sp.total_amount, sp.telegram_payment_charge_id)
    if until is None:
        return      # этот платёж уже был обработан
    await database.log_event("pay", m.from_user.id, {"plan": plan_id, "stars": sp.total_amount})
    await m.answer(
        f"✅ Оплата прошла! Доступ без дневного лимита до {until.astimezone(MSK).strftime('%d.%m.%Y %H:%M')} (МСК). "
        f"Учись без остановки!"
    )


@router.message(F.refunded_payment)
async def refunded(m: Message):
    """Возврат Stars: снимаем оплаченные дни Premium."""
    rp = m.refunded_payment
    res = await database.refund_payment(rp.telegram_payment_charge_id, {k: v.days for k, v in PLANS.items()})
    if res is None:
        return
    tg_id, new_end = res
    await database.log_event("refund", tg_id, {"charge": rp.telegram_payment_charge_id})
    await m.answer("Возврат звёзд оформлен. Дневной лимит снова действует, когда закончится оплаченный период."
                   if new_end else "Возврат звёзд оформлен. Бесплатный режим: дневной лимит заданий.")


async def create_invoice_link(bot: Bot, plan_id: str, tg_id: int, stars: int | None = None) -> str:
    p = PLANS[plan_id]
    return await bot.create_invoice_link(
        title=f"Engly: без дневного лимита, {p.title}",
        description="Доступ без дневного лимита заданий и безлимитный разбор ошибок. Разовая оплата, без автопродления.",
        payload=f"{plan_id}:{tg_id}",
        provider_token="",
        currency="XTR",
        prices=[LabeledPrice(label=p.title, amount=stars or p.stars)],
    )
