"""Адаптивный тест уровня (упрощённая IRT-модель 3PL + байесовская оценка EAP).

Идея (как в EF SET / Duolingo English Test, но на 15 вопросов):
  • Способность пользователя θ ∈ [0, 6) — это «уровень» в долях CEFR (A1=0…C2=5…6).
  • Вероятность верного ответа на вопрос сложности b:
        P(θ) = c + (1 − c) · σ(a·(θ − b)),  c = 0.25 (угадывание из 4 вариантов), a = 1.3
  • После каждого ответа обновляем апостериорное распределение θ на сетке (EAP):
        post(θ) ∝ prior(θ) · Π P(θ) | верно  или  (1 − P(θ)) | неверно
  • Следующий вопрос — тот, что даёт максимум информации Фишера при текущем θ̂
    (то есть сложность ≈ θ̂: верно → сложнее, неверно → легче).
  • Стоп: ≥10 вопросов и SD(θ) ≤ 0.5, либо 15 вопросов.
Состояние сессии — только список ответов; всё остальное пересчитывается (stateless, легко тестировать).
"""
import math
import random
from dataclasses import dataclass

from .placement_bank import BANK, LEVELS

A = 1.3          # дискриминация
C = 0.25         # вероятность угадать
GRID = [round(-0.5 + 0.1 * i, 1) for i in range(71)]   # θ от −0.5 до 6.5
PRIOR_MEAN, PRIOR_SD = 2.5, 1.6
MIN_Q, MAX_Q, TARGET_SD = 10, 15, 0.5
START_THETA = 0.6   # первый вопрос — лёгкий A1: новичок не должен сразу увидеть «непонятное»


def p_correct(theta: float, b: float) -> float:
    return C + (1 - C) / (1 + math.exp(-A * (theta - b)))


def fisher_info(theta: float, b: float) -> float:
    p = p_correct(theta, b)
    q = 1 - p
    return (A ** 2) * (q / p) * ((p - C) / (1 - C)) ** 2


@dataclass
class Estimate:
    theta: float
    sd: float


def estimate(answers: list[dict]) -> Estimate:
    """answers: [{'b': float, 'ok': bool}] -> EAP-оценка θ и её неопределённость."""
    logpost = [-0.5 * ((t - PRIOR_MEAN) / PRIOR_SD) ** 2 for t in GRID]
    for ans in answers:
        for i, t in enumerate(GRID):
            p = p_correct(t, ans["b"])
            logpost[i] += math.log(p if ans["ok"] else 1 - p)
    m = max(logpost)
    w = [math.exp(x - m) for x in logpost]
    s = sum(w)
    mean = sum(t * wi for t, wi in zip(GRID, w)) / s
    var = sum(((t - mean) ** 2) * wi for t, wi in zip(GRID, w)) / s
    return Estimate(theta=mean, sd=math.sqrt(var))


def is_finished(answers: list[dict]) -> bool:
    n = len(answers)
    if n >= MAX_Q:
        return True
    return n >= MIN_Q and estimate(answers).sd <= TARGET_SD


def pick_next(answers: list[dict], asked: set[str], rng: random.Random | None = None) -> dict | None:
    """Вопрос с макс. информацией; из топ-3 случайный (чтобы тест не был одинаковым).
    Не ставим подряд 3 вопроса одного типа (перевод/грамматика)."""
    rng = rng or random
    theta = estimate(answers).theta if answers else START_THETA
    pool = [q for q in BANK.values() if q["id"] not in asked]
    if not pool:
        return None
    last_kinds = [a.get("kind") for a in answers[-2:]]
    if len(last_kinds) == 2 and last_kinds[0] == last_kinds[1]:
        alt = [q for q in pool if q["kind"] != last_kinds[0]]
        pool = alt or pool
    pool.sort(key=lambda q: fisher_info(theta, q["b"]), reverse=True)
    return rng.choice(pool[:3])


def level_of(theta: float) -> str:
    return LEVELS[max(0, min(5, int(math.floor(theta))))]


def confidence(sd: float, n: int) -> str:
    if n >= MIN_Q and sd <= 0.5:
        return "high"
    if sd <= 0.7:
        return "medium"
    return "low"


def summarize(answers: list[dict]) -> dict:
    est = estimate(answers)
    by_kind: dict[str, list[int]] = {}
    by_level: dict[str, list[int]] = {}
    for a in answers:
        by_kind.setdefault(a["kind"], []).append(1 if a["ok"] else 0)
        by_level.setdefault(a["level"], []).append(1 if a["ok"] else 0)
    lvl = level_of(est.theta)
    return {
        "level": lvl,
        "theta": round(est.theta, 2),
        "sd": round(est.sd, 2),
        "confidence": confidence(est.sd, len(answers)),
        "answered": len(answers),
        "correct": sum(1 for a in answers if a["ok"]),
        "by_kind": {k: round(sum(v) / len(v), 2) for k, v in by_kind.items()},
        "by_level": {k: [sum(v), len(v)] for k, v in sorted(by_level.items())},
        "progress_in_level": round(est.theta - math.floor(est.theta), 2),
    }
