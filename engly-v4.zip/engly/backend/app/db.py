"""SQLite-хранилище Engly: юзеры, прогресс, стрики, платежи, события."""
import asyncio
import json
import secrets
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

import aiosqlite

from .config import settings

MSK = ZoneInfo("Europe/Moscow")

REF_BONUS_FREE = 5
REF_BONUS_DAYS = 7


def utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def msk_today() -> str:
    return datetime.now(MSK).date().isoformat()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  tg_id INTEGER PRIMARY KEY,
  username TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  level TEXT DEFAULT 'A1',
  quiz_done INTEGER NOT NULL DEFAULT 0,
  xp INTEGER NOT NULL DEFAULT 0,
  streak_days INTEGER NOT NULL DEFAULT 0,
  last_study_day TEXT,
  premium_until TEXT,
  ref_bonus_until TEXT
);
CREATE TABLE IF NOT EXISTS daily_usage(
  tg_id INTEGER NOT NULL,
  day TEXT NOT NULL,
  tasks INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (tg_id, day)
);
CREATE TABLE IF NOT EXISTS answers_log(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id INTEGER NOT NULL,
  item_en TEXT NOT NULL,
  is_correct INTEGER NOT NULL,
  mode TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS lesson_progress(
  tg_id INTEGER NOT NULL,
  level TEXT NOT NULL,
  topic TEXT NOT NULL,
  lessons_done INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (tg_id, level, topic)
);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id INTEGER NOT NULL,
  plan TEXT NOT NULL,
  stars INTEGER NOT NULL,
  telegram_payment_charge_id TEXT UNIQUE,
  created_at TEXT DEFAULT (datetime('now')),
  refunded INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS events(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id INTEGER,
  name TEXT NOT NULL,
  payload TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_events_name ON events(name);
CREATE INDEX IF NOT EXISTS idx_events_user ON events(tg_id, name);
CREATE INDEX IF NOT EXISTS idx_answers_user ON answers_log(tg_id, item_en);
CREATE TABLE IF NOT EXISTS srs_cards(
  tg_id INTEGER NOT NULL,
  item_en TEXT NOT NULL,
  level TEXT NOT NULL,
  topic TEXT NOT NULL DEFAULT '',
  ru TEXT NOT NULL DEFAULT '',
  phrase TEXT NOT NULL DEFAULT '',
  phrase_ru TEXT NOT NULL DEFAULT '',
  src TEXT NOT NULL DEFAULT 'bank',
  ease REAL NOT NULL DEFAULT 2.5,
  interval REAL NOT NULL DEFAULT 0,
  reps INTEGER NOT NULL DEFAULT 0,
  lapses INTEGER NOT NULL DEFAULT 0,
  due_at TEXT NOT NULL,
  last_at TEXT,
  PRIMARY KEY (tg_id, item_en)
);
CREATE INDEX IF NOT EXISTS idx_srs_due ON srs_cards(tg_id, due_at);
CREATE TABLE IF NOT EXISTS sessions(
  id TEXT PRIMARY KEY,
  tg_id INTEGER NOT NULL,
  kind TEXT NOT NULL,
  state TEXT NOT NULL,
  finished INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(tg_id, kind);
CREATE TABLE IF NOT EXISTS achievements(
  tg_id INTEGER NOT NULL,
  code TEXT NOT NULL,
  earned_at TEXT DEFAULT (datetime('now')),
  PRIMARY KEY (tg_id, code)
);
CREATE TABLE IF NOT EXISTS location_progress(
  tg_id INTEGER NOT NULL,
  loc_id TEXT NOT NULL,
  stars INTEGER NOT NULL DEFAULT 0,
  runs INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (tg_id, loc_id)
);
"""

USER_COLUMNS = {
    "free_analysis_day": "TEXT",
    "goal": "TEXT",
    "daily_minutes": "INTEGER",
    "daily_goal": "INTEGER NOT NULL DEFAULT 30",
    "tickets": "INTEGER NOT NULL DEFAULT 0",
    "freezes": "INTEGER NOT NULL DEFAULT 0",
    "perfect_lessons": "INTEGER NOT NULL DEFAULT 0",
    "theta": "REAL",
    "placement_sd": "REAL",
}
USAGE_COLUMNS = {"xp": "INTEGER NOT NULL DEFAULT 0", "goal_hit": "INTEGER NOT NULL DEFAULT 0"}


def streak_view(streak: int, last_day: str | None, freezes: int) -> tuple[int, bool]:
    """Что показывать пользователю: (стрик, занимался ли сегодня). Если пропущено больше дня (и заморозка не спасёт),
    серия уже сгорела — раньше профиль показывал старое число до следующего занятия."""
    if not last_day or streak <= 0:
        return 0, False
    d = datetime.now(MSK).date()
    if last_day == d.isoformat():
        return streak, True
    if last_day == (d - timedelta(days=1)).isoformat():
        return streak, False
    if last_day == (d - timedelta(days=2)).isoformat() and freezes > 0:
        return streak, False
    return 0, False


def iso(dt: datetime) -> str:
    """Единый формат времени в БД (UTC, без микросекунд) — строки сравнимы лексикографически."""
    return dt.astimezone(timezone.utc).replace(microsecond=0).isoformat()


class Database:
    def __init__(self, path: str):
        self.path = path
        self.db: aiosqlite.Connection | None = None
        # одно соединение на всё приложение: многошаговые записи (платежи) выполняем под замком,
        # чтобы commit/rollback одного запроса не захватывал чужие незавершённые изменения
        self.lock = asyncio.Lock()
        self._known: set[int] = set()   # пользователи, которых уже создали в этом процессе

    async def connect(self) -> None:
        self._known.clear()
        self.db = await aiosqlite.connect(self.path)
        self.db.row_factory = sqlite3.Row
        await self.db.execute("PRAGMA journal_mode=WAL")
        await self.db.executescript(SCHEMA)
        await self._ensure_columns("users", USER_COLUMNS)
        await self._ensure_columns("daily_usage", USAGE_COLUMNS)
        # миграция: в старом банке тема называлась « small talk» (с пробелом)
        await self.db.execute("UPDATE lesson_progress SET topic='Small talk' WHERE topic=' small talk'")
        await self.db.commit()

    async def _ensure_columns(self, table: str, cols: dict[str, str]) -> None:
        have = {r["name"] for r in await (await self.db.execute(f"PRAGMA table_info({table})")).fetchall()}
        for name, ddl in cols.items():
            if name not in have:
                await self.db.execute(f"ALTER TABLE {table} ADD COLUMN {name} {ddl}")
        await self.db.commit()

    async def close(self) -> None:
        if self.db:
            await self.db.close()

    # ---- users ----
    async def upsert_user(self, tg_id: int, username: str | None) -> None:
        await self.db.execute(
            "INSERT INTO users(tg_id, username) VALUES(?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username",
            (tg_id, username),
        )
        await self.db.commit()

    async def ensure_user(self, tg_id: int, username: str | None) -> None:
        """Создаёт запись пользователя один раз за жизнь процесса (раньше upsert + commit шли на каждый запрос)."""
        if tg_id in self._known:
            return
        await self.upsert_user(tg_id, username)
        if len(self._known) > 100_000:
            self._known.clear()
        self._known.add(tg_id)

    async def delete_user(self, tg_id: int) -> None:
        """Полное удаление данных пользователя. Записи об оплатах остаются (бухгалтерия и возвраты Telegram Stars)."""
        async with self.lock:
            for table in ("srs_cards", "sessions", "achievements", "location_progress", "lesson_progress",
                          "answers_log", "daily_usage", "events"):
                await self.db.execute(f"DELETE FROM {table} WHERE tg_id=?", (tg_id,))
            await self.db.execute("DELETE FROM users WHERE tg_id=?", (tg_id,))
            await self.db.commit()
        self._known.discard(tg_id)

    async def get_user(self, tg_id: int) -> sqlite3.Row | None:
        cur = await self.db.execute("SELECT * FROM users WHERE tg_id=?", (tg_id,))
        return await cur.fetchone()

    def is_premium(self, user: sqlite3.Row | None) -> bool:
        if not user or not user["premium_until"]:
            return False
        try:
            return datetime.fromisoformat(user["premium_until"]) > datetime.now(timezone.utc)
        except ValueError:
            return False

    async def extend_premium(self, tg_id: int, days: int, conn: aiosqlite.Connection | None = None) -> datetime:
        """Продлевает Premium: если подписка ещё идёт, дни добавляются к её концу (остаток не теряется)."""
        c = conn or self.db
        row = await (await c.execute("SELECT premium_until FROM users WHERE tg_id=?", (tg_id,))).fetchone()
        now = datetime.now(timezone.utc)
        base = now
        if row and row["premium_until"]:
            try:
                cur_end = datetime.fromisoformat(row["premium_until"])
                if cur_end > now:
                    base = cur_end
            except ValueError:
                pass
        new_end = base + timedelta(days=days)
        await c.execute(
            "INSERT INTO users(tg_id, premium_until) VALUES(?,?) "
            "ON CONFLICT(tg_id) DO UPDATE SET premium_until=excluded.premium_until",
            (tg_id, iso(new_end)),
        )
        if conn is None:
            await c.commit()
        return new_end

    # ---- стрик, XP, билеты ----
    async def touch_streak(self, tg_id: int) -> dict:
        """Засчитывает «учился сегодня». Пропуск ровно одного дня прощается, если есть заморозка ❄️.
        Возвращает {streak, new_day, freeze_used}."""
        user = await self.get_user(tg_id)
        if not user:
            return {"streak": 0, "new_day": False, "freeze_used": False}
        today = msk_today()
        last = user["last_study_day"]
        if last == today:
            return {"streak": user["streak_days"], "new_day": False, "freeze_used": False}
        d = datetime.now(MSK).date()
        yesterday, before = (d - timedelta(days=1)).isoformat(), (d - timedelta(days=2)).isoformat()
        freeze_used, freezes = False, user["freezes"]
        if last == yesterday:
            streak = user["streak_days"] + 1
        elif last == before and freezes > 0 and user["streak_days"] > 0:
            streak, freezes, freeze_used = user["streak_days"] + 1, freezes - 1, True
        else:
            streak = 1
        await self.db.execute(
            "UPDATE users SET streak_days=?, last_study_day=?, freezes=? WHERE tg_id=?",
            (streak, today, freezes, tg_id),
        )
        await self.db.commit()
        return {"streak": streak, "new_day": True, "freeze_used": freeze_used}

    async def add_xp(self, tg_id: int, xp: int) -> dict:
        """Атомарно начисляет XP (общий и дневной). Возвращает {xp, today_xp, goal, goal_just_hit}."""
        today = msk_today()
        await self.db.execute(
            "INSERT INTO daily_usage(tg_id, day, tasks, xp) VALUES(?,?,0,?) "
            "ON CONFLICT(tg_id, day) DO UPDATE SET xp=xp+excluded.xp", (tg_id, today, xp))
        await self.db.execute("UPDATE users SET xp=xp+? WHERE tg_id=?", (xp, tg_id))
        user = await self.get_user(tg_id)
        row = await (await self.db.execute(
            "SELECT xp, goal_hit FROM daily_usage WHERE tg_id=? AND day=?", (tg_id, today))).fetchone()
        goal = user["daily_goal"] or 30
        just_hit = bool(row["xp"] >= goal and not row["goal_hit"])
        if just_hit:
            await self.db.execute("UPDATE daily_usage SET goal_hit=1 WHERE tg_id=? AND day=?", (tg_id, today))
        await self.db.commit()
        return {"xp": user["xp"], "today_xp": row["xp"], "goal": goal, "goal_just_hit": just_hit}

    async def daily_status(self, tg_id: int) -> dict:
        user = await self.get_user(tg_id)
        row = await (await self.db.execute(
            "SELECT xp, tasks FROM daily_usage WHERE tg_id=? AND day=?", (tg_id, msk_today()))).fetchone()
        return {"today_xp": row["xp"] if row else 0, "goal": (user["daily_goal"] if user else 30) or 30}

    async def add_tickets(self, tg_id: int, n: int) -> None:
        if n:
            await self.db.execute("UPDATE users SET tickets=tickets+? WHERE tg_id=?", (n, tg_id))
            await self.db.commit()

    async def spend_tickets(self, tg_id: int, n: int) -> bool:
        cur = await self.db.execute(
            "UPDATE users SET tickets=tickets-? WHERE tg_id=? AND tickets>=?", (n, tg_id, n))
        await self.db.commit()
        return cur.rowcount > 0

    # ---- SRS ----
    async def srs_get(self, tg_id: int, en: str) -> sqlite3.Row | None:
        cur = await self.db.execute("SELECT * FROM srs_cards WHERE tg_id=? AND item_en=?", (tg_id, en))
        return await cur.fetchone()

    async def srs_record(self, tg_id: int, info: dict, correct: bool, ms: int | None = None) -> dict:
        """Пересчитывает карточку после ответа. info: {en, level, topic, ru, phrase, phrase_ru, src?}."""
        from .srs import Card, schedule

        now = datetime.now(timezone.utc)
        row = await self.srs_get(tg_id, info["en"])
        card = Card(ease=row["ease"], interval=row["interval"], reps=row["reps"], lapses=row["lapses"]) if row else Card()
        # В одном уроке слово встречается в 4–5 заданиях: интервал растёт не чаще раза в 4 часа,
        # иначе за один урок слово «выучилось бы» на недели. Ошибка учитывается всегда.
        if correct and row and row["reps"] >= 1 and row["last_at"]:
            try:
                last = datetime.fromisoformat(row["last_at"])
                if last.tzinfo is None:
                    last = last.replace(tzinfo=timezone.utc)
                if now - last < timedelta(hours=4):
                    return {"interval": row["interval"], "reps": row["reps"], "lapses": row["lapses"], "due_at": row["due_at"], "held": True}
            except ValueError:
                pass
        new = schedule(card, correct, now, ms)
        await self.db.execute(
            "INSERT INTO srs_cards(tg_id,item_en,level,topic,ru,phrase,phrase_ru,src,ease,interval,reps,lapses,due_at,last_at) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(tg_id,item_en) DO UPDATE SET "
            "ease=excluded.ease, interval=excluded.interval, reps=excluded.reps, lapses=excluded.lapses, "
            "due_at=excluded.due_at, last_at=excluded.last_at",
            (tg_id, info["en"], info["level"], info.get("topic", ""), info["ru"], info["phrase"], info["phrase_ru"],
             info.get("src", "bank"), new.ease, new.interval, new.reps, new.lapses, iso(new.due_at), iso(now)))
        await self.db.commit()
        return {"interval": new.interval, "reps": new.reps, "lapses": new.lapses, "due_at": iso(new.due_at)}

    async def srs_add_cards(self, tg_id: int, cards: list[dict], first_due_hours: int = 20) -> int:
        """Добавляет карточки (напр. ключевые фразы локации) без изменения уже существующих."""
        due = iso(datetime.now(timezone.utc) + timedelta(hours=first_due_hours))
        n = 0
        for c in cards:
            cur = await self.db.execute(
                "INSERT OR IGNORE INTO srs_cards(tg_id,item_en,level,topic,ru,phrase,phrase_ru,src,due_at) "
                "VALUES(?,?,?,?,?,?,?,?,?)",
                (tg_id, c["en"], c["level"], c.get("topic", ""), c["ru"], c["phrase"], c["phrase_ru"], c.get("src", "location"), due))
            n += cur.rowcount
        await self.db.commit()
        return n

    async def srs_due(self, tg_id: int, limit: int = 20) -> list[dict]:
        cur = await self.db.execute(
            "SELECT item_en AS en, level, topic, ru, phrase, phrase_ru, reps, lapses, interval FROM srs_cards "
            "WHERE tg_id=? AND due_at<=? ORDER BY due_at ASC LIMIT ?", (tg_id, iso(datetime.now(timezone.utc)), limit))
        return [dict(r) for r in await cur.fetchall()]

    async def srs_known(self, tg_id: int, level: str, topic: str) -> dict[str, dict]:
        cur = await self.db.execute(
            "SELECT item_en AS en, reps, lapses, interval FROM srs_cards WHERE tg_id=? AND level=? AND topic=?",
            (tg_id, level, topic))
        return {r["en"]: dict(r) for r in await cur.fetchall()}

    async def srs_all(self, tg_id: int) -> list[dict]:
        cur = await self.db.execute(
            "SELECT item_en AS en, level, topic, ru, phrase, phrase_ru, reps, lapses, interval, due_at FROM srs_cards "
            "WHERE tg_id=? ORDER BY last_at DESC, item_en", (tg_id,))
        return [dict(r) for r in await cur.fetchall()]

    async def srs_pool(self, tg_id: int, limit: int = 40) -> list[dict]:
        """Знакомые карточки (reps>=1) — для пар и тренировок."""
        cur = await self.db.execute(
            "SELECT item_en AS en, level, topic, ru, phrase, phrase_ru, reps, lapses, interval FROM srs_cards "
            "WHERE tg_id=? AND reps>=1 ORDER BY last_at DESC LIMIT ?", (tg_id, limit))
        return [dict(r) for r in await cur.fetchall()]

    async def path_progress(self, tg_id: int) -> dict[tuple[str, str], int]:
        cur = await self.db.execute("SELECT level, topic, lessons_done FROM lesson_progress WHERE tg_id=?", (tg_id,))
        return {(r["level"], r["topic"]): r["lessons_done"] for r in await cur.fetchall()}

    async def srs_stats(self, tg_id: int) -> dict:
        row = await (await self.db.execute(
            "SELECT COUNT(*) total, "
            "COALESCE(SUM(due_at<=?),0) due, "
            "COALESCE(SUM(interval>=21),0) mastered, "
            "COALESCE(SUM(lapses>=4),0) leeches FROM srs_cards WHERE tg_id=?",
            (iso(datetime.now(timezone.utc)), tg_id))).fetchone()
        return {"total": row["total"], "due": row["due"], "mastered": row["mastered"], "leeches": row["leeches"]}

    async def srs_status_counts(self, tg_id: int) -> dict:
        """Те же статусы, что в словаре: выучено (интервал ≥ 21 дня) / новое (ни одного верного ответа) / учу."""
        row = await (await self.db.execute(
            "SELECT COALESCE(SUM(interval>=21),0) m, COALESCE(SUM(interval<21 AND reps=0),0) n, "
            "COALESCE(SUM(interval<21 AND reps>0),0) l FROM srs_cards WHERE tg_id=?", (tg_id,))).fetchone()
        return {"new": row["n"], "learning": row["l"], "mastered": row["m"]}

    # ---- сессии (урок / тест / локация): состояние на сервере, клиенту доверять нельзя ----
    async def session_create(self, tg_id: int, kind: str, state: dict) -> str:
        sid = secrets.token_urlsafe(9)
        await self.db.execute(
            "INSERT INTO sessions(id,tg_id,kind,state,created_at) VALUES(?,?,?,?,?)",
            (sid, tg_id, kind, json.dumps(state, ensure_ascii=False), iso(datetime.now(timezone.utc))))
        await self.db.commit()
        return sid

    async def session_get(self, sid: str, tg_id: int, kind: str) -> tuple[dict, bool] | None:
        cur = await self.db.execute(
            "SELECT state, finished FROM sessions WHERE id=? AND tg_id=? AND kind=?", (sid, tg_id, kind))
        row = await cur.fetchone()
        return (json.loads(row["state"]), bool(row["finished"])) if row else None

    async def session_open_latest(self, tg_id: int, kind: str, max_age_h: int = 12) -> tuple[str, dict] | None:
        """Последняя незавершённая сессия (для восстановления урока после закрытия приложения)."""
        cur = await self.db.execute(
            "SELECT id, state, created_at FROM sessions WHERE tg_id=? AND kind=? AND finished=0 ORDER BY created_at DESC LIMIT 1", (tg_id, kind))
        row = await cur.fetchone()
        if not row:
            return None
        try:
            if datetime.now(timezone.utc) - datetime.fromisoformat(row["created_at"]) > timedelta(hours=max_age_h):
                return None
        except ValueError:
            return None
        return row["id"], json.loads(row["state"])

    async def session_save(self, sid: str, state: dict, finished: bool = False) -> None:
        await self.db.execute("UPDATE sessions SET state=?, finished=? WHERE id=?",
                              (json.dumps(state, ensure_ascii=False), 1 if finished else 0, sid))
        await self.db.commit()

    async def session_cleanup(self, days: int = 3) -> None:
        await self.db.execute("DELETE FROM sessions WHERE created_at<?", (iso(datetime.now(timezone.utc) - timedelta(days=days)),))
        await self.db.commit()

    # ---- достижения и локации ----
    async def ach_have(self, tg_id: int) -> set[str]:
        cur = await self.db.execute("SELECT code FROM achievements WHERE tg_id=?", (tg_id,))
        return {r["code"] for r in await cur.fetchall()}

    async def ach_add(self, tg_id: int, code: str) -> bool:
        cur = await self.db.execute("INSERT OR IGNORE INTO achievements(tg_id, code) VALUES(?,?)", (tg_id, code))
        await self.db.commit()
        return cur.rowcount > 0

    async def loc_progress(self, tg_id: int) -> dict[str, dict]:
        cur = await self.db.execute("SELECT loc_id, stars, runs FROM location_progress WHERE tg_id=?", (tg_id,))
        return {r["loc_id"]: {"stars": r["stars"], "runs": r["runs"]} for r in await cur.fetchall()}

    async def loc_record(self, tg_id: int, loc_id: str, stars: int) -> bool:
        """Фиксирует прохождение; True — если это первое прохождение локации."""
        prev = (await self.loc_progress(tg_id)).get(loc_id)
        await self.db.execute(
            "INSERT INTO location_progress(tg_id, loc_id, stars, runs) VALUES(?,?,?,1) "
            "ON CONFLICT(tg_id, loc_id) DO UPDATE SET runs=runs+1, stars=MAX(stars, excluded.stars)",
            (tg_id, loc_id, stars))
        await self.db.commit()
        return prev is None

    async def stats_for_achievements(self, tg_id: int) -> dict:
        user = await self.get_user(tg_id)
        lessons = (await (await self.db.execute(
            "SELECT COALESCE(SUM(lessons_done),0) n FROM lesson_progress WHERE tg_id=?", (tg_id,))).fetchone())["n"]
        locs = (await (await self.db.execute(
            "SELECT COUNT(*) n FROM location_progress WHERE tg_id=?", (tg_id,))).fetchone())["n"]
        return {"lessons": lessons, "locations": locs, "streak": user["streak_days"], "xp": user["xp"],
                "perfect": user["perfect_lessons"], "mastered": (await self.srs_stats(tg_id))["mastered"]}

    # ---- дневной лимит ----
    def _limit_with_bonus(self, user: sqlite3.Row | None) -> tuple[int, bool]:
        limit = settings.free_limit
        if user and user["ref_bonus_until"]:
            try:
                if datetime.fromisoformat(user["ref_bonus_until"]) > datetime.now(timezone.utc):
                    return limit + REF_BONUS_FREE, True
            except ValueError:
                pass
        return limit, False

    async def tasks_left(self, tg_id: int) -> int:
        cur = await self.db.execute(
            "SELECT tasks FROM daily_usage WHERE tg_id=? AND day=?", (tg_id, msk_today())
        )
        row = await cur.fetchone()
        used = row["tasks"] if row else 0
        limit, _ = self._limit_with_bonus(await self.get_user(tg_id))
        return max(0, limit - used)

    async def count_task(self, tg_id: int) -> None:
        await self.db.execute(
            "INSERT INTO daily_usage(tg_id, day, tasks) VALUES(?,?,1) "
            "ON CONFLICT(tg_id, day) DO UPDATE SET tasks=tasks+1",
            (tg_id, msk_today()),
        )
        await self.db.commit()

    async def grant_ref_bonus(self, tg_id: int) -> datetime:
        user = await self.get_user(tg_id)
        now = datetime.now(timezone.utc)
        base = now
        if user and user["ref_bonus_until"]:
            try:
                cur_end = datetime.fromisoformat(user["ref_bonus_until"])
                if cur_end > base:
                    base = cur_end
            except ValueError:
                pass
        until = base + timedelta(days=REF_BONUS_DAYS)
        await self.db.execute("UPDATE users SET ref_bonus_until=? WHERE tg_id=?", (until.isoformat(), tg_id))
        await self.db.commit()
        return until

    # ---- платежи ----
    async def _pay_conn(self) -> aiosqlite.Connection:
        """Отдельное соединение для денег: commit/rollback платежа не затрагивает чужие незавершённые записи."""
        conn = await aiosqlite.connect(self.path)
        conn.row_factory = sqlite3.Row
        await conn.execute("PRAGMA busy_timeout=8000")
        return conn

    async def apply_payment(self, tg_id: int, plan: str, days: int, stars: int, charge_id: str) -> datetime | None:
        """Идемпотентно: повторная доставка того же платежа (тот же charge_id) Premium второй раз не продлевает."""
        async with self.lock:
            conn = await self._pay_conn()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                cur = await conn.execute(
                    "INSERT OR IGNORE INTO payments(tg_id, plan, stars, telegram_payment_charge_id) VALUES(?,?,?,?)",
                    (tg_id, plan, stars, charge_id),
                )
                if cur.rowcount == 0:
                    await conn.rollback()
                    return None
                until = await self.extend_premium(tg_id, days, conn)
                await conn.commit()
                return until
            except Exception:
                await conn.rollback()
                raise
            finally:
                await conn.close()

    async def refund_payment(self, charge_id: str, days_of: dict[str, int]) -> tuple[int, datetime | None] | None:
        """Возврат Stars: платёж помечается возвращённым, оплаченные дни снимаются (но не глубже «сейчас»).
        None — платёж неизвестен или уже обработан."""
        async with self.lock:
            conn = await self._pay_conn()
            try:
                await conn.execute("BEGIN IMMEDIATE")
                row = await (await conn.execute(
                    "SELECT tg_id, plan FROM payments WHERE telegram_payment_charge_id=? AND refunded=0", (charge_id,))).fetchone()
                if not row:
                    await conn.rollback()
                    return None
                await conn.execute("UPDATE payments SET refunded=1 WHERE telegram_payment_charge_id=?", (charge_id,))
                u = await (await conn.execute("SELECT premium_until FROM users WHERE tg_id=?", (row["tg_id"],))).fetchone()
                new_end = None
                if u and u["premium_until"]:
                    try:
                        new_end = datetime.fromisoformat(u["premium_until"]) - timedelta(days=days_of.get(row["plan"], 0))
                    except ValueError:
                        new_end = None
                    if new_end is not None:
                        if new_end <= datetime.now(timezone.utc):
                            new_end = None
                        await conn.execute("UPDATE users SET premium_until=? WHERE tg_id=?",
                                           (iso(new_end) if new_end else None, row["tg_id"]))
                await conn.commit()
                return row["tg_id"], new_end
            except Exception:
                await conn.rollback()
                raise
            finally:
                await conn.close()

    async def has_payments(self, tg_id: int) -> bool:
        cur = await self.db.execute(
            "SELECT 1 FROM payments WHERE tg_id=? AND refunded=0 LIMIT 1", (tg_id,)
        )
        return await cur.fetchone() is not None

    # ---- события ----
    async def log_event(self, name: str, tg_id: int | None = None, payload: dict | None = None) -> None:
        await self.db.execute(
            "INSERT INTO events(tg_id, name, payload) VALUES(?,?,?)",
            (tg_id, name, json.dumps(payload, ensure_ascii=False) if payload else None),
        )
        await self.db.commit()

    async def has_event(self, tg_id: int, name: str) -> bool:
        cur = await self.db.execute("SELECT 1 FROM events WHERE tg_id=? AND name=? LIMIT 1", (tg_id, name))
        return await cur.fetchone() is not None

    async def has_event_date(self, tg_id: int, name: str, day: str) -> bool:
        cur = await self.db.execute(
            "SELECT 1 FROM events WHERE tg_id=? AND name=? AND json_extract(payload,'$.day')=? LIMIT 1",
            (tg_id, name, day),
        )
        return await cur.fetchone() is not None

    # ---- бесплатный разбор ошибок: 1 в день ----
    async def analysis_used_today(self, tg_id: int) -> bool:
        row = await self.get_user(tg_id)
        return bool(row and row["free_analysis_day"] == msk_today())

    async def mark_analysis_used(self, tg_id: int) -> None:
        await self.db.execute("UPDATE users SET free_analysis_day=? WHERE tg_id=?", (msk_today(), tg_id))
        await self.db.commit()

    async def active_learners(self, days: int = 7) -> list[sqlite3.Row]:
        cur = await self.db.execute(
            "SELECT tg_id, level, streak_days FROM users WHERE last_study_day >= ?",
            ((datetime.now(MSK).date() - timedelta(days=days)).isoformat(),),
        )
        return await cur.fetchall()


database = Database(settings.db_path)


def ensure_db_file() -> None:
    Path(settings.db_path).parent.mkdir(parents=True, exist_ok=True)
