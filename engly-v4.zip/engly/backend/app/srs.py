"""Интервальные повторения (SRS) — адаптация SM-2 под двоичный ответ «верно/неверно».

Карточка = слово/фраза пользователя. Состояние: ease (лёгкость), interval (дни), reps (верных подряд),
lapses (сколько раз забыл), due_at (когда показать).

Правила:
  • Ошибка        → reps=0, lapses+1, ease−0.2 (мин 1.3), due через 10 минут («зона повторения»:
                    слово вернётся в этом же уроке, а затем в следующем).
  • Верно         → reps+1; 1-й раз интервал 1 день, 2-й — 3 дня, дальше interval·ease.
  • Скорость      → быстро (<3 c) ease+0.1 («знаю уверенно»), медленно (>8 c) ease−0.14.
  • Пиявка (leech)→ lapses ≥ 4: слово помечено «трудным», показывается чаще (интервал ≤ 2 дней).
  • Выучено       → interval ≥ 21 дня.
"""
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone

MIN_EASE, START_EASE, MAX_INTERVAL = 1.3, 2.5, 180.0
RELEARN_MIN = 10
LEECH_LAPSES = 4
MASTERED_DAYS = 21.0


@dataclass(frozen=True)
class Card:
    ease: float = START_EASE
    interval: float = 0.0   # дни
    reps: int = 0
    lapses: int = 0
    due_at: datetime | None = None


def schedule(card: Card, correct: bool, now: datetime | None = None, ms: int | None = None) -> Card:
    now = now or datetime.now(timezone.utc)
    if not correct:
        return replace(card, reps=0, lapses=card.lapses + 1, interval=0.0,
                       ease=max(MIN_EASE, card.ease - 0.2), due_at=now + timedelta(minutes=RELEARN_MIN))
    ease = card.ease
    if ms is not None:
        if ms < 3000:
            ease += 0.1
        elif ms > 8000:
            ease -= 0.14
    ease = max(MIN_EASE, min(3.0, ease))
    reps = card.reps + 1
    if reps == 1:
        interval = 1.0
    elif reps == 2:
        interval = 3.0
    else:
        interval = round(max(card.interval, 3.0) * ease, 1)
    if card.lapses >= LEECH_LAPSES:
        interval = min(interval, 2.0)
    interval = min(interval, MAX_INTERVAL)
    return replace(card, ease=ease, reps=reps, interval=interval, due_at=now + timedelta(days=interval))


def is_leech(lapses: int) -> bool:
    return lapses >= LEECH_LAPSES


def is_mastered(interval: float) -> bool:
    return interval >= MASTERED_DAYS
