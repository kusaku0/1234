"""Тесты Engly v4.0: платежи, защита от двойных наград, диалоги, стрик, удаление аккаунта, авторизация Telegram,
изоляция пользователей через HTTP, миграция БД старых пользователей.
Запуск: cd backend && python -m pytest -q
"""
import asyncio
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from types import SimpleNamespace
from urllib.parse import urlencode

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import httpx  # noqa: E402

from app import auth, locations as L, services as svc  # noqa: E402
from app.config import settings  # noqa: E402
from app.db import MSK, database as db, iso, streak_view  # noqa: E402
from app.plans import PLANS  # noqa: E402
from test_engine import fresh_db, mk_user, right_answer  # noqa: E402

TOKEN = "123456:TEST_TOKEN_FOR_UNIT_TESTS"


def run(coro):
    return asyncio.run(coro)


def make_init_data(user_id, token=TOKEN, auth_date=None, username="tester"):
    fields = {"auth_date": str(auth_date if auth_date is not None else int(time.time())), "query_id": "AAHtest",
              "user": json.dumps({"id": user_id, "first_name": "T", "username": username})}
    check = "\n".join(f"{k}={v}" for k, v in sorted(fields.items()))
    secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
    fields["hash"] = hmac.new(secret, check.encode(), hashlib.sha256).hexdigest()
    return urlencode(fields)


# ------------------------------------------------------------------ авторизация Telegram
def test_init_data_verification():
    good = make_init_data(7)
    assert auth.verify_init_data(good, TOKEN, 3600)["user"]
    assert auth.verify_init_data(good, "999:OTHER", 3600) is None                       # чужой токен бота
    assert auth.verify_init_data(good.replace("tester", "hacker"), TOKEN, 3600) is None   # подмена данных
    assert auth.verify_init_data(make_init_data(7, auth_date=int(time.time()) - 10 * 86400), TOKEN, 86400) is None   # просрочено
    assert auth.verify_init_data(good.replace("auth_date=", "auth_date=x"), TOKEN, 3600) is None   # мусор вместо даты → None, не 500
    assert auth.verify_init_data(good + "&hash=" + "я" * 8, TOKEN, 3600) is None          # не-ASCII в hash → None, не 500
    assert auth.verify_init_data("", TOKEN, 3600) is None


def test_dev_mode_never_works_on_production_host():
    old = (settings.dev_mode, settings.base_url)
    try:
        settings.dev_mode, settings.base_url = True, "https://engly.example.com/engly"
        assert not settings.dev_allowed                 # DEV_MODE=1 на боевом домене — вход под чужим id невозможен
        settings.base_url = "http://localhost:8002"
        assert settings.dev_allowed
        settings.dev_mode = False
        assert not settings.dev_allowed
    finally:
        settings.dev_mode, settings.base_url = old


def test_rate_limit():
    uid = 987654
    assert all(auth.check_rate(uid, now=1000.0) for _ in range(auth.RATE_LIMIT))
    assert not auth.check_rate(uid, now=1000.5)
    assert auth.check_rate(uid, now=1000.0 + auth.RATE_WINDOW + 1)


# ------------------------------------------------------------------ платежи
async def scenario_payments():
    await fresh_db()
    await db.upsert_user(1, "p")
    u1 = await db.apply_payment(1, "d7", 7, 49, "ch-1")
    assert u1 and db.is_premium(await db.get_user(1))
    assert await db.apply_payment(1, "d7", 7, 49, "ch-1") is None                      # повторное уведомление
    assert (await db.get_user(1))["premium_until"] == iso(u1)                          # доступ не продлён второй раз
    u2 = await db.apply_payment(1, "d14", 14, 89, "ch-2")                              # продление: остаток не теряется
    assert abs((u2 - u1) - timedelta(days=14)) < timedelta(seconds=2)
    # шесть одновременных доставок одного платежа → ровно одно начисление
    res = await asyncio.gather(*[db.apply_payment(1, "d30", 30, 149, "ch-3") for _ in range(6)])
    assert sum(r is not None for r in res) == 1
    assert (await (await db.db.execute("SELECT COUNT(*) n FROM payments WHERE tg_id=1")).fetchone())["n"] == 3
    # возврат одного платежа снимает его дни, второй раз возврат не сработает
    before = datetime.fromisoformat((await db.get_user(1))["premium_until"])
    tg, new_end = await db.refund_payment("ch-3", {k: p.days for k, p in PLANS.items()})
    assert tg == 1 and abs((before - new_end) - timedelta(days=30)) < timedelta(seconds=2)
    assert await db.refund_payment("ch-3", {}) is None
    # окончание Premium: пользователь снова на бесплатном лимите
    await db.db.execute("UPDATE users SET premium_until=? WHERE tg_id=1", (iso(datetime.now(timezone.utc) - timedelta(days=1)),))
    await db.db.commit()
    assert not db.is_premium(await db.get_user(1))
    assert (await svc.profile(1))["is_premium"] is False and await db.tasks_left(1) == settings.free_limit
    print("payments ok")


def test_payments():
    run(scenario_payments())


class FakeMsg:
    def __init__(self, uid, payload, amount, charge, currency="XTR"):
        self.from_user = SimpleNamespace(id=uid)
        self.successful_payment = SimpleNamespace(invoice_payload=payload, total_amount=amount, currency=currency,
                                                  telegram_payment_charge_id=charge)
        self.bot = SimpleNamespace(send_message=self._noop)
        self.sent = []

    async def _noop(self, *a, **k):
        return None

    async def answer(self, text, **k):
        self.sent.append(text)


class FakeQuery:
    def __init__(self, uid, payload, amount, currency="XTR"):
        self.from_user = SimpleNamespace(id=uid)
        self.invoice_payload, self.total_amount, self.currency = payload, amount, currency
        self.ok = None

    async def answer(self, ok, error_message=None):
        self.ok = ok


async def scenario_bot_payment_handlers():
    from app import bot as botmod
    await fresh_db()
    await db.upsert_user(5, "b")
    # pre_checkout: свой счёт и верная сумма — да; чужой владелец, не та сумма, не Stars, неизвестный тариф — нет
    for q, expect in [(FakeQuery(5, "d7:5", 49), True), (FakeQuery(5, "d7:6", 49), False), (FakeQuery(5, "d7:5", 1), False),
                      (FakeQuery(5, "d7:5", 49, "USD"), False), (FakeQuery(5, "zzz:5", 49), False),
                      (FakeQuery(5, "d30:5", PLANS["d30"].stars * 80 // 100), True)]:
        await botmod.pre_checkout(q)
        assert q.ok is expect, (q.invoice_payload, q.total_amount)
    # успешная оплата
    m = FakeMsg(5, "d7:5", 49, "c-A")
    await botmod.paid(m)
    assert db.is_premium(await db.get_user(5)) and m.sent and "Оплата прошла" in m.sent[0]
    until = (await db.get_user(5))["premium_until"]
    m2 = FakeMsg(5, "d7:5", 49, "c-A")           # Telegram повторил уведомление
    await botmod.paid(m2)
    assert (await db.get_user(5))["premium_until"] == until and not m2.sent
    # неизвестный тариф / не Stars: доступ не выдаётся, пользователь получает объяснение
    for bad in (FakeMsg(5, "xx:5", 10, "c-B"), FakeMsg(5, "d7:5", 49, "c-C", currency="USD")):
        await botmod.paid(bad)
        assert bad.sent and "не распознан" in bad.sent[0]
    assert (await db.get_user(5))["premium_until"] == until
    # тексты оплаты не обещают того, чего нет
    assert "Все миры" not in " ".join(botmod.welcome_text().split()) and str(settings.free_limit) in botmod.welcome_text()
    print("bot payment handlers ok")


def test_bot_payment_handlers():
    run(scenario_bot_payment_handlers())


# ------------------------------------------------------------------ награды не начисляются дважды
async def scenario_no_double_reward():
    await fresh_db()
    await mk_user(11)
    await db.extend_premium(11, 30)
    st = await svc.lesson_start(11, "A1", "Приветствия", "path", None)
    sid = st["session_id"]
    state, _ = await db.session_get(sid, 11, "lesson")
    assert state["tasks"][0]["type"] == "intro"
    await svc.lesson_answer(11, sid, 0, "seen", 1000)
    t1 = state["tasks"][1]
    xp0 = (await db.get_user(11))["xp"]
    # двойной тап: два одновременных запроса с одним и тем же заданием
    res = await asyncio.gather(*[svc.lesson_answer(11, sid, 1, right_answer(t1), 1500) for _ in range(5)], return_exceptions=True)
    ok = [r for r in res if isinstance(r, dict)]
    dup = [r for r in res if isinstance(r, svc.ApiError) and r.status == 409]
    assert len(ok) == 1 and len(dup) == 4
    assert (await db.get_user(11))["xp"] == xp0 + t1["xp"]
    assert ok[0]["correct_value"] == right_answer(t1)                                   # клиент подсвечивает точное совпадение
    # проходим остаток и завершаем урок несколько раз одновременно
    state, _ = await db.session_get(sid, 11, "lesson")
    for i in range(2, len(state["tasks"])):
        t = state["tasks"][i]
        if t["type"] == "match":
            for pr in t["pairs"]:
                await svc.lesson_pair(11, sid, i, pr["en"], pr["ru"])
        await svc.lesson_answer(11, sid, i, right_answer(t), 2000)
    fin = await asyncio.gather(*[svc.lesson_finish(11, sid) for _ in range(5)])
    assert all(f == fin[0] for f in fin)
    u = await db.get_user(11)
    assert u["tickets"] == fin[0]["tickets"] - 0 or u["tickets"] >= 1
    first_xp = u["xp"]
    again = await svc.lesson_finish(11, sid)
    assert (await db.get_user(11))["xp"] == first_xp and again == fin[0]                 # повтор finish ничего не начисляет
    assert (await db.path_progress(11)).get(("A1", "Приветствия"), 0) == 1             # урок засчитан один раз
    print("no double reward ok")


def test_no_double_reward():
    run(scenario_no_double_reward())


# ------------------------------------------------------------------ диалог в локации не обрывается лимитом
async def scenario_location_never_cut():
    await fresh_db()
    await db.upsert_user(41, "l")
    await db.db.execute("UPDATE users SET level='A1', quiz_done=1 WHERE tg_id=41")
    for tp in ("Приветствия", "Еда и напитки", "Числа и цвета", "Знакомство", "Я и ты"):
        await db.db.execute("INSERT OR REPLACE INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(41,'A1',?,3)", (tp,))
    await db.db.execute("INSERT INTO daily_usage(tg_id, day, tasks) VALUES(41, ?, ?)", (datetime.now(MSK).date().isoformat(), settings.free_limit - 1))
    await db.db.commit()
    assert await db.tasks_left(41) == 1
    st = await svc.location_start(41, "nyc_park")            # остался 1 бесплатный шаг — запуск разрешён
    node, steps = st["node"], 0
    while True:
        r = await svc.location_choose(41, st["session_id"], node["id"], 0)     # раньше на 2-й реплике: 402 limit
        steps += 1
        if r["done"]:
            break
        node = r["node"]
    assert steps >= 2
    try:                                                      # а вот новый запуск при пустом лимите — запрещён
        await svc.location_start(41, "nyc_park"); assert False
    except svc.ApiError as e:
        assert e.status == 402
    print("location never cut ok, steps", steps)


def test_location_never_cut():
    run(scenario_location_never_cut())


# ------------------------------------------------------------------ стрик, удаление, старые пользователи
def test_streak_view():
    d = datetime.now(MSK).date()
    day = lambda n: (d - timedelta(days=n)).isoformat()   # noqa: E731
    assert streak_view(7, day(0), 0) == (7, True)
    assert streak_view(7, day(1), 0) == (7, False)
    assert streak_view(7, day(2), 0) == (0, False)        # пропущен день без заморозки — серия сгорела
    assert streak_view(7, day(2), 1) == (7, False)        # заморозка спасёт при следующем занятии
    assert streak_view(7, day(5), 2) == (0, False)
    assert streak_view(0, None, 0) == (0, False)


async def scenario_delete_and_isolation():
    await fresh_db()
    for tg in (21, 22):
        await mk_user(tg)
        await db.extend_premium(tg, 30)
    st = await svc.lesson_start(21, "A1", "Приветствия", "path", None)
    await svc.lesson_answer(21, st["session_id"], 0, "seen", 100)
    await db.apply_payment(21, "d7", 7, 49, "del-1")
    await db.apply_payment(22, "d7", 7, 49, "del-2")
    # чужую сессию использовать нельзя
    try:
        await svc.lesson_answer(22, st["session_id"], 1, "x", 100); assert False
    except svc.ApiError as e:
        assert e.status == 404
    assert await svc.delete_account(21) == {"deleted": True}
    assert await db.get_user(21) is None and (await db.srs_stats(21))["total"] == 0
    assert await db.session_get(st["session_id"], 21, "lesson") is None
    assert (await db.get_user(22)) is not None and db.is_premium(await db.get_user(22))      # чужие данные не тронуты
    assert (await (await db.db.execute("SELECT COUNT(*) n FROM payments WHERE tg_id=21")).fetchone())["n"] == 1   # учёт оплат сохранён
    p = await svc.profile(21, "again")                       # после удаления — чистый аккаунт
    assert p["onboarded"] is False and p["xp"] == 0 and p["is_premium"] is False
    print("delete + isolation ok")


def test_delete_and_isolation():
    run(scenario_delete_and_isolation())


async def scenario_returning_user_keeps_progress():
    await fresh_db()
    await mk_user(31, "B1")
    await db.db.execute("UPDATE users SET xp=420, streak_days=3, last_study_day=?, goal='work', daily_minutes=10 WHERE tg_id=31",
                        (datetime.now(MSK).date().isoformat(),))
    await db.db.execute("INSERT INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(31,'B1','Путешествия',2)")
    await db.db.commit()
    await db.srs_add_cards(31, [{"en": "journey", "ru": "поездка", "phrase": "A long journey", "phrase_ru": "Долгая поездка", "level": "B1"}])
    before = await svc.profile(31, "x")
    db._known.clear()                                        # «повторный вход» в новом процессе
    again = await svc.profile(31, "x")
    assert {k: before[k] for k in ("xp", "level", "streak", "goal", "minutes", "onboarded")} == {k: again[k] for k in ("xp", "level", "streak", "goal", "minutes", "onboarded")}
    r = await svc.placement_skip(31, "fun", 5)               # «я новичок» не затирает уровень и цель
    assert r["level"] == "B1"
    u = await db.get_user(31)
    assert u["level"] == "B1" and u["goal"] == "work" and u["daily_minutes"] == 10
    assert (await db.path_progress(31))[("B1", "Путешествия")] == 2 and (await db.srs_stats(31))["total"] == 1
    print("returning user ok")


def test_returning_user_keeps_progress():
    run(scenario_returning_user_keeps_progress())


async def scenario_migration_from_v3():
    """БД старой версии (без новых колонок) открывается без потери данных."""
    path = os.path.join(tempfile.mkdtemp(), "old.db")
    con = sqlite3.connect(path)
    con.executescript("""
        CREATE TABLE users(tg_id INTEGER PRIMARY KEY, username TEXT, created_at TEXT DEFAULT (datetime('now')), level TEXT DEFAULT 'A1',
            quiz_done INTEGER NOT NULL DEFAULT 0, xp INTEGER NOT NULL DEFAULT 0, streak_days INTEGER NOT NULL DEFAULT 0,
            last_study_day TEXT, premium_until TEXT, ref_bonus_until TEXT);
        CREATE TABLE daily_usage(tg_id INTEGER NOT NULL, day TEXT NOT NULL, tasks INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (tg_id, day));
        CREATE TABLE lesson_progress(tg_id INTEGER NOT NULL, level TEXT NOT NULL, topic TEXT NOT NULL, lessons_done INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (tg_id, level, topic));
        CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, tg_id INTEGER NOT NULL, plan TEXT NOT NULL, stars INTEGER NOT NULL,
            telegram_payment_charge_id TEXT UNIQUE, created_at TEXT DEFAULT (datetime('now')), refunded INTEGER NOT NULL DEFAULT 0);
        INSERT INTO users(tg_id, username, level, quiz_done, xp, streak_days, premium_until) VALUES (77, 'old', 'A2', 1, 640, 4, '2099-01-01T00:00:00.123456+00:00');
        INSERT INTO lesson_progress VALUES (77, 'A1', 'Приветствия', 3), (77, 'A1', ' small talk', 1);
        INSERT INTO payments(tg_id, plan, stars, telegram_payment_charge_id) VALUES (77, 'd30', 149, 'old-charge');
    """)
    con.commit(); con.close()
    db.path = path
    await db.connect()
    u = await db.get_user(77)
    assert (u["level"], u["xp"], u["streak_days"]) == ("A2", 640, 4) and u["freezes"] == 0 and u["tickets"] == 0 and u["daily_goal"] == 30
    assert db.is_premium(u)                                   # старая запись premium_until с микросекундами читается
    assert (await db.path_progress(77))[("A1", "Приветствия")] == 3
    assert ("A1", "Small talk") in await db.path_progress(77)  # миграция темы с пробелом
    assert await db.apply_payment(77, "d7", 7, 49, "old-charge") is None   # старые платежи учитываются как уже обработанные
    p = await svc.profile(77, "old")
    assert p["level"] == "A2" and p["is_premium"] and p["onboarded"]
    print("migration ok")


def test_migration_from_v3():
    run(scenario_migration_from_v3())


# ------------------------------------------------------------------ HTTP: авторизация и изоляция
async def scenario_http_security():
    from app.main import app
    await fresh_db()
    old_token = settings.bot_token
    settings.bot_token = TOKEN
    try:
        tr = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=tr, base_url="http://t") as c:
            H = lambda uid: {"X-Init-Data": make_init_data(uid)}   # noqa: E731
            assert (await c.get("/api/profile")).status_code == 401
            assert (await c.get("/api/profile", headers={"X-Init-Data": "hash=bad"})).status_code == 401
            assert (await c.get("/api/profile", headers={"X-Dev-User": "1"})).status_code == 401      # dev-вход выключен
            assert (await c.get("/api/profile", headers={"X-Init-Data": make_init_data(1, auth_date=1)})).status_code == 401
            h = (await c.get("/healthz")).json()
            assert h == {"ok": True, "app": "engly"}                                                   # без внутренних флагов
            # два пользователя
            a = (await c.get("/api/profile", headers=H(101))).json()
            b = (await c.get("/api/profile", headers=H(102))).json()
            assert a["tg_id"] == 101 and b["tg_id"] == 102 and a["xp"] == 0 and a["onboarded"] is False
            # онбординг A: пропуск теста, затем урок
            r = await c.post("/api/placement/skip", headers=H(101), json={"goal": "travel", "minutes": 10})
            assert r.status_code == 200
            st = (await c.post("/api/lesson/start", headers=H(101), json={"level": "A1", "topic": "Приветствия", "mode": "path"})).json()
            sid = st["session_id"]
            assert "options" in json.dumps(st) and "correct" not in json.dumps(st).replace("correct_", "")   # ответы не утекают
            # B не может ни читать, ни отвечать, ни завершать чужой урок
            assert (await c.get(f"/api/lesson/state?session_id={sid}", headers=H(102))).status_code == 404
            assert (await c.post("/api/lesson/answer", headers=H(102), json={"session_id": sid, "idx": 0, "answer": "seen"})).status_code == 404
            assert (await c.post("/api/lesson/finish", headers=H(102), json={"session_id": sid})).status_code == 404
            # XP, Premium, стрик и прогресс нельзя задать запросом: у API нет таких входов; лишние поля игнорируются
            r = await c.post("/api/lesson/answer", headers=H(101), json={"session_id": sid, "idx": 0, "answer": "seen", "xp": 9999, "premium": True})
            assert r.status_code == 200 and r.json()["xp_earned"] == 0
            p = (await c.get("/api/profile", headers=H(101))).json()
            assert p["xp"] == 0 and p["is_premium"] is False
            # незавершённый урок нельзя «завершить» ради наград
            assert (await c.post("/api/lesson/finish", headers=H(101), json={"session_id": sid})).status_code == 400
            # неизвестные события и кривые тела
            assert (await c.post("/api/event", headers=H(101), json={"name": "give_me_xp"})).status_code == 400
            r = await c.post("/api/lesson/answer", headers=H(101), json={"session_id": 5})
            assert r.status_code == 422 and r.json() == {"error": "bad_request"}
            assert (await c.post("/api/invoice", headers=H(101), json={"plan": "free"})).status_code == 400
            # удаление аккаунта удаляет только свой аккаунт
            assert (await c.delete("/api/account", headers=H(101))).json() == {"deleted": True}
            assert (await c.get("/api/profile", headers=H(101))).json()["onboarded"] is False
            assert (await c.get("/api/profile", headers=H(102))).json()["tg_id"] == 102
            assert (await c.get(f"/api/lesson/state?session_id={sid}", headers=H(101))).status_code == 404
    finally:
        settings.bot_token = old_token
    print("http security ok")


def test_http_security():
    run(scenario_http_security())
