"""Тесты ядра Engly: адаптивный тест, SRS, сервисный слой (сессии, античит, стрики, локации).
Запуск: cd backend && python -m pytest -q   (или просто: python tests/test_engine.py)
"""
import asyncio
import os
import random
import sys
import tempfile
from datetime import datetime, timedelta, timezone

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import adaptive, gamify, lessons, locations as L, services as svc  # noqa: E402
from app.config import settings  # noqa: E402
from app.db import MSK, Database, database as db  # noqa: E402
from app.placement_bank import BANK as PB  # noqa: E402
from app.srs import Card, schedule  # noqa: E402


# ---------------------------------------------------------------- адаптивный тест
def _simulate(theta, rng):
    ans, asked = [], set()
    while not adaptive.is_finished(ans):
        q = adaptive.pick_next(ans, asked, rng)
        asked.add(q["id"])
        ans.append({"b": q["b"], "ok": rng.random() < adaptive.p_correct(theta, q["b"]), "kind": q["kind"], "level": q["level"]})
    return ans


def test_adaptive_accuracy():
    rng = random.Random(1)
    n = within1 = 0
    for lvl in range(6):
        for _ in range(120):
            th = lvl + rng.random()
            ans = _simulate(th, rng)
            assert 10 <= len(ans) <= 15
            pred = adaptive.LEVELS.index(adaptive.summarize(ans)["level"])
            n += 1
            within1 += abs(pred - lvl) <= 1
    assert within1 / n >= 0.95, within1 / n


def test_adaptive_direction():
    """Верно → следующий вопрос сложнее, неверно → легче."""
    ans = [{"b": 2.5, "ok": True, "kind": "tr", "level": "B1"}]
    up = adaptive.pick_next(ans, set(), random.Random(0))
    ans = [{"b": 2.5, "ok": False, "kind": "tr", "level": "B1"}]
    down = adaptive.pick_next(ans, set(), random.Random(0))
    assert adaptive.estimate([{"b": 2.5, "ok": True}]).theta > adaptive.estimate([{"b": 2.5, "ok": False}]).theta
    assert up["b"] >= down["b"]


def test_bank_integrity():
    assert len(PB) == 60
    for q in PB.values():
        assert q["correct"] not in q["wrong"] and len(set(q["wrong"])) == 3, q["id"]


# ---------------------------------------------------------------- SRS
def test_srs_schedule():
    now = datetime(2026, 1, 1, tzinfo=timezone.utc)
    c = schedule(Card(), True, now, 5000)
    assert c.interval == 1 and c.reps == 1
    c = schedule(c, True, now, 5000)
    assert c.interval == 3
    c = schedule(c, True, now, 5000)
    assert c.interval > 3
    bad = schedule(c, False, now)
    assert bad.reps == 0 and bad.lapses == 1 and bad.due_at - now == timedelta(minutes=10) and bad.ease < c.ease
    assert schedule(Card(lapses=5, reps=5, interval=30), True, now).interval <= 2   # пиявка


def test_locations_valid():
    assert L.validate() == []
    assert len(L.LOCATIONS) == 10


def test_beginner_lessons_are_gentle():
    """Новичок A1: в каждом уроке пути — по одному новому слову за раз (intro → лёгкие задания), без сборки фраз в первых темах."""
    import random
    from app.content import BANK
    for lv in ("A1",):
        for tp in BANK[lv]:
            for c in range(lessons.n_chunks(lv, tp)):
                t = lessons.build_path_lesson(lv, tp, c, [], [], 0)
                ks = [x["type"] for x in t]
                assert ks.count("intro") == len(lessons.chunk_words(lv, tp, c)) <= 3
                assert "scramble" not in ks
                for w in lessons.chunk_words(lv, tp, c):
                    i = next(j for j, x in enumerate(t) if x["type"] == "intro" and x["item"] == w["en"])
                    assert t[i + 1]["type"] in ("pick_emoji", "en_ru") and len(t[i + 1]["options"]) <= 3


def test_levels():
    assert gamify.player_level(100)["level"] == 2 and gamify.player_level(299)["level"] == 2


# ---------------------------------------------------------------- сервисы
def run(coro):
    return asyncio.run(coro)


async def fresh_db():
    path = os.path.join(tempfile.mkdtemp(), "t.db")
    db.path = path
    await db.connect()


def oracle_answer(q, right=True):
    return PB[q["id"]]["correct"] if right else q["options"][0] if q["options"][0] != PB[q["id"]]["correct"] else q["options"][1]


async def do_placement(tg, right_fn):
    await db.upsert_user(tg, "u")
    st = await svc.placement_start(tg, "travel", 10)
    q, res = st["question"], None
    assert "correct" not in q and "wrong" not in q            # ответ не утекает клиенту
    while True:
        r = await svc.placement_answer(tg, st["session_id"], q["id"], oracle_answer(q, right_fn(q)))
        if r["done"]:
            return st, r["result"]
        q = r["question"]


async def scenario_placement():
    await fresh_db()
    st, hi = await do_placement(1, lambda q: True)
    assert hi["level"] in ("C1", "C2") and hi["plan"]["daily_goal_xp"] == 40
    u = await db.get_user(1)
    assert u["quiz_done"] == 1 and u["level"] == hi["level"] and u["goal"] == "travel" and u["daily_goal"] == 40
    _, lo = await do_placement(2, lambda q: False)
    assert lo["level"] == "A1" and lo["confidence"] in ("medium", "high", "low")
    # античит
    st = await svc.placement_start(3, None, None) if await db.upsert_user(3, "x") is None else None
    for bad_q in ("C2-10", "zzz"):
        try:
            await svc.placement_answer(3, st["session_id"], bad_q, "x"); assert False
        except svc.ApiError as e:
            assert e.status == 400
    try:
        await svc.placement_answer(3, "nope", "A2-01", "x"); assert False
    except svc.ApiError as e:
        assert e.status == 404
    # завершённую сессию повторно трогать нельзя
    try:
        await svc.placement_answer(1, st["session_id"], "A1-01", "x"); assert False
    except svc.ApiError as e:
        assert e.status in (404, 409)
    print("placement ok:", hi["level"], lo["level"])


def right_answer(t):
    k = t["type"]
    if k in ("ru_en", "type_word"):
        return t["item"]
    if k in ("en_ru", "listen", "pick_emoji"):
        return t["emoji"] if t.get("by") == "emoji" else t["ru"]
    if k == "scramble":
        return " ".join(lessons.norm_phrase(t["phrase"]))
    return {"intro": "seen", "speak": "skip", "match": "done"}[k]


async def play(tg, st, right=lambda i, t: True, upto=None):
    """Проходит урок: правильные/неправильные ответы по правилу right(i, task). Возвращает итог finish."""
    sid = st["session_id"]
    i = 0
    while True:
        state, _ = await db.session_get(sid, tg, "lesson")
        if i >= len(state["tasks"]) or (upto is not None and i >= upto):
            break
        t = state["tasks"][i]
        ok = right(i, t)
        if t["type"] == "match":
            for p in t["pairs"]:
                if not ok:
                    wrong = next(x["ru"] for x in t["pairs"] if x["en"] != p["en"])
                    await svc.lesson_pair(tg, sid, i, p["en"], wrong); await svc.lesson_pair(tg, sid, i, p["en"], wrong)
                await svc.lesson_pair(tg, sid, i, p["en"], p["ru"])
            ans = "done"
        else:
            ans = right_answer(t) if ok or t["type"] in ("intro", "speak") else "заведомо неверно"
        await svc.lesson_answer(tg, sid, i, ans, 3000)
        i += 1
    return await svc.lesson_finish(tg, sid)


async def mk_user(tg, level="A1"):
    await db.upsert_user(tg, "u")
    await db.db.execute("UPDATE users SET level=?, quiz_done=1 WHERE tg_id=?", (level, tg)); await db.db.commit()


async def scenario_path():
    await fresh_db()
    await mk_user(10)
    await db.extend_premium(10, 30)     # лимит проверяет scenario_limit_and_premium
    p = await svc.path(10)
    a1 = p["levels"][0]["units"]
    assert [u["status"] for u in a1[:3]] == ["current", "locked", "locked"] and p["current"]["topic"] == "Приветствия"
    assert p["levels"][1]["state"] == "locked" and p["levels"][1]["units"][0]["status"] == "locked"
    try:
        await svc.lesson_start(10, "A1", "Знакомство"); assert False
    except svc.ApiError as e:
        assert e.status == 403
    st = await svc.lesson_start(10, "A1", "Приветствия")
    assert st["mode"] == "path" and st["chunk"] == 0 and st["tasks"][0]["type"] == "intro"
    kinds = [t["type"] for t in st["tasks"]]
    assert kinds.count("intro") == 3 and kinds[-1] == "speak" and "scramble" not in kinds       # новичку не дают разбор предложений
    assert "type_word" in kinds and "match" in kinds
    for t in st["tasks"]:
        assert not ({"correct", "answer"} & set(t)) and not any(k in t for k in ("pairs", "matched"))
    assert "ru" not in st["tasks"][1]                       # задание «выбери картинку» не выдаёт перевод
    # античит: «пары» сервер проверяет сам, пока не соединены — «done» нельзя
    mi = kinds.index("match")
    for i in range(mi):
        await svc.lesson_answer(10, st["session_id"], i, "seen" if kinds[i] == "intro" else right_answer((await db.session_get(st["session_id"], 10, "lesson"))[0]["tasks"][i]), 2000)
    try:
        await svc.lesson_answer(10, st["session_id"], mi, "done", 1000); assert False
    except svc.ApiError as e:
        assert e.status == 400 and e.detail == "not_matched"
    left0 = (await db.srs_stats(10))["total"]
    assert left0 == 3                                       # знакомство создало карточки слов
    # плохой урок (всё мимо) не продвигает путь
    st2 = await svc.lesson_start(10, "A1", "Приветствия")
    bad = await play(10, st2, right=lambda i, t: False)
    assert bad["path"]["passed"] is False and bad["accuracy"] < 0.6
    assert (await svc.path(10))["levels"][0]["units"][0]["done"] == 0
    # три хороших урока закрывают тему и открывают следующую
    for k in range(3):
        r = await play(10, await svc.lesson_start(10, "A1", "Приветствия"))
        assert r["path"]["passed"] and r["perfect"] and r["path"]["lesson"] == k + 1
    assert r["path"]["unit_done"]
    p = await svc.path(10)
    assert [u["status"] for u in p["levels"][0]["units"][:2]] == ["done", "current"]
    again = await svc.lesson_start(10, "A1", "Приветствия")
    assert again["mode"] == "practice"                      # пройденную тему можно тренировать свободно
    # повышение уровня: все темы A1 пройдены
    for t in p["levels"][0]["units"][1:-1]:
        await db.db.execute("INSERT OR REPLACE INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(10,'A1',?,3)", (t["topic"],))
    last = p["levels"][0]["units"][-1]
    await db.db.execute("INSERT OR REPLACE INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(10,'A1',?,?)", (last["topic"], last["lessons"] - 1)); await db.db.commit()
    r = await play(10, await svc.lesson_start(10, "A1", last["topic"]))
    assert r["cefr_up"] and r["cefr_up"]["to"] == "A2" and (await db.get_user(10))["level"] == "A2"
    assert (await svc.path(10))["current"]["level"] == "A2"
    print("path ok")


async def scenario_match_drill_vocab():
    await fresh_db()
    await mk_user(11)
    await db.extend_premium(11, 30)
    try:
        await svc.lesson_start(11, None, None, mode="drill", kind="listen"); assert False
    except svc.ApiError as e:
        assert e.status == 409 and e.detail == "need_words"
    await play(11, await svc.lesson_start(11, "A1", "Приветствия"))
    await play(11, await svc.lesson_start(11, "A1", "Приветствия"))
    v = await svc.vocab(11)
    assert v["counts"]["learning"] >= 6, v["counts"]
    assert any(c["emoji"] for c in v["cards"])
    for kind in ("listen", "type_word", "pick_emoji", "ru_en", "match"):
        st = await svc.lesson_start(11, None, None, mode="drill", kind=kind)
        assert st["mode"] == "drill" and all(t["type"] == kind for t in st["tasks"]), kind
        r = await play(11, st)
        assert r["accuracy"] == 1.0, kind
    try:
        await svc.lesson_start(11, None, None, mode="drill", kind="bogus"); assert False
    except svc.ApiError as e:
        assert e.status == 400
    # пара: неверная пара — ошибка, повторная верная — засчитывается; больше одной ошибки → не идеально
    st = await svc.lesson_start(11, None, None, mode="drill", kind="match")
    state, _ = await db.session_get(st["session_id"], 11, "lesson")
    t = state["tasks"][0]
    other = next(p for p in t["pairs"] if p["en"] != t["pairs"][0]["en"])
    assert (await svc.lesson_pair(11, st["session_id"], 0, t["pairs"][0]["en"], other["ru"]))["ok"] is False
    for p in t["pairs"]:
        r = await svc.lesson_pair(11, st["session_id"], 0, p["en"], p["ru"]); assert r["ok"]
    assert r["done"]
    a = await svc.lesson_answer(11, st["session_id"], 0, "done", 1000)
    assert a["correct"] is True and a["mistakes"] == 1
    print("match/drill/vocab ok")


async def scenario_lesson():
    await fresh_db()
    await mk_user(12)
    st = await svc.lesson_start(12, "A1", "Приветствия")
    sid = st["session_id"]
    state, _ = await db.session_get(sid, 12, "lesson")
    ti = next(i for i, t in enumerate(state["tasks"]) if t["type"] == "pick_emoji")
    r = await svc.lesson_answer(12, sid, ti, "заведомо неверно", 4000)
    assert r["correct"] is False and r["retry"] and r["retry"]["idx"] == len(state["tasks"])
    assert r["retry"]["type"] in ("pick_emoji", "en_ru") and len(r["retry"]["options"]) == 2    # ошибка → самый лёгкий повтор
    card = await db.srs_get(12, state["tasks"][ti]["item"])
    assert card["lapses"] == 1 and card["reps"] == 0
    try:
        await svc.lesson_answer(12, sid, ti, "x", 1); assert False
    except svc.ApiError as e:
        assert e.status == 409
    try:
        await svc.lesson_finish(12, sid); assert False
    except svc.ApiError as e:
        assert e.status == 400
    await db.db.execute("UPDATE srs_cards SET due_at=? WHERE tg_id=12 AND item_en=?",
                        ((datetime.now(timezone.utc) - timedelta(minutes=1)).replace(microsecond=0).isoformat(), card["item_en"]))
    await db.db.commit()
    rv = await svc.lesson_start(12, None, None, mode="review")
    assert rv["review_count"] >= 1
    await db.srs_add_cards(12, [{"en": "dog", "ru": "собака", "phrase": "I have a dog.", "phrase_ru": "У меня есть собака.", "level": "A1", "topic": "Животные"}])
    await db.db.execute("UPDATE srs_cards SET due_at=? WHERE tg_id=12 AND item_en='dog'", ((datetime.now(timezone.utc) - timedelta(hours=1)).replace(microsecond=0).isoformat(),))
    await db.db.commit()
    nxt = await svc.lesson_start(12, "A1", "Приветствия")
    assert nxt["review_count"] >= 1 and nxt["tasks"][0]["review"]       # просроченное слово из другой темы — разминка
    print("lesson ok")


async def scenario_limit_and_premium():
    await fresh_db()
    await mk_user(20)
    started = 0
    try:
        while True:
            st = await svc.lesson_start(20, "A1", "Приветствия")
            started += 1
            r = await play(20, st)                       # начатый урок всегда можно дойти до конца, даже если лимит кончился по ходу
            assert r["xp_lesson"] > 0
    except svc.ApiError as e:
        assert e.status == 402                           # а вот начать новый — уже нельзя
    assert started >= 1 and await db.tasks_left(20) == 0
    await db.extend_premium(20, 7)
    assert (await svc.lesson_start(20, "A1", "Приветствия"))["tasks"]
    print("limit ok, lessons:", started)


async def scenario_limit_never_cuts_lesson():
    await fresh_db()
    await mk_user(21)
    for _ in range(settings.free_limit - 1):
        await db.count_task(21)
    assert await db.tasks_left(21) == 1
    st = await svc.lesson_start(21, "A1", "Приветствия")           # остался 1 бесплатный ответ — урок всё равно пройдёт целиком
    r = await play(21, st)
    assert r["path"]["passed"] and await db.tasks_left(21) == 0
    try:
        await svc.lesson_start(21, "A1", "Приветствия"); assert False
    except svc.ApiError as e:
        assert e.status == 402
    # повторение бесплатно и без лимита
    await db.db.execute("UPDATE srs_cards SET due_at='2000-01-01T00:00:00+00:00' WHERE tg_id=21"); await db.db.commit()
    rv = await svc.lesson_start(21, None, None, mode="review")
    await play(21, rv)
    assert await db.tasks_left(21) == 0
    print("limit-never-cuts ok")


async def scenario_errors_are_free():
    await fresh_db()
    await mk_user(22)
    st = await svc.lesson_start(22, "A1", "Приветствия")
    state, _ = await db.session_get(st["session_id"], 22, "lesson")
    counted = sum(1 for t in state["tasks"][:state["base"]] if t["type"] not in ("intro", "speak") and not t.get("review"))
    r = await play(22, st, right=lambda i, t: False)               # всё неверно → 3 повтора ошибок
    assert settings.free_limit - await db.tasks_left(22) == counted, "ошибки и повторы не должны расходовать лимит"
    print("errors free ok")


async def scenario_resume_and_strict_finish():
    await fresh_db()
    await mk_user(23)
    await db.extend_premium(23, 30)
    st = await svc.lesson_start(23, "A1", "Приветствия")
    sid = st["session_id"]
    state, _ = await db.session_get(sid, 23, "lesson")
    for i in range(6):
        t = state["tasks"][i]
        await svc.lesson_answer(23, sid, i, right_answer(t) if t["type"] != "match" else "x", 1000) if t["type"] != "match" else None
    res = await svc.lesson_resume(23)
    assert res and res["session_id"] == sid and res["next"] == 6 and len(res["answered"]) == 6
    assert (await svc.lesson_state(23, sid))["next"] == 6
    assert not any(k in res["tasks"][1] for k in ("correct", "pairs"))
    try:                                                            # ответ уже принят, а клиент не получил ответ → 409, клиент синхронизируется
        await svc.lesson_answer(23, sid, 2, "x", 1); assert False
    except svc.ApiError as e:
        assert e.status == 409
    try:                                                            # завершить после части заданий нельзя
        await svc.lesson_finish(23, sid); assert False
    except svc.ApiError as e:
        assert e.status == 400 and e.detail == "not_finished"
    for i in range(6, len(state["tasks"])):
        t = state["tasks"][i]
        if t["type"] == "match":
            for p in t["pairs"]:
                await svc.lesson_pair(23, sid, i, p["en"], p["ru"])
        await svc.lesson_answer(23, sid, i, right_answer(t), 1000)
    await svc.lesson_finish(23, sid)
    assert await svc.lesson_resume(23) is None
    print("resume ok")


async def scenario_goal_and_practice():
    await fresh_db()
    await mk_user(24)
    base = [u["topic"] for u in (await svc.path(24))["levels"][0]["units"]]
    await db.db.execute("UPDATE users SET goal='travel' WHERE tg_id=24"); await db.db.commit()
    p = await svc.path(24)
    tr = [u["topic"] for u in p["levels"][0]["units"]]
    assert tr[:3] == base[:3] == ["Приветствия", "Знакомство", "Я и ты"] and tr[3] == "Еда и напитки" and tr != base
    assert [u["goal_pick"] for u in p["levels"][0]["units"]].count(True) == 3
    assert sorted(tr) == sorted(base)
    await db.extend_premium(24, 30)
    for _ in range(2):
        await play(24, await svc.lesson_start(24, "A1", "Приветствия"))
    pr = await svc.practice(24)
    for k, n in pr["drills"].items():                               # кнопка активна ⇔ сервер соберёт тренировку
        try:
            await svc.lesson_start(24, None, None, mode="drill", kind=k); ok = True
        except svc.ApiError as e:
            assert e.detail == "need_words"; ok = False
        assert ok == (n >= pr["need"]), (k, n)
    print("goal/practice ok")


async def scenario_streak():
    await fresh_db()
    await db.upsert_user(30, "s")
    r = await db.touch_streak(30); assert r["streak"] == 1 and r["new_day"]
    r = await db.touch_streak(30); assert r["streak"] == 1 and not r["new_day"]
    day = lambda n: (datetime.now(MSK).date() - timedelta(days=n)).isoformat()
    await db.db.execute("UPDATE users SET last_study_day=?, streak_days=5 WHERE tg_id=30", (day(1),)); await db.db.commit()
    assert (await db.touch_streak(30))["streak"] == 6                   # вчера учился — +1
    await db.db.execute("UPDATE users SET last_study_day=?, streak_days=6, freezes=1 WHERE tg_id=30", (day(2),)); await db.db.commit()
    r = await db.touch_streak(30); assert r["streak"] == 7 and r["freeze_used"]   # заморозка спасла
    assert (await db.get_user(30))["freezes"] == 0
    await db.db.execute("UPDATE users SET last_study_day=?, streak_days=7 WHERE tg_id=30", (day(2),)); await db.db.commit()
    assert (await db.touch_streak(30))["streak"] == 1                   # заморозки нет — сброс
    # покупка заморозки за билеты
    await db.add_tickets(30, 10)
    r = await svc.buy_freeze(30); assert r["freezes"] == 1 and r["tickets"] == 0
    try:
        await svc.buy_freeze(30); assert False
    except svc.ApiError as e:
        assert e.status == 402
    print("streak ok")


async def scenario_location():
    await fresh_db()
    await db.upsert_user(40, "l")
    await db.db.execute("UPDATE users SET level='A1', quiz_done=1 WHERE tg_id=40"); await db.db.commit()
    lst = await svc.locations(40)
    assert not any(l["unlocked"] for l in lst["locations"]) and "Приветствия" in lst["locations"][0]["lock_hint"]   # без слов — в диалог не пускаем
    try:
        await svc.location_start(40, "nyc_park"); assert False
    except svc.ApiError as e:
        assert e.status == 403
    for tp in ("Приветствия", "Еда и напитки", "Числа и цвета", "Знакомство", "Я и ты"):
        await db.db.execute("INSERT OR REPLACE INTO lesson_progress(tg_id, level, topic, lessons_done) VALUES(40,'A1',?,3)", (tp,))
    await db.db.commit()
    lst = await svc.locations(40)
    assert [l["unlocked"] for l in lst["locations"]] == [True, False, False, False, False, True, True, False, False, False]
    try:
        await svc.location_start(40, "sf_interview"); assert False
    except svc.ApiError as e:
        assert e.status == 403
    st = await svc.location_start(40, "nyc_park")
    sid, node = st["session_id"], st["node"]
    assert all(set(c) == {"en", "ru"} for c in node["choices"])         # q и подсказки скрыты до выбора
    loc = L.LOC_BY_ID["nyc_park"]
    try:
        await svc.location_choose(40, sid, "n5", 0); assert False       # нельзя перепрыгнуть узел
    except svc.ApiError as e:
        assert e.status == 400
    while True:
        best = max(range(len(loc["nodes"][node["id"]]["choices"])), key=lambda i: loc["nodes"][node["id"]]["choices"][i]["q"])
        r = await svc.location_choose(40, sid, node["id"], best)
        if r["done"]:
            break
        node = r["node"]
    assert r["stars"] == 3 and r["first_time"] and r["vocab_added"] == 5
    assert any(a["code"] == "first_trip" for a in r["achievements"])
    u = await db.get_user(40)
    assert u["tickets"] >= 2
    assert (await db.srs_stats(40))["total"] == 5
    # повторное прохождение: билетов за «первый раз» нет
    st = await svc.location_start(40, "nyc_park"); node = st["node"]
    while True:
        r = await svc.location_choose(40, st["session_id"], node["id"], 0)
        if r["done"]:
            break
        node = r["node"]
    assert r["first_time"] is False and r["vocab_added"] == 0
    print("location ok: stars", r["stars"])


def test_services():
    # шим aiosqlite не нужен, если установлен настоящий; здесь просто запускаем сценарии
    for sc in (scenario_placement, scenario_path, scenario_match_drill_vocab, scenario_lesson, scenario_limit_and_premium, scenario_limit_never_cuts_lesson, scenario_errors_are_free, scenario_resume_and_strict_finish, scenario_goal_and_practice, scenario_streak, scenario_location):
        run(sc())


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)
