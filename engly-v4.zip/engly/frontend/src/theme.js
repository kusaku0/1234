import { useCallback, useEffect, useState } from 'react'
import { tg } from './tg.js'

/* Тема: auto (как в Telegram / системе) · light · dark. Выбор хранится в localStorage. */
const KEY = 'engly_theme'
const COLORS = { dark: '#0b0a1f', light: '#f5f3ff' }

export const getPref = () => { try { return localStorage.getItem(KEY) || 'auto' } catch { return 'auto' } }

export function resolve(pref) {
  if (pref === 'light' || pref === 'dark') return pref
  if (tg?.colorScheme) return tg.colorScheme
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark'
}

export function applyTheme(pref) {
  const r = resolve(pref)
  document.documentElement.dataset.theme = r
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', COLORS[r])
  try { tg?.setHeaderColor?.(COLORS[r]); tg?.setBackgroundColor?.(COLORS[r]); tg?.setBottomBarColor?.(COLORS[r]) } catch {}
  return r
}

export function useTheme() {
  const [pref, setPrefState] = useState(getPref)
  const [resolved, setResolved] = useState(() => resolve(getPref()))
  const setPref = useCallback((p) => {
    try { localStorage.setItem(KEY, p) } catch {}
    setPrefState(p); setResolved(applyTheme(p))
  }, [])
  useEffect(() => {
    setResolved(applyTheme(pref))
    const on = () => { if (getPref() === 'auto') setResolved(applyTheme('auto')) }
    const mq = window.matchMedia?.('(prefers-color-scheme: light)')
    mq?.addEventListener?.('change', on); tg?.onEvent?.('themeChanged', on)
    return () => { mq?.removeEventListener?.('change', on); tg?.offEvent?.('themeChanged', on) }
  }, [pref])
  return { pref, resolved, setPref, toggle: () => setPref(resolved === 'dark' ? 'light' : 'dark') }
}
