export const tg = typeof window !== 'undefined' ? window.Telegram?.WebApp : undefined

/* Отступы под вырезы и панели Telegram: --tg-top / --tg-bottom добавляются к env(safe-area-inset-*) в CSS */
function syncInsets() {
  try {
    const sa = tg.safeAreaInset || {}, ca = tg.contentSafeAreaInset || {}
    const r = document.documentElement.style
    r.setProperty('--tg-top', `${(sa.top || 0) + (ca.top || 0)}px`)
    r.setProperty('--tg-bottom', `${(sa.bottom || 0) + (ca.bottom || 0)}px`)
  } catch {}
}

export function setupTelegram() {
  if (!tg) return
  try {
    tg.ready()
    tg.expand()
    tg.disableVerticalSwipes?.()        // свайп вниз по уроку не должен закрывать приложение
    syncInsets()
    for (const e of ['safeAreaChanged', 'contentSafeAreaChanged', 'fullscreenChanged']) tg.onEvent?.(e, syncInsets)
  } catch {}
}

export const haptic = {
  on: (() => { try { return localStorage.getItem('engly_haptic') !== '0' } catch { return true } })(),
  set(v) { this.on = v; try { localStorage.setItem('engly_haptic', v ? '1' : '0') } catch {} },
  tap() { if (this.on) try { tg?.HapticFeedback?.impactOccurred('light') } catch {} },
  soft() { if (this.on) try { tg?.HapticFeedback?.selectionChanged() } catch {} },
  ok() { if (this.on) try { tg?.HapticFeedback?.notificationOccurred('success') } catch {} },
  bad() { if (this.on) try { tg?.HapticFeedback?.notificationOccurred('error') } catch {} },
}

// TTS: выбираем самый приятный английский голос (нейронные/«Enhanced» — выше приоритет)
let voice = null
function pickVoice() {
  try {
    const vs = window.speechSynthesis.getVoices().filter((v) => /^en[-_]/i.test(v.lang))
    if (!vs.length) return null
    const score = (v) => (/natural|neural|online/i.test(v.name) ? 6 : 0) + (/google|samantha|aria|jenny|ava|zoe|daniel/i.test(v.name) ? 3 : 0) + (/en[-_]US/i.test(v.lang) ? 2 : 0) + (v.localService ? 0 : 1)
    return vs.sort((a, b) => score(b) - score(a))[0]
  } catch { return null }
}
try { window.speechSynthesis?.addEventListener?.('voiceschanged', () => { voice = pickVoice() }) } catch {}

export function speak(text, rate = 0.9) {
  try {
    voice = voice || pickVoice()
    const u = new SpeechSynthesisUtterance(text)
    u.lang = voice?.lang || 'en-US'; if (voice) u.voice = voice
    u.rate = rate; u.pitch = 1.02
    window.speechSynthesis.cancel()
    window.speechSynthesis.speak(u)
    return true
  } catch { return false }
}
export const ttsAvailable = typeof window !== 'undefined' && 'speechSynthesis' in window
