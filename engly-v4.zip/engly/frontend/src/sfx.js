/* Звуковой дизайн Engly: мягкие «колокольчики» и «маримба» вместо резких писков.
   Все звуки синтезируются WebAudio (без файлов): синус + гармоники колокола, ФНЧ, лёгкая реверберация.
   Правильные ответы идут по пентатонике и поднимаются выше с серией верных — приятно и «играет» как мелодия. */
let ctx = null, bus = null, muted = false, vol = 0.8
try { muted = localStorage.getItem('engly_mute') === '1'; vol = Number(localStorage.getItem('engly_vol') ?? 0.8) } catch {}

const PENTA = [523.25, 587.33, 659.25, 783.99, 880.0, 1046.5, 1174.66, 1318.51]   // C D E G A C D E

function impulse(c, sec = 1.6, decay = 3.2) {
  const len = Math.floor(c.sampleRate * sec), buf = c.createBuffer(2, len, c.sampleRate)
  for (let ch = 0; ch < 2; ch++) { const d = buf.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, decay) }
  return buf
}

function ac() {
  if (muted) return null
  try {
    if (!ctx) {
      const C = window.AudioContext || window.webkitAudioContext
      if (!C) return null
      ctx = new C()
      const master = ctx.createGain(); master.gain.value = vol
      const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.ratio.value = 3
      const verb = ctx.createConvolver(); verb.buffer = impulse(ctx)
      const wet = ctx.createGain(); wet.gain.value = 0.22
      bus = ctx.createGain()
      bus.connect(master); bus.connect(verb); verb.connect(wet); wet.connect(master)
      master.connect(comp); comp.connect(ctx.destination)
      ctx.master = master
    }
    if (ctx.state === 'suspended') ctx.resume()
    return ctx
  } catch { return null }
}

/* нота-колокольчик: основной тон + гармоники с разным затуханием */
function note(freq, at = 0, dur = 0.5, { gain = 0.16, parts = [[1, 1], [2.76, 0.22], [5.4, 0.07]], lp = 7000, glide = null, attack = 0.006 } = {}) {
  const c = ac(); if (!c) return
  const t = c.currentTime + at
  const f = c.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = lp
  f.connect(bus)
  parts.forEach(([m, g], i) => {
    const o = c.createOscillator(), e = c.createGain()
    o.type = 'sine'; o.frequency.setValueAtTime(freq * m, t)
    if (glide) o.frequency.exponentialRampToValueAtTime(glide * m, t + dur)
    const d = dur / (1 + i * 0.9)
    e.gain.setValueAtTime(0.0001, t); e.gain.exponentialRampToValueAtTime(gain * g, t + attack); e.gain.exponentialRampToValueAtTime(0.0001, t + d)
    o.connect(e).connect(f); o.start(t); o.stop(t + d + 0.05)
  })
}

function air(at, dur, f0, f1, gain = 0.07, q = 0.9) {
  const c = ac(); if (!c) return
  const len = Math.floor(c.sampleRate * dur), buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0)
  for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1
  const src = c.createBufferSource(); src.buffer = buf
  const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.Q.value = q
  const t = c.currentTime + at
  bp.frequency.setValueAtTime(f0, t); bp.frequency.exponentialRampToValueAtTime(f1, t + dur)
  const g = c.createGain(); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(gain, t + dur * 0.45); g.gain.exponentialRampToValueAtTime(0.0001, t + dur)
  src.connect(bp).connect(g).connect(bus); src.start(t)
}

export const sfx = {
  get muted() { return muted },
  get volume() { return vol },
  setMuted(v) { muted = v; try { localStorage.setItem('engly_mute', v ? '1' : '0') } catch {} },
  setVolume(v) { vol = v; try { localStorage.setItem('engly_vol', String(v)) } catch {}; if (ctx?.master) ctx.master.gain.value = v },
  unlock() { const m = muted; muted = false; ac(); muted = m },

  /* лёгкий «пузырёк» на касание */
  tap() { note(760, 0, 0.09, { gain: 0.05, parts: [[1, 1], [2, 0.15]], glide: 560 }) },
  select() { note(640, 0, 0.07, { gain: 0.04, parts: [[1, 1]] }) },
  pop() { note(420, 0, 0.12, { gain: 0.07, parts: [[1, 1], [2, 0.3]], glide: 880 }) },
  /* верно: мелодичный «дзынь», тон растёт с серией */
  ok(combo = 0) {
    const f = PENTA[Math.min(combo, PENTA.length - 3)]
    note(f, 0, 0.55, { gain: 0.15 }); note(f * 1.5, 0.075, 0.6, { gain: 0.12 })
  },
  /* неверно: тёплый, мягкий «буп» — не пугает */
  bad() { note(294, 0, 0.32, { gain: 0.13, parts: [[1, 1], [2, 0.18]], lp: 1200, glide: 233 }); note(233, 0.11, 0.34, { gain: 0.09, parts: [[1, 1]], lp: 900, glide: 196 }) },
  /* пара найдена */
  pair() { note(PENTA[4], 0, 0.3, { gain: 0.1, parts: [[1, 1], [2.76, 0.15]] }); note(PENTA[6], 0.06, 0.4, { gain: 0.09 }) },
  star() { note(1568, 0, 0.4, { gain: 0.09 }); note(2093, 0.07, 0.5, { gain: 0.07 }); note(2637, 0.15, 0.6, { gain: 0.05 }) },
  coin() { note(1318.5, 0, 0.3, { gain: 0.1 }); note(1975.5, 0.07, 0.5, { gain: 0.1 }) },
  flip() { air(0, 0.07, 2400, 4200, 0.05, 2) },
  toggle(on = true) { note(on ? 660 : 520, 0, 0.14, { gain: 0.07 }); note(on ? 990 : 390, 0.07, 0.2, { gain: 0.07 }) },
  /* урок пройден: арпеджио + мерцающий аккорд */
  done() {
    ;[523.25, 659.25, 783.99, 1046.5, 1318.51].forEach((f, i) => note(f, i * 0.085, 0.7, { gain: 0.13 }))
    ;[523.25, 659.25, 783.99, 1046.5].forEach((f) => note(f, 0.5, 1.5, { gain: 0.05, parts: [[1, 1], [2, 0.2]] }))
    air(0.45, 0.9, 5000, 9000, 0.012)
  },
  levelup() {
    ;[392, 523.25, 659.25, 783.99, 1046.5, 1318.51, 1568].forEach((f, i) => note(f, i * 0.09, 0.8, { gain: 0.13 }))
    ;[523.25, 783.99, 1046.5, 1318.51].forEach((f) => note(f, 0.7, 1.8, { gain: 0.06, parts: [[1, 1], [2, 0.25]] }))
  },
  whoosh() { air(0, 1.9, 280, 3400, 0.1); note(180, 0, 1.7, { gain: 0.04, parts: [[1, 1]], glide: 520 }) },
  land() { note(659.25, 0, 0.5, { gain: 0.13 }); note(880, 0.12, 0.7, { gain: 0.12 }); note(1318.5, 0.26, 0.9, { gain: 0.07 }) },
}
