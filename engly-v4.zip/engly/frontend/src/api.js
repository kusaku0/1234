import { tg } from './tg.js'

// мини-апп живёт на /engly/ — все запросы должны идти туда же, а не в корень домена (там бэкенд ПДД)
const BASE = (import.meta.env.BASE_URL || '/').replace(/\/$/, '')
const TIMEOUT = 15000

function headers() {
  const h = { 'Content-Type': 'application/json' }
  if (tg?.initData) h['X-Init-Data'] = tg.initData
  if (['localhost', '127.0.0.1'].includes(location.hostname)) {
    const dev = new URLSearchParams(location.search).get('dev_user')
    if (dev) h['X-Dev-User'] = dev
  }
  return h
}

export class ApiError extends Error {
  constructor(status, detail) { super(String(detail)); this.status = status; this.detail = detail }
}

async function once(method, path, body) {
  const ctl = new AbortController()
  const timer = setTimeout(() => ctl.abort(), TIMEOUT)   // на плохой сети запрос не должен висеть вечно
  let res
  try {
    res = await fetch(BASE + path, { method, headers: headers(), body: body ? JSON.stringify(body) : undefined, signal: ctl.signal })
  } catch { throw new ApiError(0, 'network') } finally { clearTimeout(timer) }
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new ApiError(res.status, typeof data.error === 'string' ? data.error : typeof data.detail === 'string' ? data.detail : res.statusText)
  return data
}

// GET безопасно повторять; POST — нет (ответ мог дойти до сервера, повтор обрабатывает экран урока через 409/resync)
async function call(method, path, body) {
  try { return await once(method, path, body) } catch (e) {
    if (method === 'GET' && e.status === 0) return once(method, path, body)
    throw e
  }
}

export const api = {
  get: (p) => call('GET', p),
  post: (p, b) => call('POST', p, b || {}),
  del: (p) => call('DELETE', p),
  openInvoice: (link) => new Promise((resolve) => {
    if (tg?.openInvoice) tg.openInvoice(link, (s) => resolve(s))
    else { window.open(link, '_blank'); resolve('opened') }
  }),
}
