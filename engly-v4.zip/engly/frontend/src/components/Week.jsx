import { Icon } from './icons.jsx'

const DAYS = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс']
/* Неделя: по стрику восстанавливаем, какие дни подряд закрыты (стрик — это непрерывная серия до сегодня/вчера) */
export default function Week({ streak, doneToday }) {
  const now = new Date(), today = (now.getDay() + 6) % 7
  const last = doneToday ? today : today - 1          // последний закрытый день (может быть вчера)
  const cells = DAYS.map((d, i) => {
    const back = last - i                               // сколько дней назад от последнего закрытого
    const on = i <= last && back < streak
    return { d, on, today: i === today }
  })
  return <div className="week">{cells.map((c) => <div key={c.d} className={`d ${c.on ? 'on' : ''} ${c.today ? 'today' : ''}`}>{c.d}<i><Icon name="check" size={16} stroke={3} /></i></div>)}</div>
}
