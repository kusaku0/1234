import { useEffect, useRef } from 'react'
import { LAND, WATER } from '../data/world.js'

/* Точечный 3D-глобус на Canvas 2D: ноль зависимостей (≈6 КБ), 60 fps на слабых телефонах.
   Идея: суша = сетка точек по сфере, прошедших «точка в полигоне»; вращение = пересчёт проекции.
   Пролёт камеры: flyTo(lat, lon) → вращение с ease-in-out + экспоненциальный зум (zoom in к городу). */

const D2R = Math.PI / 180
const inPoly = (poly, x, y) => {
  let c = false
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i], [xj, yj] = poly[j]
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) c = !c
  }
  return c
}
const isLand = (lon, lat) => LAND.some((p) => inPoly(p, lon, lat)) && !WATER.some((p) => inPoly(p, lon, lat))

let DOTS = null, DENSE = null
let STEP = 2.6, DSTEP = 1.1
function buildDots(step) {
  const out = []
  for (let lat = -88; lat <= 88; lat += step) {
    const k = Math.max(0.12, Math.cos(lat * D2R))
    const ds = step / k
    for (let lon = -180; lon < 180; lon += ds) if (isLand(lon, lat)) out.push([lat * D2R, lon * D2R])
  }
  return out
}
const ease = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2)
const wrap = (a) => { while (a > Math.PI) a -= 2 * Math.PI; while (a < -Math.PI) a += 2 * Math.PI; return a }

export default function Globe({ pins = [], height = 300, interactive = true, spin = true, flyTo = null, onArrive, onPinClick, focus = null }) {
  const ref = useRef(null)
  const st = useRef({ lat: 0.35, lon: -0.6, zoom: 1, drag: null, fly: null, t0: performance.now(), arrived: false })
  const props = useRef({})
  props.current = { pins, onPinClick, onArrive, spin, interactive }

  // «фокус» — мягкий доворот к выбранной точке (клик по пину), без драматичного пролёта
  useEffect(() => {
    if (!focus) return
    const s = st.current
    s.fly = { from: { lat: s.lat, lon: s.lon, zoom: s.zoom }, to: { lat: focus.lat * D2R, lon: focus.lon * D2R, zoom: 1.15 }, t: performance.now(), dur: 900, soft: true }
  }, [focus?.lat, focus?.lon])

  // драматичный пролёт: разгон, оборот, зум к городу
  useEffect(() => {
    if (!flyTo) return
    const s = st.current
    s.arrived = false
    const reduce = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches
    s.fly = { from: { lat: s.lat, lon: s.lon, zoom: s.zoom }, to: { lat: flyTo.lat * D2R, lon: flyTo.lon * D2R, zoom: 3.6 }, t: performance.now(), dur: reduce ? 250 : (flyTo.dur || 2600), soft: false }
  }, [flyTo?.lat, flyTo?.lon, flyTo?.key])

  useEffect(() => {
    const cv = ref.current
    const ctx = cv.getContext('2d')
    const weak = (navigator.hardwareConcurrency || 4) <= 4
    if (!DOTS) { STEP = weak ? 3.4 : 2.6; DSTEP = weak ? 1.6 : 1.1; DOTS = buildDots(STEP) }
    const stars = Array.from({ length: 70 }, (_, i) => [((i * 97) % 100) / 100, ((i * 57 + 13) % 100) / 100, 0.4 + ((i * 31) % 10) / 12])
    let raf, alive = true, W = 0, H = 0

    const resize = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2)
      W = cv.clientWidth; H = height
      cv.width = W * dpr; cv.height = H * dpr
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
    resize()
    const ro = new ResizeObserver(resize); ro.observe(cv)

    const proj = (lat, lon, s, R, cx, cy) => {
      const dl = lon - s.lon, cl = Math.cos(lat), sl = Math.sin(lat)
      const x = cl * Math.sin(dl)
      const y = Math.cos(s.lat) * sl - Math.sin(s.lat) * cl * Math.cos(dl)
      const z = Math.sin(s.lat) * sl + Math.cos(s.lat) * cl * Math.cos(dl)
      return [cx + R * x, cy - R * y, z]
    }

    let pinHits = []
    const frame = (now) => {
      if (!alive) return
      raf = requestAnimationFrame(frame)
      if (document.hidden) return
      const s = st.current, p = props.current
      // --- анимация камеры
      if (s.fly) {
        const f = s.fly, u = Math.max(0, Math.min(1, (now - f.t) / f.dur)), e = ease(u)
        const dLon = wrap(f.to.lon - f.from.lon)
        const extra = f.soft ? 0 : Math.sign(dLon || 1) * 2 * Math.PI          // полный оборот сверху — эффект скорости
        s.lon = f.from.lon + (dLon + extra) * e
        s.lat = f.from.lat + (f.to.lat - f.from.lat) * e
        const zk = f.soft ? e : Math.pow(e, 2.2)                               // зум нарастает ближе к концу — «ныряем»
        s.zoom = f.from.zoom + (f.to.zoom - f.from.zoom) * zk
        if (u >= 1) { s.fly = null; s.lon = f.to.lon; s.lat = f.to.lat; if (!f.soft && !s.arrived) { s.arrived = true; p.onArrive?.() } }
      } else if (p.spin && !s.drag) {
        s.lon += 0.0016
      }
      // --- отрисовка
      ctx.clearRect(0, 0, W, H)
      const cx = W / 2, cy = H / 2, R = Math.min(W, H) * 0.4 * s.zoom
      for (const [sx, sy, sz] of stars) { ctx.globalAlpha = 0.25 + 0.45 * Math.abs(Math.sin(now / 900 + sx * 20)) * sz * 0.8; ctx.fillStyle = '#cfe0ff'; ctx.fillRect(sx * W, sy * H, 1.4, 1.4) }
      ctx.globalAlpha = 1
      // атмосфера
      const g = ctx.createRadialGradient(cx, cy, R * 0.92, cx, cy, R * 1.28)
      g.addColorStop(0, 'rgba(160,120,255,.5)'); g.addColorStop(0.35, 'rgba(124,92,255,.18)'); g.addColorStop(1, 'rgba(60,40,200,0)')
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(cx, cy, R * 1.28, 0, 7); ctx.fill()
      // океан
      const og = ctx.createRadialGradient(cx - R * 0.35, cy - R * 0.4, R * 0.1, cx, cy, R)
      og.addColorStop(0, '#3b3fb8'); og.addColorStop(0.6, '#1f1f78'); og.addColorStop(1, '#0b0a3a')
      ctx.fillStyle = og; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill()
      // сетка (меридианы/параллели) — лёгкая
      ctx.strokeStyle = 'rgba(120,160,255,.12)'; ctx.lineWidth = 1
      for (let lo = -180; lo < 180; lo += 30) {
        ctx.beginPath(); let pen = false
        for (let la = -90; la <= 90; la += 6) { const [x, y, z] = proj(la * D2R, lo * D2R, s, R, cx, cy); if (z > 0) { pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true } else pen = false }
        ctx.stroke()
      }
      for (let la = -60; la <= 60; la += 30) {
        ctx.beginPath(); let pen = false
        for (let lo = -180; lo <= 180; lo += 6) { const [x, y, z] = proj(la * D2R, lo * D2R, s, R, cx, cy); if (z > 0) { pen ? ctx.lineTo(x, y) : ctx.moveTo(x, y); pen = true } else pen = false }
        ctx.stroke()
      }
      // суша точками; при приближении подменяем сетку на плотную, чтобы не было «квадратов»
      const dense = s.zoom > 1.7
      if (dense && !DENSE) DENSE = buildDots(DSTEP)
      const set = dense ? DENSE : DOTS, stepRad = (dense ? DSTEP : STEP) * D2R
      const base = Math.max(0.8, R * stepRad * 0.26)
      for (let i = 0; i < set.length; i++) {
        const [la, lo] = set[i]
        const [x, y, z] = proj(la, lo, s, R, cx, cy)
        if (z <= 0.02) continue
        if (dense && (x < -10 || x > W + 10 || y < -10 || y > H + 10)) continue
        ctx.globalAlpha = 0.35 + 0.65 * z
        ctx.fillStyle = z > 0.75 ? '#9ff5d6' : z > 0.4 ? '#58d6c0' : '#3a9aa8'
        const r = base * (0.55 + 0.6 * z)
        if (r > 2.2) { ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill() } else ctx.fillRect(x - r, y - r, r * 2, r * 2)
      }
      ctx.globalAlpha = 1
      // блик
      const hg = ctx.createRadialGradient(cx - R * 0.45, cy - R * 0.5, 0, cx - R * 0.45, cy - R * 0.5, R * 0.9)
      hg.addColorStop(0, 'rgba(255,255,255,.16)'); hg.addColorStop(1, 'rgba(255,255,255,0)')
      ctx.fillStyle = hg; ctx.beginPath(); ctx.arc(cx, cy, R, 0, 7); ctx.fill()
      // пины
      pinHits = []
      for (const pin of p.pins) {
        const [x, y, z] = proj(pin.lat * D2R, pin.lon * D2R, s, R, cx, cy)
        if (z <= 0.08) continue
        const pulse = (Math.sin(now / 420 + pin.lon) + 1) / 2
        const col = pin.locked ? '#7a76aa' : pin.done ? '#38ef9e' : '#ffd35a'
        if (pin.pulse && !pin.locked) { ctx.strokeStyle = col; ctx.globalAlpha = 0.6 * (1 - pulse); ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(x, y, 10 + pulse * 16, 0, 7); ctx.stroke(); ctx.globalAlpha = 1 }
        ctx.fillStyle = 'rgba(8,12,30,.9)'; ctx.beginPath(); ctx.arc(x, y, 12, 0, 7); ctx.fill()
        ctx.strokeStyle = col; ctx.lineWidth = 2.5; ctx.stroke()
        ctx.font = '14px system-ui, "Apple Color Emoji", "Segoe UI Emoji"'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
        ctx.globalAlpha = pin.locked ? 0.5 : 1; ctx.fillText(pin.locked ? '🔒' : pin.emoji, x, y + 1); ctx.globalAlpha = 1
        if (pin.label && z > 0.5 && (pin.pulse || pin.selected)) {
          ctx.font = '700 12px system-ui, sans-serif'; const w = ctx.measureText(pin.label).width + 14
          ctx.fillStyle = 'rgba(8,12,30,.85)'; ctx.beginPath(); ctx.roundRect(x - w / 2, y + 17, w, 20, 10); ctx.fill()
          ctx.fillStyle = '#eef2ff'; ctx.fillText(pin.label, x, y + 28)
        }
        pinHits.push({ id: pin.id, x, y })
      }
      // «посадка»: вспышка света у города в конце пролёта
      if (s.fly && !s.fly.soft) {
        const u = Math.min(1, (now - s.fly.t) / s.fly.dur)
        if (u > 0.7) { ctx.fillStyle = `rgba(255,230,160,${(u - 0.7) / 0.3 * 0.5})`; ctx.beginPath(); ctx.arc(cx, cy, 8 + (u - 0.7) * 120, 0, 7); ctx.fill() }
      }
    }
    raf = requestAnimationFrame(frame)

    // ---- ввод: перетаскивание вращает глобус, тап по пину выбирает локацию
    const pos = (e) => { const r = cv.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top] }
    const down = (e) => { if (!props.current.interactive || st.current.fly) return; const [x, y] = pos(e); st.current.drag = { x, y, lon: st.current.lon, lat: st.current.lat, moved: false }; cv.setPointerCapture?.(e.pointerId) }
    const move = (e) => {
      const d = st.current.drag; if (!d) return
      const [x, y] = pos(e), dx = x - d.x, dy = y - d.y
      if (Math.abs(dx) + Math.abs(dy) > 5) d.moved = true
      const k = 1 / (Math.min(W, H) * 0.4 * st.current.zoom)
      st.current.lon = d.lon - dx * k; st.current.lat = Math.max(-1.2, Math.min(1.2, d.lat + dy * k))
    }
    const up = (e) => {
      const d = st.current.drag; st.current.drag = null
      if (d && !d.moved) {
        const [x, y] = pos(e)
        const hit = pinHits.find((h) => Math.hypot(h.x - x, h.y - y) < 22)
        if (hit) props.current.onPinClick?.(hit.id)
      }
    }
    cv.addEventListener('pointerdown', down); cv.addEventListener('pointermove', move)
    cv.addEventListener('pointerup', up); cv.addEventListener('pointercancel', up)
    return () => { alive = false; cancelAnimationFrame(raf); ro.disconnect(); cv.removeEventListener('pointerdown', down); cv.removeEventListener('pointermove', move); cv.removeEventListener('pointerup', up); cv.removeEventListener('pointercancel', up) }
  }, [height])

  return <canvas ref={ref} style={{ height, touchAction: interactive ? 'pan-y' : 'none' }} />
}
