import { Component, useId, useMemo } from 'react'
import { Icon } from './icons.jsx'
import Mascot from './Mascot.jsx'

export function Ring({ value, max, size = 84, stroke = 9, children }) {
  const id = useId().replace(/:/g, '')
  const r = (size - stroke) / 2, c = 2 * Math.PI * r, p = Math.max(0, Math.min(1, max ? value / max : 0))
  return (
    <div className="ring" style={{ width: size, height: size }}>
      <svg width={size} height={size}>
        <defs><linearGradient id={`g${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor={p >= 1 ? '#38ef9e' : '#ffd35a'} /><stop offset="1" stopColor={p >= 1 ? '#12c98a' : '#ff8a4c'} /></linearGradient></defs>
        <circle cx={size / 2} cy={size / 2} r={r} className="ring-bg" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={`url(#g${id})`} strokeWidth={stroke} fill="none" strokeLinecap="round"
          strokeDasharray={c} strokeDashoffset={c * (1 - p)} style={{ transition: 'stroke-dashoffset .8s cubic-bezier(.3,.8,.3,1)' }} />
      </svg>
      <div className="rc"><div>{children}</div></div>
    </div>
  )
}

export function Confetti({ n = 34 }) {
  const bits = useMemo(() => Array.from({ length: n }, (_, i) => ({
    left: Math.random() * 100, delay: Math.random() * 0.5, c: ['#ffd35a', '#38ef9e', '#43c6ff', '#ff5fa2', '#9a7bff'][i % 5], d: 1.8 + Math.random() * 1.4, w: 6 + Math.random() * 6, round: i % 3 === 0 })), [n])
  return <div className="confetti">{bits.map((b, i) => <i key={i} style={{ left: `${b.left}%`, background: b.c, width: b.w, height: b.round ? b.w : b.w * 1.6, borderRadius: b.round ? '50%' : 2, animationDelay: `${b.delay}s`, animationDuration: `${b.d}s` }} />)}</div>
}

export const Skel = ({ h = 220 }) => <div className="skel" style={{ height: h }} />

export function ErrorBox({ onRetry, text = 'Не удалось загрузить. Проверь соединение.' }) {
  return (
    <div className="card center" style={{ padding: 26 }}>
      <Mascot mood="sad" size={96} />
      <p className="muted" style={{ margin: '8px 0 14px' }}>{text}</p>
      {onRetry && <button className="btn ghost" onClick={onRetry}><Icon name="repeat" size={18} />Повторить</button>}
    </div>
  )
}

export function Sheet({ open, onClose, children }) {
  if (!open) return null
  return <><div className="backdrop" onClick={onClose} /><div className="sheet"><div className="grab" />{children}</div></>
}

export function Segmented({ value, options, onChange }) {
  return (
    <div className="seg" role="tablist">
      {options.map((o) => (
        <button key={o.v} role="tab" aria-selected={value === o.v} className={value === o.v ? 'on' : ''} onClick={() => onChange(o.v)}>
          {o.icon && <Icon name={o.icon} size={16} />}{o.t}
        </button>))}
    </div>
  )
}

export function Switch({ on, onChange, label }) {
  return <button className={`switch ${on ? 'on' : ''}`} role="switch" aria-checked={on} aria-label={label} onClick={() => onChange(!on)}><i /></button>
}

export function Reward({ mood = 'cheer', title, sub, xp, chips = [], achievements = [], stars, children, cta = 'Продолжить', onClose, confetti = true }) {
  return (
    <div className="reward fade-up">
      {confetti && <Confetti />}
      <div className="reward-halo"><Mascot mood={mood} size={128} float /></div>
      {stars != null && <div className="stars">{[0, 1, 2].map((k) => <span key={k} className={k < stars ? '' : 'off'} style={{ animationDelay: `${0.25 + k * 0.22}s` }}><Icon name="star" size={46} fill="currentColor" stroke={1.5} /></span>)}</div>}
      <h2 className="reward-title">{title}</h2>
      {sub && <p className="muted" style={{ margin: '4px 16px 0' }}>{sub}</p>}
      {xp != null && <div className="bigxp"><Icon name="bolt" size={34} />+{xp} XP</div>}
      <div className="chips">{chips.filter(Boolean).map((c, i) => <span key={i} className="chip" style={{ animationDelay: `${0.3 + i * 0.1}s` }}>{c}</span>)}</div>
      {children}
      {achievements.map((a) => (
        <div className="ach" key={a.code}><span className="e">{a.emoji}</span><div><b>{a.title}</b><div className="muted" style={{ fontSize: 12.5 }}>{a.desc} · +{a.tickets} <Icon name="plane" size={12} /></div></div></div>
      ))}
      <button className="btn" style={{ marginTop: 18 }} onClick={onClose}>{cta}</button>
    </div>
  )
}

/* «Слово» с подсвеченным вхождением в примере */
export function Highlight({ text, word }) {
  if (!text || !word) return text
  const i = text.toLowerCase().indexOf(word.toLowerCase())
  if (i < 0) return text
  return <>{text.slice(0, i)}<mark>{text.slice(i, i + word.length)}</mark>{text.slice(i + word.length)}</>
}

/* Любая неожиданная ошибка отрисовки — не белый экран, а понятное сообщение и перезапуск */
export class ErrorBoundary extends Component {
  state = { failed: false }
  static getDerivedStateFromError() { return { failed: true } }
  componentDidCatch(e) { try { console.error(e) } catch {} }
  render() {
    if (!this.state.failed) return this.props.children
    return <div style={{ padding: 16 }}><ErrorBox text="Что-то пошло не так. Прогресс сохранён — перезапусти экран." onRetry={() => location.reload()} /></div>
  }
}
