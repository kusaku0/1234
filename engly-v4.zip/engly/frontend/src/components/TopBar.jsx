import { Icon } from './icons.jsx'
import Mascot from './Mascot.jsx'

/* Шапка: логотип, стрик, билеты, переключатели темы и звука */
export default function TopBar({ profile, theme, sound, toggleSound, sub = 'учись с нуля' }) {
  return (
    <div className="topbar">
      <div className="brand"><Mascot size={44} /><h1>Engly<small>{sub}</small></h1></div>
      <div className="pills">
        <span className="pill fire"><Icon name="flame" size={17} />{profile?.streak ?? 0}</span>
        <span className="pill tix"><Icon name="plane" size={16} />{profile?.tickets ?? 0}</span>
        <button className="icon-btn sm tap" onClick={theme.toggle} aria-label="Сменить тему"><Icon name={theme.resolved === 'dark' ? 'sun' : 'moon'} size={19} /></button>
        <button className="icon-btn sm tap" onClick={toggleSound} aria-label="Звук"><Icon name={sound ? 'volume' : 'mute'} size={19} /></button>
      </div>
    </div>
  )
}
