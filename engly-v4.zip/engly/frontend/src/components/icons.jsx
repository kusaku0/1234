/* Набор SVG-иконок Engly (24×24, скруглённые линии). Вместо эмодзи в интерфейсе — единый стиль. */
const P = {
  path: <><circle cx="6" cy="18" r="2.4" /><circle cx="18" cy="6" r="2.4" /><path d="M8.2 17h5.3a3.5 3.5 0 0 0 0-7h-3a3.5 3.5 0 0 1 0-7h5.3" /></>,
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" /></>,
  bolt: <path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12l1-8Z" />,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4.5 21c0-4.2 3.4-6.8 7.5-6.8s7.5 2.6 7.5 6.8" /></>,
  book: <><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H20v15H6.5A2.5 2.5 0 0 0 4 20.5v-15Z" /><path d="M4 20.5A2.5 2.5 0 0 0 6.5 23H20v-5" /></>,
  flame: <path d="M12 2.5c.8 3.6 5.2 5.6 5.2 10.2a5.2 5.2 0 0 1-10.4 0c0-2 .9-3.2 2-4.2.3 1.3 1 2 2 2.2-.8-3.2-.2-5.4 1.2-8.2Z" />,
  plane: <><path d="M21 3 3 10.4l7 3.1 3.1 7L21 3Z" /><path d="m10 13.5 4.8-4.8" /></>,
  star: <path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9L12 3Z" />,
  check: <path d="m5 12.5 4.5 4.5L19 7.5" />,
  x: <path d="M6 6l12 12M18 6 6 18" />,
  volume: <><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4Z" /><path d="M15.5 9a4 4 0 0 1 0 6M18 6.5a8 8 0 0 1 0 11" /></>,
  mute: <><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5H4Z" /><path d="m16 9.5 5 5M21 9.5l-5 5" /></>,
  mic: <><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3" /></>,
  lock: <><rect x="5" y="10.5" width="14" height="10" rx="3" /><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5" /></>,
  sun: <><circle cx="12" cy="12" r="4" /><path d="M12 2.5v2M12 19.5v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2.5 12h2M19.5 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>,
  moon: <path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5Z" />,
  auto: <><circle cx="12" cy="12" r="9" /><path d="M12 3a9 9 0 0 1 0 18Z" fill="currentColor" /></>,
  right: <path d="m9 6 6 6-6 6" />,
  left: <path d="M19 12H5M11 6l-6 6 6 6" />,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
  repeat: <><path d="M3.5 12a8.5 8.5 0 0 1 14.6-5.9L20.5 8.5" /><path d="M20.5 3.5v5h-5" /><path d="M20.5 12a8.5 8.5 0 0 1-14.6 5.9L3.5 15.5" /><path d="M3.5 20.5v-5h5" /></>,
  headphones: <><path d="M4 15v-3a8 8 0 0 1 16 0v3" /><rect x="3" y="14" width="4" height="7" rx="2" /><rect x="17" y="14" width="4" height="7" rx="2" /></>,
  pencil: <><path d="M4 20h4L19.5 8.5a2.8 2.8 0 0 0-4-4L4 16v4Z" /><path d="m13.5 6.5 4 4" /></>,
  image: <><rect x="3" y="4" width="18" height="16" rx="3" /><circle cx="9" cy="10" r="2" /><path d="m21 16-5-5-9 9" /></>,
  blocks: <><rect x="3" y="3" width="8" height="8" rx="2.2" /><rect x="13" y="3" width="8" height="8" rx="2.2" /><rect x="3" y="13" width="8" height="8" rx="2.2" /><rect x="13" y="13" width="8" height="8" rx="2.2" /></>,
  cards: <><rect x="3" y="7" width="14" height="14" rx="3" /><path d="M7 3.5h10.5A3.5 3.5 0 0 1 21 7v10.5" /></>,
  trophy: <><path d="M8 4h8v6a4 4 0 0 1-8 0V4Z" /><path d="M8 6H4v1a4 4 0 0 0 4 4M16 6h4v1a4 4 0 0 1-4 4M12 14v4M8 21h8M9.5 18h5" /></>,
  snow: <path d="M12 2.5v19M4 7.2l16 9.6M20 7.2 4 16.8M9.5 4 12 6l2.5-2M9.5 20 12 18l2.5 2" />,
  sliders: <><path d="M4 6h9M19 6h1M4 12h2M12 12h8M4 18h11M21 18h-1" /><circle cx="16" cy="6" r="2.2" /><circle cx="9" cy="12" r="2.2" /><circle cx="17.5" cy="18" r="2.2" /></>,
  gift: <><rect x="3" y="8" width="18" height="4.5" rx="1.2" /><path d="M5 12.5V20h14v-7.5M12 8v12M12 8C9.5 8 8 6.8 8 5.5S9.2 3 10.7 4 12 8 12 8Zm0 0c2.5 0 4-1.2 4-2.5S14.8 3 13.3 4 12 8 12 8Z" /></>,
  play: <path d="M8 5.5v13l11-6.5-11-6.5Z" />,
  gem: <><path d="M6 3.5h12L22 9.5 12 21 2 9.5l4-6Z" /><path d="M2 9.5h20M9 3.5l3 17.5 3-17.5" /></>,
  chart: <path d="M5 20V11M11 20V4M17 20v-6M3 20h18" />,
  sparkles: <><path d="M11 3l1.9 5.1L18 10l-5.1 1.9L11 17l-1.9-5.1L4 10l5.1-1.9L11 3Z" /><path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9L19 15Z" /></>,
  flag: <path d="M5 21V4M5 4h11l-2 4 2 4H5" />,
  heart: <path d="M12 20.5S3.5 15.4 3.5 9.2A4.7 4.7 0 0 1 12 6.6a4.7 4.7 0 0 1 8.5 2.6c0 6.2-8.5 11.3-8.5 11.3Z" />,
  plus: <path d="M12 5v14M5 12h14" />,
  info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v5M12 8v.01" /></>,
  translate: <><path d="M4 5h9M8.5 3v2M6 5c.5 4 3 7 6 8M11.5 5c-.5 4-3 7-7 9" /><path d="m13 21 4-9 4 9M14.4 18h5.2" /></>,
  eye: <><path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z" /><circle cx="12" cy="12" r="2.8" /></>,
  eyeoff: <><path d="M3 3l18 18M9.9 5.7A9.5 9.5 0 0 1 12 5.5c6 0 9.5 6.5 9.5 6.5a16 16 0 0 1-3 3.7M6.3 7.4A15.5 15.5 0 0 0 2.5 12S6 18.5 12 18.5c1.4 0 2.7-.4 3.8-.9" /></>,
}
const FILLED = new Set(['flame', 'play', 'bolt'])

export function Icon({ name, size = 22, stroke = 2, fill, style, className }) {
  const f = fill ?? (FILLED.has(name) ? 'currentColor' : 'none')
  return (
    <svg className={className} style={style} width={size} height={size} viewBox="0 0 24 24" fill={f} stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{P[name]}</svg>
  )
}
