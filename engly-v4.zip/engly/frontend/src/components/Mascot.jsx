import { useId } from 'react'

/* Лу — сова-путешественница, талисман Engly. Настроения: happy · cheer · sad · think · sleep */
export default function Mascot({ mood = 'happy', size = 120, float = false, style }) {
  const id = useId().replace(/:/g, '')
  const sad = mood === 'sad', cheer = mood === 'cheer', sleep = mood === 'sleep', think = mood === 'think'
  const pupil = sad ? [0, 3] : think ? [4, -3] : [0, 1]
  return (
    <svg className={float ? 'mascot-float' : ''} width={size} height={size} viewBox="0 0 120 120" style={style} aria-hidden="true">
      <defs>
        <linearGradient id={`b${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#9a7bff" /><stop offset="1" stopColor="#6a3fe8" /></linearGradient>
        <linearGradient id={`w${id}`} x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#7c5cff" /><stop offset="1" stopColor="#5a32d6" /></linearGradient>
        <linearGradient id={`s${id}`} x1="0" y1="0" x2="1" y2="0"><stop offset="0" stopColor="#ff7ab8" /><stop offset="1" stopColor="#ff4f93" /></linearGradient>
      </defs>
      <ellipse cx="60" cy="112" rx="30" ry="5" fill="rgba(0,0,0,.18)" />
      {/* уши-хохолки */}
      <path d="M31 40 25 15l23 15Z" fill={`url(#w${id})`} /><path d="M89 40l6-25-23 15Z" fill={`url(#w${id})`} />
      {/* крылья */}
      <g style={{ transformOrigin: '30px 70px', transform: cheer ? 'rotate(24deg)' : 'none' }}><path d="M26 64c-14 8-15 26-3 38 11-4 15-16 14-34Z" fill={`url(#w${id})`} /></g>
      <g style={{ transformOrigin: '90px 70px', transform: cheer ? 'rotate(-24deg)' : 'none' }}><path d="M94 64c14 8 15 26 3 38-11-4-15-16-14-34Z" fill={`url(#w${id})`} /></g>
      {/* тело и пузико */}
      <ellipse cx="60" cy="66" rx="38" ry="41" fill={`url(#b${id})`} />
      <ellipse cx="60" cy="81" rx="23" ry="25" fill="#f4eeff" />
      <path d="M46 78q4 5 8 0M58 86q4 5 8 0M50 92q4 5 8 0" stroke="#d8c9ff" strokeWidth="2.4" strokeLinecap="round" fill="none" />
      {/* глаза */}
      {sleep || cheer ? (
        <g stroke="#1b1740" strokeWidth="4" strokeLinecap="round" fill="none">
          <path d={cheer ? 'M33 57q10-12 20 0' : 'M33 54q10 8 20 0'} /><path d={cheer ? 'M67 57q10-12 20 0' : 'M67 54q10 8 20 0'} />
        </g>
      ) : (
        <g className="mascot-eyes">
          <circle cx="44" cy="55" r="15" fill="#fff" /><circle cx="76" cy="55" r="15" fill="#fff" />
          <circle cx={44 + pupil[0]} cy={55 + pupil[1]} r="8" fill="#1b1740" /><circle cx={76 + pupil[0]} cy={55 + pupil[1]} r="8" fill="#1b1740" />
          <circle cx={47 + pupil[0]} cy={52 + pupil[1]} r="2.8" fill="#fff" /><circle cx={79 + pupil[0]} cy={52 + pupil[1]} r="2.8" fill="#fff" />
        </g>
      )}
      {sad && <><path d="M31 38l20 6M89 38l-20 6" stroke="#2a1f66" strokeWidth="3.4" strokeLinecap="round" /><path d="M86 66c3 5 5 8 0 10-5-2-3-5 0-10Z" fill="#6ad0ff" /></>}
      {think && <path d="M29 42l20-4M91 40l-20-2" stroke="#2a1f66" strokeWidth="3.4" strokeLinecap="round" />}
      {/* румянец, клюв */}
      <circle cx="31" cy="70" r="5" fill="#ff8fb8" opacity=".55" /><circle cx="89" cy="70" r="5" fill="#ff8fb8" opacity=".55" />
      <path d="M53 66h14l-7 11Z" fill="#ffb347" /><path d="M53 66h14l-7 4Z" fill="#ffd27a" />
      {cheer && <path d="M52 80q8 8 16 0" stroke="#e8627a" strokeWidth="3" strokeLinecap="round" fill="none" />}
      {/* шарф */}
      <path d="M33 94q27 13 54 0l-2 9q-25 12-50 0Z" fill={`url(#s${id})`} /><path d="M82 100l6 14 7-3-4-13Z" fill="#ff4f93" />
      <ellipse cx="48" cy="109" rx="7" ry="3.4" fill="#ffb347" /><ellipse cx="72" cy="109" rx="7" ry="3.4" fill="#ffb347" />
    </svg>
  )
}
