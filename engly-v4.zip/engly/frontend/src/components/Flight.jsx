import { useEffect, useState } from 'react'
import Globe from './Globe.jsx'
import Mascot from './Mascot.jsx'
import { sfx } from '../sfx.js'

/* Кинематографичный пролёт: глобус разгоняется, камера ныряет к городу (zoom in), вспышка → локация. */
export default function Flight({ loc, onArrive }) {
  const [flash, setFlash] = useState(false)
  useEffect(() => { sfx.whoosh() }, [])
  const arrive = () => { sfx.land(); setFlash(true); setTimeout(onArrive, 450) }
  return (
    <div className="flight" style={{ position: 'fixed', inset: 0, zIndex: 60, background: 'radial-gradient(circle at 50% 45%, #1b1a6b, #04031a 80%)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
      <Globe height={Math.min(window.innerHeight * 0.62, 520)} interactive={false} spin={false}
        flyTo={{ lat: loc.lat, lon: loc.lon, key: loc.id, dur: 2800 }} onArrive={arrive}
        pins={[{ id: loc.id, lat: loc.lat, lon: loc.lon, emoji: loc.emoji, label: loc.city, pulse: true }]} />
      <div className="fade-up" style={{ position: 'absolute', left: 0, right: 0, bottom: '12%', textAlign: 'center', color: '#fff' }}>
        <Mascot mood="cheer" size={70} float />
        <h2 style={{ fontSize: 26, margin: '4px 0 0' }}>Летим: {loc.city}</h2><p style={{ margin: '6px 0 0', opacity: .75 }}>{loc.place} · {loc.country}</p>
      </div>
      {flash && <div style={{ position: 'fixed', inset: 0, zIndex: 61, background: '#fff', pointerEvents: 'none', animation: 'fadeUp .6s ease reverse forwards' }} />}
    </div>
  )
}
