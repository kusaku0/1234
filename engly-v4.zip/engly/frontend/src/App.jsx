import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from './api.js'
import { setupTelegram, tg } from './tg.js'
import { sfx } from './sfx.js'
import { useTheme } from './theme.js'
import Flight from './components/Flight.jsx'
import { Icon } from './components/icons.jsx'
import Mascot from './components/Mascot.jsx'
import { ErrorBox } from './components/ui.jsx'
import Lesson from './screens/Lesson.jsx'
import Location from './screens/Location.jsx'
import Mistakes from './screens/Mistakes.jsx'
import Onboarding from './screens/Onboarding.jsx'
import Paywall from './screens/Paywall.jsx'
import Path from './screens/Path.jsx'
import Practice from './screens/Practice.jsx'
import Profile from './screens/Profile.jsx'
import { Flashcards, Vocab } from './screens/Vocab.jsx'
import World from './screens/World.jsx'

/* Экраны: boot → [onboarding] → main (🛤 Путь | 🌍 Мир | ⚡ Практика | 👤 Профиль);
   поверх: lesson, flight → location, mistakes, vocab, flash, paywall */
const TABS = [['path', 'path', 'Путь'], ['world', 'globe', 'Мир'], ['practice', 'bolt', 'Практика'], ['profile', 'user', 'Профиль']]

export default function App() {
  const theme = useTheme()
  const [profile, setProfile] = useState(null)
  const [view, setView] = useState('boot')
  const [tab, setTab] = useState('path')
  const [lessonCtx, setLessonCtx] = useState(null)
  const [lessonKey, setLessonKey] = useState(0)
  const [locData, setLocData] = useState(null)
  const [flight, setFlight] = useState(null)
  const [paywall, setPaywall] = useState(null)
  const [bootErr, setBootErr] = useState(null)
  const lastRefresh = useRef(0)
  const [retest, setRetest] = useState(false)
  const [rk, setRk] = useState(0)                  // перезагрузка карты пути после урока
  const [sound, setSound] = useState(!sfx.muted)
  const startRef = useRef(null)
  const goBack = useRef(() => {})

  const refresh = useCallback(() => {
    lastRefresh.current = Date.now()
    return api.get('/api/profile').then((p) => { setProfile(p); return p }).catch((e) => { refresh.err = e; return null })
  }, [])
  const boot = useCallback(async () => {
    setBootErr(null)
    const p = await refresh()
    if (!p) return setBootErr(refresh.err?.status === 401 ? 'auth' : 'net')
    setView(p.onboarded ? 'main' : 'onboarding')
    api.post('/api/event', { name: 'app_open' }).catch(() => {})
  }, [refresh])
  useEffect(() => {
    setupTelegram(); boot()
    const unlock = () => sfx.unlock()                // iOS: аудио оживает после первого касания
    window.addEventListener('pointerdown', unlock, { once: true })
    return () => window.removeEventListener('pointerdown', unlock)
  }, [boot])

  const toggleSound = () => { const m = sound; sfx.setMuted(m); setSound(!m); if (m) { sfx.unlock(); sfx.toggle(true) } }
  const startLesson = (ctx) => { sfx.unlock(); setLessonCtx(ctx); setLessonKey((k) => k + 1); setView('lesson') }
  const home = () => { refresh(); setRk((k) => k + 1); setView('main') }
  const nextPath = async () => {
    const p = await api.get('/api/path').catch(() => null)
    refresh(); setRk((k) => k + 1)
    if (p?.current) startLesson({ mode: 'path', level: p.current.level, topic: p.current.topic }); else home()
  }

  const fly = (loc) => {
    sfx.unlock()
    startRef.current = api.post('/api/location/start', { loc_id: loc.id }).then((d) => ({ d })).catch((e) => ({ e }))
    setFlight(loc)
  }
  const arrived = async () => {
    const r = await startRef.current
    setFlight(null)
    if (r.e) { if (r.e.status === 402) setPaywall({ reason: 'limit' }); return }
    setLocData(r.d); setView('location')
  }
  const limit = () => setPaywall({ reason: 'limit', inLesson: view === 'lesson' })

  goBack.current = () => { if (paywall) setPaywall(null); else if (view === 'lesson' || view === 'location') home(); else setView('main') }
  useEffect(() => {          // кнопка «назад» Telegram синхронизирована с внутренней навигацией
    const bb = tg?.BackButton
    if (!bb) return
    const h = () => goBack.current()
    if ((view !== 'main' && view !== 'boot' && view !== 'onboarding') || paywall) { bb.show(); bb.onClick(h) } else bb.hide()
    return () => bb.offClick(h)
  }, [view, paywall])

  if (view === 'boot') return bootErr ? <ErrorBox onRetry={boot} text={bootErr === 'auth' ? 'Сессия устарела или приложение открыто не из Telegram. Закрой Engly и открой снова через бота.' : undefined} /> : <div className="splash"><Mascot mood="happy" size={130} float /><h1 className="grad-text" style={{ fontSize: 34, fontWeight: 950 }}>Engly</h1></div>

  const due = profile?.srs?.due ?? 0
  const common = { profile, theme, sound, toggleSound }
  return (
    <div>
      {view === 'onboarding' && (
        <Onboarding initialStep={retest ? 'test' : 'welcome'} initialGoal={retest ? profile?.goal : null} initialMinutes={retest ? profile?.minutes : null}
          onCancel={retest ? () => { setRetest(false); setView('main') } : null} onDone={async () => {
          const p = await refresh(); setRetest(false); setRk((k) => k + 1)
          const path = await api.get('/api/path').catch(() => null)
          if (path?.current && !p?.streak && !retest) startLesson({ mode: 'path', level: path.current.level, topic: path.current.topic }); else setView('main')
        }} />)}

      {view === 'main' && <>
        {tab === 'path' && <Path {...common} refreshKey={rk} onStart={startLesson} onReview={() => startLesson({ mode: 'review' })} />}
        {tab === 'world' && <World {...common} onFly={fly} />}
        {tab === 'practice' && <Practice {...common} onDrill={(kind) => { api.post('/api/event', { name: 'drill_open', payload: { kind } }).catch(() => {}); startLesson({ mode: 'drill', kind }) }}
          onReview={() => startLesson({ mode: 'review' })} onVocab={() => setView('vocab')} onFlash={() => setView('flash')} />}
        {tab === 'profile' && <Profile {...common} refresh={refresh} showPaywall={limit} onMistakes={() => setView('mistakes')} onVocab={() => setView('vocab')}
          onRetest={() => { setRetest(true); setView('onboarding') }}
          onDeleted={() => { setTab('path'); setProfile(null); setRk((k) => k + 1); boot() }} />}
        <nav className="nav"><div>
          {TABS.map(([id, ic, t]) => (
            <button key={id} className={tab === id ? 'on' : ''} onClick={() => { setTab(id); if (Date.now() - lastRefresh.current > 15000) refresh(); sfx.tap() }}>
              <Icon name={ic} size={23} />{t}{id === 'practice' && due > 0 && <span className="dot">{due > 99 ? '99' : due}</span>}</button>))}
        </div></nav>
      </>}

      {view === 'lesson' && lessonCtx && <Lesson key={lessonKey} {...lessonCtx} onExit={home} onNext={nextPath} onPaywall={limit} />}
      {view === 'location' && locData && <Location data={locData} onExit={home} onPaywall={limit} />}
      {view === 'mistakes' && <Mistakes profile={profile} refresh={refresh} onBack={() => setView('main')} showPaywall={() => setPaywall({ reason: 'analysis' })} />}
      {view === 'vocab' && <Vocab onBack={() => setView('main')} onFlash={() => setView('flash')} />}
      {view === 'flash' && <Flashcards onBack={() => setView('main')} />}

      {flight && <Flight loc={flight} onArrive={arrived} />}
      {paywall && <Paywall reason={paywall.reason} profile={profile} onClose={async () => { const pw = paywall; setPaywall(null); const p = await refresh(); if (pw.inLesson && p?.is_premium) setLessonKey((k) => k + 1) }} refresh={refresh} />}
    </div>
  )
}
