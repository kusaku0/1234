import { useEffect, useRef, useState } from 'react'
import { api } from '../api.js'
import { haptic, speak, ttsAvailable } from '../tg.js'
import { sfx } from '../sfx.js'
import Globe from '../components/Globe.jsx'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'
import { ErrorBox, Skel } from '../components/ui.jsx'

const GOALS = [
  { id: 'travel', e: '✈️', t: 'Путешествия', s: 'Отели, кафе, дорога' },
  { id: 'work', e: '💼', t: 'Работа и карьера', s: 'Собеседования, переписка' },
  { id: 'study', e: '🎓', t: 'Учёба и экзамены', s: 'Академический английский' },
  { id: 'relocate', e: '🏡', t: 'Переезд', s: 'Жизнь в другой стране' },
  { id: 'fun', e: '🎬', t: 'Фильмы и общение', s: 'Понимать и болтать' },
]
const MINUTES = [
  { v: 5, e: '🌱', t: '5 минут', s: 'Лёгкий старт · 20 XP в день' },
  { v: 10, e: '🔥', t: '10 минут', s: 'Обычный · 40 XP в день' },
  { v: 15, e: '💪', t: '15 минут', s: 'Серьёзный · 60 XP в день' },
  { v: 20, e: '🚀', t: '20 минут', s: 'Интенсив · 80 XP в день' },
]
const ev = (step) => api.post('/api/event', { name: 'onboarding_step', payload: { step } }).catch(() => {})
const Bar = ({ v }) => <div className="progress thin" style={{ marginBottom: 20 }}><i style={{ width: `${v}%` }} /></div>

/* Первые 60 секунд: приветствие → цель → время → «с нуля или проверить уровень» → (тест) → план → первый урок.
   Новичку тест не навязываем: «Начну с нуля» — самый заметный вариант. */
export default function Onboarding({ onDone, onCancel = null, initialStep = 'welcome', initialGoal = null, initialMinutes = null }) {
  const [step, setStep] = useState(initialStep)
  const [goal, setGoal] = useState(initialGoal)
  const [minutes, setMinutes] = useState(initialMinutes)
  const [busy, setBusy] = useState(false)
  const [result, setResult] = useState(null)
  const [fail, setFail] = useState(false)
  const go = (s) => { setStep(s); ev(s); sfx.pop(); haptic.tap() }

  if (step === 'welcome') return (
    <div className="ob fade-up">
      <div className="grow center" style={{ paddingTop: 18 }}>
        <div className="globe-hero"><Globe pins={[]} height={250} interactive={false} spin /></div>
        <div style={{ marginTop: -26, position: 'relative' }}><Mascot mood="cheer" size={92} float /></div>
        <h1 style={{ marginTop: 4 }}>Английский<br /><span className="grad-text">с нуля до свободы</span></h1>
        <p className="muted" style={{ fontSize: 16, margin: '10px 8px 14px' }}>По одному слову: картинка, звук, пример. Потом — путешествие по миру и живые диалоги.</p>
        {[['image', 'Слова с картинками', 'запоминаются сами'], ['repeat', 'Умные повторения', 'слова возвращаются вовремя'], ['globe', '10 локаций мира', 'говори в Париже, Токио, Нью-Йорке']].map(([i, t, s]) => (
          <div className="feat" key={t}><span className="e"><Icon name={i} size={24} /></span><div><b>{t}</b><div className="muted" style={{ fontSize: 13 }}>{s}</div></div></div>))}
      </div>
      <div className="foot2"><button className="btn shine" onClick={() => { sfx.unlock(); go('goal') }}>Начать</button></div>
    </div>)

  if (step === 'goal') return (
    <div className="ob fade-up"><Bar v={25} />
      <h2>Зачем тебе английский?</h2><p className="muted">Подберём темы под твою цель</p>
      <div className="grow">{GOALS.map((g) => (
        <button key={g.id} className={`pick tap ${goal === g.id ? 'sel' : ''}`} onClick={() => { setGoal(g.id); sfx.select(); haptic.tap() }}>
          <span className="e">{g.e}</span><span>{g.t}<small>{g.s}</small></span></button>))}</div>
      <div className="foot2"><button className="btn" disabled={!goal} onClick={() => go('minutes')}>Дальше</button></div>
    </div>)

  if (step === 'minutes') return (
    <div className="ob fade-up"><Bar v={50} />
      <h2>Сколько минут в день?</h2><p className="muted">Это твоя дневная цель по очкам опыта (XP) — не жёсткий таймер</p>
      <div className="grow">{MINUTES.map((m) => (
        <button key={m.v} className={`pick tap ${minutes === m.v ? 'sel' : ''}`} onClick={() => { setMinutes(m.v); sfx.select(); haptic.tap() }}>
          <span className="e">{m.e}</span><span>{m.t}<small>{m.s}</small></span></button>))}</div>
      <div className="foot2"><button className="btn" disabled={!minutes} onClick={() => go('start')}>Дальше</button></div>
    </div>)

  if (step === 'start') {
    const zero = async () => {
      setBusy(true); setFail(false); sfx.pop()
      try { const r = await api.post('/api/placement/skip', { goal, minutes }); onDone(r) } catch { setBusy(false); setFail(true) }
    }
    return (
      <div className="ob fade-up"><Bar v={75} />
        <h2>С чего начнём?</h2><p className="muted">Можно изменить позже в профиле</p>
        <div className="grow">
          <button className="pick hot tap" disabled={busy} onClick={zero}><span className="e">🌱</span><span>Начну с нуля<small>Самые простые слова, по одному. Лучший выбор для новичка</small></span></button>
          <button className="pick tap" disabled={busy} onClick={() => go('test')}><span className="e">🎯</span><span>Проверю свой уровень<small>Адаптивный тест, около 2 минут</small></span></button>
          {fail && <p className="err" role="alert">Не получилось начать. Проверь соединение и попробуй ещё раз.</p>}
          <div style={{ textAlign: 'center', marginTop: 26 }}><Mascot mood="happy" size={96} float /></div>
        </div>
      </div>)
  }

  if (step === 'test') return (
    <PlacementTest goal={goal} minutes={minutes} onCancel={onCancel}
      onResult={(r) => { setResult(r); setStep('result'); ev('result'); sfx.done(); haptic.ok() }} />
  )

  return <ResultScreen r={result} onGo={() => onDone(result)} />
}

/* ---------- адаптивный тест: сервер выбирает следующий вопрос по ответам ---------- */
function PlacementTest({ goal, minutes, onResult, onCancel }) {
  const [sess, setSess] = useState(null)   // {session_id, question}
  const [picked, setPicked] = useState(null)
  const [verdict, setVerdict] = useState(null)
  const [err, setErr] = useState(false)
  const [soft, setSoft] = useState('')
  const lock = useRef(false)

  const start = () => { setErr(false); api.post('/api/placement/start', { goal, minutes }).then(setSess).catch(() => setErr(true)) }
  useEffect(start, [])

  if (err) return <ErrorBox onRetry={start} />
  if (!sess) return <Skel />
  const q = sess.question

  const answer = async (opt) => {
    if (lock.current) return
    lock.current = true
    setPicked(opt ?? '__skip'); setSoft('')
    try {
      const r = await api.post('/api/placement/answer', { session_id: sess.session_id, question_id: q.id, answer: opt })
      setVerdict(r.ok ? 'ok' : 'bad')
      r.ok ? (sfx.ok(), haptic.ok()) : (sfx.bad(), haptic.bad())
      await new Promise((res) => setTimeout(res, 650))
      if (r.done) onResult(r.result)
      else { setSess({ ...sess, question: r.question }); setPicked(null); setVerdict(null) }
    } catch { setPicked(null); setSoft('Нет связи — ответ не потерян, нажми ещё раз') }   // тест не сбрасываем из-за одного сбоя сети
    lock.current = false
  }

  return (
    <div className="fade-up" key={q.id}>
      {onCancel && <button className="btn link" style={{ width: 'auto', padding: '4px 0', marginBottom: 6 }} onClick={onCancel}>← Отмена, вернуться в профиль</button>}
      <div className="progress thin" style={{ marginBottom: 8 }}><i style={{ width: `${((q.n - 1) / q.max) * 100}%` }} /></div>
      <p className="muted center" style={{ fontSize: 13, margin: '0 0 12px' }}>Вопрос {q.n} · тест подстраивается под тебя</p>
      <div className="qcard">
        <p className="qsub">{q.instr}</p>
        <div className={`qword ${q.kind === 'cloze' ? 'sm' : ''}`}>{q.prompt}</div>
        {q.tts && ttsAvailable && <button className="sound-btn" onClick={() => speak(q.prompt)} aria-label="Послушать"><Icon name="volume" size={24} /></button>}
        <div className="opts">
          {q.options.map((o) => (
            <button key={o} className={`opt tap ${picked === o ? verdict || '' : picked ? 'dim' : ''}`} onClick={() => answer(o)}>{o}</button>
          ))}
        </div>
        {soft && <p className="err" role="alert">{soft}</p>}
        <button className="btn link" style={{ marginTop: 8 }} onClick={() => answer(null)}>Не знаю</button>
      </div>
    </div>
  )
}

/* ---------- результат + персональный план ---------- */
function ResultScreen({ r, onGo }) {
  const p = r.plan, w = p.world
  const conf = { high: 'Точность высокая', medium: 'Точность средняя — уточним по ходу занятий', low: 'Результат приблизительный — уточним по ходу занятий' }[r.confidence]
  return (
    <div className="ob fade-up">
      <div className="grow center" style={{ paddingTop: 10 }}>
        <Mascot mood="cheer" size={84} float /><p className="muted" style={{ margin: 0 }}>Твой уровень</p>
        <div className="level-badge">{r.level}</div>
        <h2>{w.emoji} {w.title}</h2>
        <p className="muted" style={{ margin: '6px 0 10px', fontSize: 14 }}>{w.desc}</p>
        {p.next_level && (
          <div style={{ margin: '0 6px 6px' }}>
            <div className="progress"><i style={{ width: `${Math.round(p.progress_in_level * 100)}%` }} /></div>
            <div className="muted" style={{ fontSize: 12, marginTop: 5 }}>До {p.next_level}: {Math.round(p.progress_in_level * 100)}% пути{r.answered ? ` · верно ${r.correct} из ${r.answered}` : ''}</div>
          </div>)}
        <div className="card" style={{ textAlign: 'left', marginTop: 14 }}>
          <b>Твой план</b>
          <div className="plan-row"><span className="e"><Icon name="chart" size={19} /></span><span>Цель на день: <b>{p.daily_goal_xp} XP</b> (~{p.minutes} мин)</span></div>
          {p.focus_topics.length > 0 && <div className="plan-row"><span className="e"><Icon name="book" size={19} /></span><span>Начнём с тем: <b>{p.focus_topics.join(', ')}</b></span></div>}
          {p.weak_area && <div className="plan-row"><span className="e"><Icon name="search" size={19} /></span><span>Подтянем: <b>{p.weak_area}</b></span></div>}
          <div className="plan-row"><span className="e"><Icon name="repeat" size={19} /></span><span>Ошибки попадут в «зону повторения» и вернутся вовремя</span></div>
        </div>
        {conf && <p className="muted" style={{ fontSize: 12, marginTop: 10 }}>{conf}</p>}
      </div>
      <div className="foot2"><button className="btn gold shine" onClick={onGo}><Icon name="play" size={18} />Начать первый урок</button></div>
    </div>
  )
}
