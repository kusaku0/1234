import { useState } from 'react'
import { api } from '../api.js'
import { haptic, tg } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'
import { Ring, Segmented, Sheet, Skel, Switch } from '../components/ui.jsx'

const Stat = ({ icon, g, v, t }) => <div className="stat"><span className="si" style={{ background: g }}><Icon name={icon} size={21} /></span><div><b>{v}</b><small>{t}</small></div></div>
const fmtDate = (iso) => { try { return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' }) } catch { return '' } }

export default function Profile({ profile, refresh, theme, sound, toggleSound, showPaywall, onMistakes, onVocab, onRetest, onDeleted }) {
  const [msg, setMsg] = useState('')
  const [vol, setVol] = useState(sfx.volume)
  const [hap, setHap] = useState(haptic.on)
  const [help, setHelp] = useState(false)
  const [del, setDel] = useState(false)
  const [delBusy, setDelBusy] = useState(false)
  const [delErr, setDelErr] = useState('')
  if (!profile) return <Skel h={260} />
  const p = profile
  const refLink = p.bot_username ? `https://t.me/${p.bot_username}?start=ref_${p.tg_id}` : null
  const share = () => {
    const text = 'Engly — английский с нуля в Telegram: слова с картинками, умные повторения и путешествия по миру. Заходи по ссылке — нам обоим +5 заданий в день на неделю'
    try { tg?.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(refLink)}&text=${encodeURIComponent(text)}`) } catch {}
  }
  const buyFreeze = async () => {
    try { await api.post('/api/shop/freeze'); sfx.coin(); haptic.ok(); setMsg('Заморозка куплена: пропуск одного дня не сбросит стрик'); refresh() }
    catch (e) { setMsg(e.detail === 'not_enough_tickets' ? `Нужно ${p.freeze_price} билетов — проходи уроки и локации` : e.detail === 'max_freezes' ? 'Максимум 2 заморозки' : 'Не получилось') }
  }
  const acc = p.answered ? Math.round((p.correct / p.answered) * 100) : 0
  const setPref = (v) => { theme.setPref(v); sfx.toggle(v !== 'light'); api.post('/api/event', { name: 'theme_toggle', payload: { v } }).catch(() => {}) }
  const S = Stat
  const doDelete = async () => {
    setDelBusy(true); setDelErr('')
    try { await api.del('/api/account'); setDel(false); haptic.ok(); onDeleted?.() }
    catch { setDelErr('Не удалось удалить. Проверь соединение и попробуй ещё раз.') }
    setDelBusy(false)
  }
  const left = p.is_premium ? null : p.free_left
  return (
    <div>
      <div className="topbar"><h2>Профиль</h2></div>
      <div className="stagger">
        <div className="card" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <Mascot mood="happy" size={92} float />
          <div style={{ flex: 1 }}>
            <div className="muted" style={{ fontSize: 12.5, fontWeight: 700 }}>Твой уровень</div>
            <div style={{ fontSize: 30, fontWeight: 950 }} className="grad-text">{p.level}</div>
            <div className="muted" style={{ fontSize: 13 }}>Игрок {p.player.level} · {p.xp} XP</div>
          </div>
          <Ring value={p.player.xp_in_level} max={p.player.xp_for_level} size={66} stroke={8}><Icon name="bolt" size={20} /></Ring>
        </div>

        <div className="sect">Мой прогресс</div>
        <div className="stat-grid">
          <S icon="flame" g="linear-gradient(135deg,#ff9f43,#ff5f6d)" v={`${p.streak} дн.`} t={p.freezes > 0 ? `стрик · заморозок ${p.freezes}` : 'стрик'} />
          <S icon="plane" g="var(--g-sky)" v={p.tickets} t="билетов" />
          <S icon="check" g="var(--g-ok)" v={`${acc}%`} t="точность ответов" />
          <S icon="gem" g="var(--g-brand)" v={`${p.srs.mastered}/${p.srs.total}`} t="слов выучено" />
        </div>
        <button className="mrow tap" style={{ marginTop: 10 }} onClick={onVocab}><span className="mi" style={{ '--c': '#ffb347' }}><Icon name="book" size={21} /></span><span className="mt"><b>Мой словарь</b><small>Все слова с картинками</small></span><Icon name="right" size={18} /></button>
        <button className="mrow tap" onClick={onMistakes}><span className="mi" style={{ '--c': '#ff6b7d' }}><Icon name="search" size={21} /></span><span className="mt"><b>Разбор ошибок</b><small>{p.analysis_left || p.is_premium ? 'Слабые места и советы' : 'Доступен завтра или в подписке'}</small></span><Icon name="right" size={18} /></button>

        <div className="sect">Настройки обучения</div>
        <div className="card">
          <Segmented value={theme.pref} onChange={setPref} options={[{ v: 'auto', t: 'Авто', icon: 'auto' }, { v: 'light', t: 'Светлая', icon: 'sun' }, { v: 'dark', t: 'Тёмная', icon: 'moon' }]} />
          <div className="row-set" style={{ marginTop: 6 }}>
            <div className="row"><span className="ic"><Icon name={sound ? 'volume' : 'mute'} size={19} /></span><div><b>Звуки</b><small>Мягкие эффекты при ответах</small></div></div>
            <Switch on={sound} onChange={() => toggleSound()} label="Звуки" />
          </div>
          {sound && <div style={{ padding: '0 0 8px 50px' }}><input type="range" min="0.1" max="1" step="0.05" value={vol} style={{ width: '100%', accentColor: '#7c5cff' }}
            onChange={(e) => { const v = Number(e.target.value); setVol(v); sfx.setVolume(v) }} onPointerUp={() => sfx.ok()} aria-label="Громкость" /></div>}
          <div className="row-set">
            <div className="row"><span className="ic"><Icon name="sparkles" size={19} /></span><div><b>Вибрация</b><small>Отклик на ответы</small></div></div>
            <Switch on={hap} onChange={(v) => { haptic.set(v); setHap(v); haptic.tap() }} label="Вибрация" />
          </div>
        </div>
        <button className="mrow tap" style={{ marginTop: 10 }} onClick={onRetest}><span className="mi" style={{ '--c': '#7c5cff' }}><Icon name="chart" size={21} /></span><span className="mt"><b>Перепройти тест уровня</b><small>Цель и дневная норма сохранятся</small></span><Icon name="right" size={18} /></button>

        <div className="sect">Награды</div>
        <div className="card">
          <b style={{ fontSize: 16, display: 'flex', alignItems: 'center', gap: 8 }}><Icon name="trophy" size={20} />Достижения · {p.achievements.filter((a) => a.earned).length}/{p.achievements.length}</b>
          <div className="ach-grid">{p.achievements.map((a) => <div key={a.code} className={`ach-cell ${a.earned ? '' : 'off'}`} title={a.desc}><span className="e">{a.emoji}</span>{a.title}</div>)}</div>
        </div>

        <div className="sect">Подписка и лимит</div>
        <div className="card">
          <div className="kv"><span>{p.is_premium ? 'Заданий в день' : 'Осталось сегодня'}</span><b>{p.is_premium ? 'без лимита' : `${left} из ${p.free_limit}`}</b></div>
          <p className="muted" style={{ fontSize: 12.5, margin: '2px 0 0' }}>Повторение слов и исправление ошибок лимит не тратят. Начатый урок можно закончить всегда.</p>
          {p.is_premium
            ? <><div className="kv"><span>Premium</span><b>до {fmtDate(p.premium_until)}</b></div><button className="btn ghost" style={{ marginTop: 6 }} onClick={showPaywall}>Продлить — дни добавятся к текущим</button></>
            : <button className="btn gold" style={{ marginTop: 12 }} onClick={showPaywall}>Снять лимит</button>}
        </div>
        <div className="card" style={{ marginTop: 10 }}>
          <div className="row"><span className="ic row-set" style={{ padding: 0 }}><span className="ic"><Icon name="snow" size={20} /></span></span><div style={{ flex: 1 }}><b>Заморозка стрика</b><div className="muted" style={{ fontSize: 13 }}>Пропустил день — серия сохранится · {p.freeze_price} билетов (макс. 2)</div></div></div>
          <button className="btn ghost" style={{ marginTop: 12 }} disabled={p.freezes >= 2} onClick={buyFreeze}>Купить за {p.freeze_price} <Icon name="plane" size={16} /></button>
          {msg && <p className="muted center" style={{ fontSize: 13, margin: '8px 0 0' }}>{msg}</p>}
        </div>

        {refLink && <><div className="sect">Друзья</div><div className="card"><b style={{ display: 'flex', alignItems: 'center', gap: 8 }}><Icon name="gift" size={20} />Приведи друга</b>
          <p className="muted" style={{ margin: '6px 0 12px', fontSize: 13.5 }}>Друг заходит по твоей ссылке — обоим +5 заданий в день на неделю.</p>
          <button className="btn" onClick={share}>Отправить другу</button></div></>}

        <div className="sect">Помощь</div>
        <button className="mrow tap" onClick={() => setHelp(true)}><span className="mi" style={{ '--c': '#43c6ff' }}><Icon name="info" size={21} /></span><span className="mt"><b>Вопросы и ответы</b><small>Лимит, оплата, голос, данные</small></span><Icon name="right" size={18} /></button>
        <button className="mrow tap danger" onClick={() => { setDelErr(''); setDel(true) }}><span className="mi" style={{ '--c': '#ff6b7d' }}><Icon name="x" size={21} /></span><span className="mt"><b>Удалить аккаунт</b><small>Прогресс и данные будут стёрты</small></span><Icon name="right" size={18} /></button>
        <p className="muted center" style={{ fontSize: 12.5, marginTop: 14 }}>Engly · /word — слово дня · /paysupport — поддержка по оплате</p>
      </div>
      <Sheet open={help} onClose={() => setHelp(false)}>
        <h2 style={{ margin: '0 0 8px' }}>Вопросы и ответы</h2>
        {faq(p.free_limit).map(([q, a]) => <details key={q} className="faq"><summary>{q}</summary><p>{a}</p></details>)}
        <button className="btn ghost" style={{ marginTop: 14 }} onClick={() => setHelp(false)}>Закрыть</button>
      </Sheet>
      <Sheet open={del} onClose={() => !delBusy && setDel(false)}>
        <h2 style={{ margin: '0 0 8px' }}>Удалить аккаунт?</h2>
        <p className="muted" style={{ margin: '0 0 6px' }}>Будут навсегда удалены прогресс, слова, достижения, стрик и билеты.{p.is_premium ? ' Оплаченный Premium тоже пропадёт.' : ''} Записи об оплатах Stars остаются у нас для учёта и возвратов.</p>
        <p className="muted" style={{ margin: 0 }}>После удаления приложение предложит начать заново.</p>
        {delErr && <p className="err" role="alert">{delErr}</p>}
        <button className="btn bad" style={{ marginTop: 16 }} disabled={delBusy} onClick={doDelete}>{delBusy ? 'Удаляю…' : 'Удалить навсегда'}</button>
        <button className="btn ghost" style={{ marginTop: 10 }} disabled={delBusy} onClick={() => setDel(false)}>Отмена</button>
      </Sheet>
    </div>
  )
}

const faq = (limit) => [
  ['Как работает дневной лимит?', `Бесплатно — ${limit} новых учебных заданий в день. Лимит проверяется при запуске урока: начатый урок можно закончить всегда. Знакомство со словами, повторение и исправление ошибок лимит не тратят.`],
  ['Что я покупаю за Telegram Stars?', 'Разовый пакет доступа без дневного лимита на 7, 14 или 30 дней. Автоматического продления нет. Вопросы по оплате и возврату — команда /paysupport в боте.'],
  ['Куда попадает запись моего голоса?', 'Никуда: запись остаётся на твоём телефоне, ты только слушаешь себя. Автоматической оценки произношения пока нет.'],
  ['Что такое повторение слов?', 'Слово возвращается через 1, 3, 7… дней — именно тогда, когда его пора освежить. Ошибся — слово придёт раньше.'],
  ['Как потерять стрик — и как этого избежать?', 'Стрик сгорает, если пропустить день. Заморозка (за билеты) сохраняет серию на один пропущенный день.'],
  ['Как удалить мои данные?', 'Профиль → «Удалить аккаунт». Прогресс стирается сразу и безвозвратно. Записи об оплатах Stars хранятся для учёта и возвратов.'],
]
