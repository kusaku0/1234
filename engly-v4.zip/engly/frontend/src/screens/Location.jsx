import { useEffect, useRef, useState } from 'react'
import { api } from '../api.js'
import { haptic, speak, ttsAvailable } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import { Reward } from '../components/ui.jsx'

const QL = { 2: ['q2', 'Отлично'], 1: ['q1', 'Неплохо'], 0: ['q0', 'Можно лучше'] }

/* Диалог в локации: NPC говорит → выбираешь реплику → мгновенный разбор → сюжет ветвится.
   Правильность реплик и XP считает сервер; клиент видит качество только после выбора. */
export default function Location({ data, onExit, onPaywall }) {
  const { location: loc, session_id } = data
  const [node, setNode] = useState(data.node)
  const [hist, setHist] = useState([])          // [{npc, you}]
  const [res, setRes] = useState(null)          // ответ сервера на последний выбор
  const [final, setFinal] = useState(null)
  const [showRu, setShowRu] = useState(['A1', 'A2'].includes(loc.level))
  const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState('')
  const bottom = useRef(null)

  useEffect(() => { if (ttsAvailable && !sfx.muted) { try { speak(node.npc) } catch {} } }, [node.id])
  useEffect(() => { bottom.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }) }, [node.id, res])

  const choose = async (idx) => {
    if (busy || res) return
    setBusy(true)
    try {
      const r = await api.post('/api/location/choose', { session_id, node_id: node.id, idx })
      r.q === 2 ? sfx.ok(2) : r.q === 1 ? sfx.star() : sfx.bad()
      r.q === 0 ? haptic.bad() : haptic.ok()
      setRes(r)
      setMsg('')
    } catch (e) {
      if (e.status === 402) onPaywall()
      else if (e.status === 404 || e.status === 409) setMsg('Диалог уже закрыт. Вернись назад и начни заново.')
      else setMsg(e.status === 0 ? 'Нет соединения — выбери реплику ещё раз.' : 'Не получилось отправить реплику, попробуй ещё раз.')
    }
    setBusy(false)
  }
  const next = () => {
    setHist((h) => [...h, { npc: node, you: res.you, react: res.react }])
    if (res.done) { setFinal(res); sfx.done(); window.scrollTo(0, 0) } else { setNode(res.node) }
    setRes(null)
  }

  if (final) return (
    <Reward mood={final.stars >= 2 ? 'cheer' : 'happy'} stars={final.stars} title={final.first_time ? 'Локация пройдена!' : 'Отлично потренировался!'} xp={final.xp_location}
      chips={[final.tickets_earned > 0 && <><Icon name="plane" size={15} />+{final.tickets_earned}</>, final.vocab_added > 0 && `+${final.vocab_added} фраз в повторение`, <><Icon name="flame" size={15} />{final.streak} дн.</>]}
      achievements={final.achievements} cta="Домой" onClose={onExit}>
      <div className="bubble" style={{ textAlign: 'left' }}>
        <div className="avatar">{loc.npc.emoji}</div>
        <div className="say">{final.ending.en}<small>{final.ending.ru}</small></div>
      </div>
      <div className="card" style={{ textAlign: 'left', marginTop: 14 }}>
        <b style={{ fontSize: 14 }}>Ключевые фразы</b>
        {final.vocab.map((v) => <div className="kv" key={v.en} style={{ fontSize: 14 }}><i>{v.phrase}</i><span className="muted">{v.ru}</span></div>)}
      </div>
    </Reward>
  )

  return (
    <div>
      <div className="topbar">
        <button className="icon-btn tap" onClick={onExit} aria-label="Назад"><Icon name="left" size={22} /></button>
        <span className="pill">{loc.emoji} {loc.city}</span>
        <button className="icon-btn tap" onClick={() => setShowRu(!showRu)} title="Перевод" aria-label="Перевод"><Icon name={showRu ? 'translate' : 'eyeoff'} size={21} /></button>
      </div>
      <div className="scene" style={{ background: `linear-gradient(160deg, ${loc.theme.a}55, ${loc.theme.b}ee)` }}>
        <div className="props">{loc.props.map((p, i) => <span key={i} style={{ left: `${12 + i * 32}%`, top: `${8 + (i % 2) * 40}%`, animationDelay: `${i * 0.8}s` }}>{p}</span>)}</div>
        <h2>{loc.title}</h2>
        <p><span className="lvl-badge">{loc.level}</span>{loc.goal}</p>
      </div>

      {hist.map((h, i) => (
        <div key={i} style={{ opacity: 0.55 }}>
          <div className="bubble"><div className="avatar">{loc.npc.emoji}</div><div className="say">{h.npc.npc}{showRu && <small>{h.npc.ru}</small>}</div></div>
          <div className="reply">{h.you.en}</div>
          {h.react && <div className="bubble" style={{ marginTop: 8 }}><div className="avatar">{loc.npc.emoji}</div><div className="say">{h.react.en}{showRu && <small>{h.react.ru}</small>}</div></div>}
        </div>
      ))}

      <div className="bubble" key={node.id}>
        <div className="avatar">{loc.npc.emoji}</div>
        <div className="say">
          {ttsAvailable && <button className="icon-btn sm sp tap" style={{ background: '#e8e4ff', borderColor: '#d3cbff', color: '#5a32d6' }} onClick={() => speak(node.npc)} aria-label="Озвучить"><Icon name="volume" size={17} /></button>}
          <b style={{ display: 'block', fontSize: 12, color: '#55608a', marginBottom: 2 }}>{loc.npc.name}</b>
          {node.npc}{showRu && <small>{node.ru}</small>}
        </div>
      </div>

      {msg && <p className="err" role="alert">{msg}</p>}
      {!res && (
        <div className="choices fade-up">
          {node.choices.map((c, i) => (
            <button key={i} className="choice tap" disabled={busy} onClick={() => choose(i)} style={{ animationDelay: `${i * .06}s` }}>{c.en}{showRu && <small>{c.ru}</small>}</button>
          ))}
        </div>
      )}

      {res && (
        <div className="fade-up">
          <div className="reply">{res.you.en}</div>
          <div className="card" style={{ marginTop: 12, borderColor: res.q === 2 ? 'var(--mint)' : res.q === 1 ? 'var(--amber)' : 'var(--coral)' }}>
            <span className={`qchip ${QL[res.q][0]}`}>{QL[res.q][1]}</span>
            {res.xp_earned > 0 && <span className="qchip q1" style={{ marginLeft: 6 }}>+{res.xp_earned} XP</span>}
            <p style={{ margin: '8px 0 0', fontSize: 14.5, lineHeight: 1.4 }}>{res.fb}</p>
            {res.react && <p className="muted" style={{ margin: '8px 0 0', fontSize: 13.5 }}>{loc.npc.name}: «{res.react.en}»</p>}
            <button className={`btn ${res.q === 0 ? 'bad' : 'ok'}`} style={{ marginTop: 12 }} onClick={next}>{res.done ? 'Завершить' : 'Дальше'}</button>
          </div>
        </div>
      )}
      <div ref={bottom} style={{ height: 8 }} />
    </div>
  )
}
