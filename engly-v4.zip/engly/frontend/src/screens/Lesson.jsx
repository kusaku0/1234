import { useCallback, useEffect, useRef, useState } from 'react'
import { api } from '../api.js'
import { haptic, speak, ttsAvailable } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'
import { ErrorBox, Highlight, Reward, Skel } from '../components/ui.jsx'

const GOOD = ['Верно!', 'Отлично!', 'В точку!', 'Так держать!', 'Блестяще!', 'Супер!']
const BAD = ['Почти!', 'Не страшно', 'Запомним!', 'Бывает']
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const KEYS = ['A', 'B', 'C', 'D']

/* Урок. Сервер выдаёт задания и сам проверяет ответы (клиент не знает правильных до ответа).
   Новое слово: карточка-знакомство → лёгкое задание → аудирование; потом пары, вспоминание, буквы, фраза. */
export default function Lesson({ mode = 'path', level, topic, kind, resume, onExit, onPaywall, onNext }) {
  const [lesson, setLesson] = useState(null)
  const [tasks, setTasks] = useState([])
  const [i, setI] = useState(0)
  const [fb, setFb] = useState(null)
  const [picked, setPicked] = useState(null)
  const [built, setBuilt] = useState([])
  const [letters, setLetters] = useState([])
  const [combo, setCombo] = useState(0)
  const [err, setErr] = useState(null)
  const [limit, setLimit] = useState(false)
  const [done, setDone] = useState(null)
  const [busy, setBusy] = useState(false)
  const [toast, setToast] = useState('')
  const t0 = useRef(Date.now())
  const inflight = useRef(false)        // защита от двойного тапа: state обновляется позже, чем приходит второй клик
  const say = (m) => { setToast(m); setTimeout(() => setToast(''), 2800) }

  const start = useCallback(() => {
    setErr(null); setLimit(false); setDone(null); setLesson(null); setI(0); setFb(null); setPicked(null); setBuilt([]); setLetters([]); setCombo(0)
    const req = resume ? api.get('/api/lesson/resume').then((r) => r.lesson) : api.post('/api/lesson/start', { level, topic, mode, kind })
    req.then((d) => { if (!d) return onExit(); setLesson(d); setTasks(d.tasks); setI(d.next || 0) })
      .catch((e) => { if (e.status === 402) setLimit(true); else setErr(e.status === 409 ? e.detail : e.status === 403 ? 'locked' : 'net') })
  }, [level, topic, mode, kind, resume]) // eslint-disable-line
  useEffect(start, [start])

  const t = tasks[i]
  useEffect(() => {
    t0.current = Date.now()
    if (!t || sfx.muted || !ttsAvailable) return
    if (t.type === 'intro') setTimeout(() => speak(t.item, 0.85), 450)
    else if (t.type === 'listen') setTimeout(() => speak(t.tts, 0.85), 350)
  }, [i, lesson]) // eslint-disable-line

  if (limit) return (
    <div className="card center fade-up" style={{ padding: 28 }}><Mascot mood="sleep" size={110} float /><h3 style={{ marginTop: 8 }}>Дневной лимит</h3>
      <p className="muted">Бесплатные задания на сегодня закончились. Знакомство со словами — всегда бесплатно, а завтра — новая порция!</p>
      <button className="btn gold" onClick={onPaywall}>Снять лимит</button><button className="btn link" onClick={onExit}>Выйти</button></div>)
  if (err === 'no_due' || err === 'need_words') return (
    <div className="card center fade-up" style={{ padding: 28 }}><Mascot mood={err === 'no_due' ? 'cheer' : 'think'} size={110} float />
      <h3 style={{ marginTop: 8 }}>{err === 'no_due' ? 'Всё повторено!' : 'Пока мало слов'}</h3>
      <p className="muted">{err === 'no_due' ? 'Слова вернутся, когда придёт время.' : 'Для этой тренировки нужно хотя бы 3 знакомых слова — пройди пару уроков на «Пути».'}</p><button className="btn" onClick={onExit}>Понятно</button></div>)
  if (err === 'gone') return <ErrorBox onRetry={onExit} text="Этот урок уже закрыт. Вернись на карту и начни заново." />
  if (err) return <ErrorBox onRetry={start} />
  if (!lesson) return <Skel h={360} />

  const total = lesson.tasks.length
  const send = async (answer) => {
    if (fb || busy || inflight.current) return null
    inflight.current = true
    setBusy(true)
    try {
      const r = await api.post('/api/lesson/answer', { session_id: lesson.session_id, idx: t.idx, answer, ms: Date.now() - t0.current })
      if (t.type !== 'intro' && t.type !== 'speak') {
        if (r.correct) { sfx.ok(combo); haptic.ok(); setCombo((c) => c + 1) } else { sfx.bad(); haptic.bad(); setCombo(0) }
      }
      if (r.tickets_earned) setTimeout(sfx.coin, 450)
      if (r.retry) setTasks((x) => [...x, r.retry])
      setBusy(false); inflight.current = false
      return r
    } catch (e) {
      setBusy(false); inflight.current = false
      if (e.status === 402) setLimit(true)
      else if (e.status === 409 && e.detail === 'already_answered') await resync()      // сервер уже принял ответ, а до нас он не дошёл
      else if (e.status === 404) setErr('gone')
      else { setPicked(null); say(e.status === 0 ? 'Нет соединения — ответ не потерян, попробуй ещё раз' : 'Не получилось отправить ответ, попробуй ещё раз') }
      return null
    }
  }
  const resync = async () => {
    try {
      const st = await api.get(`/api/lesson/state?session_id=${lesson.session_id}`)
      setTasks(st.tasks); setFb(null); setPicked(null); setBuilt([]); setLetters([])
      if (st.finished || st.next >= st.tasks.length) await finish(); else setI(st.next)
    } catch { say('Нет соединения — попробуй ещё раз') }
  }
  const finish = async () => {
    try { const r = await api.post('/api/lesson/finish', { session_id: lesson.session_id }); setDone(r); r.cefr_up ? sfx.levelup() : sfx.done(); haptic.ok(); window.scrollTo(0, 0) }
    catch (e) { if (e.status === 400) resync(); else say('Нет соединения — попробуй ещё раз') }
  }
  const answer = async (a) => { const r = await send(a); if (r) setFb({ ...r, mood: r.correct ? 'cheer' : 'sad', say: r.correct ? pick(GOOD) : pick(BAD) }) }
  const choose = (o) => { if (!fb && !busy) { setPicked(o); sfx.select(); answer(o) } }

  const next = async () => {
    sfx.tap()
    if (i + 1 >= tasks.length) return finish()
    setI(i + 1); setFb(null); setPicked(null); setBuilt([]); setLetters([])
  }
  const introGo = async () => { sfx.pop(); haptic.tap(); const r = await send('seen'); if (r) { setFb(null); await next() } }

  if (done) return <Done done={done} mode={mode} onExit={onExit} onNext={onNext} onAgain={start} />

  const optCls = (o) => `opt tap ${picked === o ? (fb ? (fb.correct ? 'ok' : 'bad') : '') : fb && !fb.correct && o === fb.correct_value ? 'ok' : fb ? 'dim' : ''}`
  const isEmoji = t.by === 'emoji'
  const opts = () => (
    <div className={`opts ${isEmoji ? `emoji ${t.options.length === 2 ? 'two' : ''}` : ''}`}>
      {t.options.map((o, k) => <button key={o} className={optCls(o)} onClick={() => choose(o)}>{!isEmoji && <span className="k">{KEYS[k]}</span>}{o}</button>)}
    </div>)

  return (
    <div>
      {toast && <div className="toast">{toast}</div>}
      <div className="lhead">
        <button className="icon-btn sm tap" onClick={onExit} aria-label="Выйти"><Icon name="x" size={20} /></button>
        <div className="progress"><i style={{ width: `${(i / tasks.length) * 100}%` }} /></div>
        {combo >= 3 ? <span className="combo"><Icon name="flame" size={18} />{combo}</span> : <span className="pill" style={{ padding: '6px 11px' }}>{Math.min(i + 1, total)}/{tasks.length}</span>}
      </div>

      <div key={t.idx} className="fade-up">
        {t.review && <span className="badge-review"><Icon name="repeat" size={13} />повторение</span>}

        {t.type === 'intro' && (
          <>
            <div className="intro-card">
              <span className="badge">Новое слово</span>
              <div className="qemoji">{t.emoji || '✨'}</div>
              <div className="en">{t.item}</div>
              <div className="ru">{t.ru}</div>
              {ttsAvailable && <button className="sound-btn" onClick={() => { speak(t.item, 0.8); sfx.tap() }} aria-label="Озвучить"><Icon name="volume" size={26} /></button>}
              <div className="quote"><Highlight text={t.phrase} word={t.item} /><small>{t.phrase_ru}</small></div>
            </div>
            <div className="tip"><Icon name="sparkles" size={18} />Повтори слово вслух — так оно запомнится в разы лучше</div>
          </>)}

        {t.type === 'pick_emoji' && (
          <div className="qcard"><p className="qsub">Выбери картинку</p><div className="qword">{t.item}</div>
            {ttsAvailable && <button className="sound-btn" onClick={() => speak(t.item, 0.85)} aria-label="Озвучить"><Icon name="volume" size={24} /></button>}{opts()}</div>)}

        {t.type === 'en_ru' && (
          <div className="qcard"><p className="qsub">Что это значит?</p>{t.emoji && <div className="qemoji" style={{ fontSize: 64 }}>{t.emoji}</div>}<div className="qword">{t.item}</div>
            {ttsAvailable && <button className="sound-btn" onClick={() => speak(t.item, 0.85)} aria-label="Озвучить"><Icon name="volume" size={24} /></button>}{opts()}</div>)}

        {t.type === 'ru_en' && (
          <div className="qcard"><p className="qsub">Как это по-английски?</p>{t.emoji && <div className="qemoji" style={{ fontSize: 64 }}>{t.emoji}</div>}<div className="qword">{t.ru}</div>{opts()}</div>)}

        {t.type === 'listen' && (
          <div className="qcard"><p className="qsub">Послушай и выбери {isEmoji ? 'картинку' : 'перевод'}</p>
            {ttsAvailable ? <button className="sound-btn big" onClick={() => speak(t.tts, 0.85)} aria-label="Послушать"><Icon name="volume" size={40} /></button>
              : <div className="qword sm">{t.tts}</div>}{opts()}</div>)}

        {t.type === 'type_word' && <TypeWord t={t} letters={letters} setLetters={setLetters} fb={fb} />}

        {t.type === 'scramble' && (
          <div className="qcard"><p className="qsub">Собери фразу по-английски</p><div className="qword sm">{t.phrase_ru}</div>
            <div className="scramble-line">{built.map((wi, k) => <span key={k} className="word tap" onClick={() => !fb && setBuilt(built.filter((_, j) => j !== k))}>{t.words[wi]}</span>)}</div>
            <div className="scramble-pool">{t.words.map((w, k) => <span key={k} className={`word tap ${built.includes(k) ? 'used' : ''}`} onClick={() => { if (!fb) { setBuilt([...built, k]); sfx.select() } }}>{w}</span>)}</div></div>)}

        {t.type === 'match' && <Match t={t} lesson={lesson} fb={fb} onDone={() => answer('done')} />}
        {t.type === 'speak' && <SpeakTask t={t} fb={fb} onDone={() => answer('done')} onSkip={() => answer('skip')} onNext={next} />}
      </div>

      {t.type === 'intro' && <div className="foot"><div><button className="btn" disabled={busy} onClick={introGo}>Запомнил — дальше</button></div></div>}
      {(t.type === 'scramble' || t.type === 'type_word') && !fb && (
        <div className="foot"><div><button className="btn" disabled={busy || (t.type === 'scramble' ? !built.length : letters.length < t.length)}
          onClick={() => answer(t.type === 'scramble' ? built.map((k) => t.words[k]).join(' ') : letters.map((k) => t.letters[k]).join(''))}>Проверить</button></div></div>)}

      {fb && t.type !== 'speak' && (
        <div className={`foot fbbar ${fb.correct ? 'good' : 'bad'}`}><div style={{ position: 'relative' }}>
          {fb.xp_earned > 0 && <span className="xpfly"><Icon name="bolt" size={18} />+{fb.xp_earned}</span>}
          <div className="t"><Mascot mood={fb.mood} size={44} />{fb.say}</div>
          {!fb.correct && fb.correct_answer && <div className="ans">Правильно: <b>{fb.correct_answer}</b></div>}
          {t.type === 'match' && fb.mistakes > 0 && <div className="ans">Ошибок в парах: {fb.mistakes}</div>}
          {fb.phrase && <div className="ex">{ttsAvailable && <button className="icon-btn sm" onClick={() => speak(fb.phrase)} aria-label="Озвучить пример"><Icon name="volume" size={16} /></button>}<span><i>{fb.phrase}</i> — {fb.phrase_ru}</span></div>}
          <button className={`btn ${fb.correct ? 'ok' : 'bad'}`} onClick={next}>{i + 1 >= tasks.length ? 'Завершить' : 'Дальше'}</button>
        </div></div>)}
    </div>
  )
}

/* ---- собери слово из букв ---- */
function TypeWord({ t, letters, setLetters, fb }) {
  const state = fb ? (fb.correct ? 'ok' : 'bad') : ''
  return (
    <div className="qcard"><p className="qsub">Собери слово по-английски</p>
      {t.emoji && <div className="qemoji" style={{ fontSize: 64 }}>{t.emoji}</div>}<div className="qword sm">{t.ru}</div>
      {ttsAvailable && <button className="sound-btn" onClick={() => speak(t.tts, 0.85)} aria-label="Подсказка: озвучить"><Icon name="volume" size={24} /></button>}
      <div className="slots">{Array.from({ length: t.length }, (_, k) => (
        <div key={k} className={`slot ${letters[k] != null ? 'filled' : ''} ${state}`} onClick={() => !fb && letters[k] != null && setLetters(letters.filter((_, j) => j !== k))}>{letters[k] != null ? t.letters[letters[k]] : ''}</div>))}</div>
      <div className="tiles">{t.letters.map((l, k) => (
        <button key={k} className={`tile tap ${letters.includes(k) ? 'used' : ''}`} onClick={() => { if (!fb && letters.length < t.length) { setLetters([...letters, k]); sfx.select(); haptic.soft() } }}>{l}</button>))}</div>
      {!fb && letters.length > 0 && <button className="btn link" onClick={() => setLetters(letters.slice(0, -1))}>⌫ Стереть</button>}
    </div>)
}

/* ---- найди пару: сервер проверяет каждую пару ---- */
function Match({ t, lesson, fb, onDone }) {
  const [a, setA] = useState(null)
  const [okEn, setOkEn] = useState([])
  const [okRu, setOkRu] = useState([])
  const [bad, setBad] = useState(null)
  const [lockd, setLockd] = useState(false)
  const tap = async (side, v) => {
    if (fb || lockd) return
    sfx.select()
    if (side === 'l') { setA(v); return }
    if (!a) return
    setLockd(true)
    try {
      const r = await api.post('/api/lesson/pair', { session_id: lesson.session_id, idx: t.idx, en: a, ru: v })
      if (r.ok) {
        sfx.pair(); haptic.soft()
        setOkEn((x) => [...x, a]); setOkRu((x) => [...x, v]); setA(null)
        if (r.done) setTimeout(onDone, 500)
      } else { sfx.bad(); haptic.bad(); setBad([a, v]); setTimeout(() => { setBad(null); setA(null) }, 520) }
    } catch {}
    setLockd(false)
  }
  return (
    <div className="qcard"><p className="qsub">Найди пары</p>
      <div className="mgrid">
        <div className="col">{t.left.map((w) => <button key={w} className={`mcell tap ${okEn.includes(w) ? 'done' : ''} ${a === w ? 'sel' : ''} ${bad?.[0] === w ? 'bad' : ''}`} onClick={() => tap('l', w)}>{w}</button>)}</div>
        <div className="col">{t.right.map((w) => <button key={w} className={`mcell tap ${okRu.includes(w) ? 'done' : ''} ${bad?.[1] === w ? 'bad' : ''}`} onClick={() => tap('r', w)}>{w}</button>)}</div>
      </div>
    </div>)
}

/* ---- говорение: запись и самопроверка (необязательно) ---- */
function SpeakTask({ t, fb, onDone, onSkip, onNext }) {
  const [rec, setRec] = useState(null)
  const [recording, setRecording] = useState(false)
  const [micErr, setMicErr] = useState(false)
  const mr = useRef(null), chunks = useRef([])
  const startRec = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      chunks.current = []
      const m = new MediaRecorder(stream)
      m.ondataavailable = (e) => chunks.current.push(e.data)
      m.onstop = () => { setRec({ url: URL.createObjectURL(new Blob(chunks.current, { type: 'audio/webm' })) }); stream.getTracks().forEach((x) => x.stop()) }
      mr.current = m; m.start(); setRecording(true); sfx.pop()
      api.post('/api/event', { name: 'speak_used' }).catch(() => {})
    } catch { setMicErr(true) }     // доступ к микрофону запрещён — честно говорим об этом, «получилось» не показываем
  }
  const stop = () => { try { mr.current?.stop() } catch {} setRecording(false); sfx.tap() }
  return (
    <div className="qcard">
      <p className="qsub">Потренируй произношение (по желанию)</p>
      {t.emoji && <div className="qemoji" style={{ fontSize: 64 }}>{t.emoji}</div>}
      <div className="qword sm">{t.phrase}</div><p className="qphrase">{t.phrase_ru}</p>
      {ttsAvailable && <button className="btn ghost small" style={{ margin: '12px auto 0' }} onClick={() => speak(t.phrase)}><Icon name="volume" size={18} />Образец</button>}
      {micErr && !fb && <div className="tip" style={{ marginTop: 16 }}><Icon name="mic" size={18} />Нет доступа к микрофону. Разреши его в настройках Telegram или просто скажи фразу вслух и пропусти шаг.</div>}
      {!rec && !fb && <div style={{ marginTop: 18 }}>
        {!micErr && <button className={`btn ${recording ? 'bad' : ''}`} onClick={recording ? stop : startRec}><Icon name={recording ? 'x' : 'mic'} size={20} />{recording ? 'Стоп' : 'Записать'}</button>}
        {!micErr && !recording && <p className="muted" style={{ fontSize: 12, margin: '8px 0 0' }}>Запись остаётся на твоём телефоне и никуда не отправляется</p>}
        <button className="btn link" onClick={() => { api.post('/api/event', { name: 'speak_skipped' }).catch(() => {}); onSkip() }}>Пропустить</button></div>}
      {rec && !fb && <div style={{ marginTop: 14 }}>
        {rec.url && <audio controls src={rec.url} style={{ width: '100%' }} />}
        <p className="muted" style={{ fontSize: 13.5 }}>Послушай себя и сравни с образцом. Автоматической оценки пока нет — судишь ты сам.</p>
        <button className="btn ok" onClick={onDone}><Icon name="check" size={20} />Да, получилось!</button></div>}
      {fb && <div className="card fade-up" style={{ marginTop: 16 }}>
        <Mascot mood={fb.xp_earned ? 'cheer' : 'happy'} size={72} /><div style={{ fontWeight: 850, margin: '4px 0 10px' }}>{fb.xp_earned ? `Красавчик! +${fb.xp_earned} XP` : 'Ничего, в следующий раз!'}</div>
        <button className="btn ok" onClick={onNext}>Завершить</button></div>}
    </div>)
}

/* ---- итог урока ---- */
function Done({ done, mode, onExit, onNext, onAgain }) {
  const p = done.path
  const failed = !!(p && !p.passed)
  const title = failed ? 'Урок пока не засчитан' : done.cefr_up ? `Уровень ${done.cefr_up.to}!` : p?.unit_done ? 'Тема пройдена!' : done.perfect ? 'Без единой ошибки!' : mode === 'review' ? 'Повторение завершено' : mode === 'drill' ? 'Тренировка пройдена' : 'Урок пройден!'
  const sub = failed ? 'Точность ниже 60%, поэтому прогресс по теме не изменился. Повтори урок: слова уже знакомы, второй раз выйдет лучше. XP за ответы начислены.' : p ? `Урок ${p.lesson} из ${p.of}` : null
  return (
    <Reward mood={failed ? 'think' : 'cheer'} confetti={!failed} title={title} sub={sub} xp={done.xp_lesson}
      chips={[<><Icon name="check" size={15} />{Math.round(done.accuracy * 100)}% точность</>, done.tickets_earned > 0 && <><Icon name="plane" size={15} />+{done.tickets_earned}</>,
        <><Icon name="flame" size={15} />{done.streak} дн.</>, done.level_up && `Уровень игрока ${done.player.level}!`, done.daily.today_xp >= done.daily.goal && 'Цель дня выполнена']}
      achievements={done.achievements} cta={failed ? 'Повторить урок' : p && p.passed && onNext ? 'Дальше по пути' : 'Готово'} onClose={failed ? onAgain : p && p.passed && onNext ? onNext : onExit}>
      {done.cefr_up && <div className="banner-up"><b>Новый уровень: {done.cefr_up.to} · {done.cefr_up.world.title}</b>Ты прошёл все темы {done.cefr_up.from}. Открылись новые темы и локации!</div>}
      {p && (
        <div style={{ margin: '12px 4px 0' }}>
          <div className="progress thin gold"><i style={{ width: `${(p.passed ? p.lesson : p.lesson - 1) / p.of * 100}%` }} /></div>
          <div className="muted" style={{ fontSize: 12.5, marginTop: 6 }}>Тема «{p.topic}»: {p.passed ? p.lesson : p.lesson - 1} из {p.of}</div>
        </div>)}
      {done.wrong > 0 && <p className="muted" style={{ fontSize: 13.5 }}>Слова с ошибками вернутся в нужный момент — так работает интервальное повторение</p>}
      {(p && (!p.passed || (mode === 'path' && onNext))) && <button className="btn ghost" style={{ marginTop: 10 }} onClick={onExit}>На карту пути</button>}
      {mode === 'practice' && <button className="btn ghost" style={{ marginTop: 10 }} onClick={onAgain}>Ещё раз</button>}
    </Reward>
  )
}
