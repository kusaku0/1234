import { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { haptic } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'
import TopBar from '../components/TopBar.jsx'
import Week from '../components/Week.jsx'
import { ErrorBox, Ring, Sheet, Skel } from '../components/ui.jsx'

const STEP = 110, OFF = [0, 17, 0, -17]    // шаг по вертикали и «змейка» в % ширины

/* Путь обучения: темы → уроки по 3 новых слова. Новичок идёт строго по порядку, по одному слову за раз. */
export default function Path({ profile, theme, sound, toggleSound, onStart, onReview, refreshKey }) {
  const [data, setData] = useState(null)
  const [err, setErr] = useState(false)
  const [lvl, setLvl] = useState(null)
  const [sheet, setSheet] = useState(null)
  const [toast, setToast] = useState('')
  const [resume, setResume] = useState(null)
  useEffect(() => { api.get('/api/lesson/resume').then((r) => setResume(r.lesson)).catch(() => {}) }, [refreshKey])
  const load = () => { setErr(false); api.get('/api/path').then((d) => { setData(d); setLvl((l) => l || d.level) }).catch(() => setErr(true)) }
  useEffect(load, [refreshKey]) // eslint-disable-line
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(''), 2200); return () => clearTimeout(t) } }, [toast])

  const cur = data?.current
  const curUnit = useMemo(() => cur && data.levels.find((l) => l.id === cur.level)?.units.find((u) => u.topic === cur.topic), [data, cur])
  const d = profile?.daily || { today_xp: 0, goal: 30 }
  const due = data?.due ?? 0
  if (err) return <ErrorBox onRetry={load} />
  if (!data) return <><TopBar profile={profile} theme={theme} sound={sound} toggleSound={toggleSound} /><Skel h={200} /><div style={{ height: 12 }} /><Skel h={300} /></>
  const level = data.levels.find((l) => l.id === lvl) || data.levels[0]

  /* Что открывает узел: пройденный — повтор темы, текущий — следующий урок, будущие и закрытые — подсказка, что нужно сделать */
  const openUnit = (u, lv, st, k) => {
    haptic.tap(); sfx.pop()
    if (st === 'locked') {
      setToast(lv.state === 'locked' ? `Откроется после уровня ${data.level}` : u.status === 'locked' ? 'Сначала пройди предыдущую тему' : 'Сначала пройди предыдущие уроки темы')
      return
    }
    setSheet({ u, lv, k, st })
  }

  return (
    <div>
      <TopBar profile={profile} theme={theme} sound={sound} toggleSound={toggleSound} />
      <div className="stagger">
        {curUnit && (
          <div className="hero">
            <div className="mascot-wrap"><Mascot mood="happy" size={108} float /></div>
            <div className="kick">Продолжить · {cur.level}</div>
            <h2>{curUnit.emoji} {curUnit.topic}</h2>
            <p>{resume ? `Начатый урок: ${resume.topic}` : `Урок ${Math.min(curUnit.done + 1, curUnit.lessons)} из ${curUnit.lessons} · по 3 новых слова`}</p>
            <div className="wchips">{curUnit.next_words.map((w) => <span className="wchip" key={w.en}>{w.emoji || '✨'} {w.en}</span>)}</div>
            <button className="btn gold shine" onClick={() => { sfx.pop(); onStart(resume ? { resume: true } : { mode: 'path', level: cur.level, topic: cur.topic }) }}><Icon name="play" size={18} />{resume ? `Продолжить урок · шаг ${Math.min(resume.next + 1, resume.tasks.length)} из ${resume.tasks.length}` : 'Начать урок'}</button>
          </div>)}

        <div className="card" style={{ marginTop: 12 }}>
          <div className="row">
            <Ring value={d.today_xp} max={d.goal} size={78} stroke={9}>{d.today_xp}<small>из {d.goal}</small></Ring>
            <div style={{ flex: 1 }}>
              <b style={{ fontSize: 16.5 }}>{d.today_xp >= d.goal ? 'Цель дня выполнена!' : 'Цель на сегодня'}</b>
              <div className="muted" style={{ fontSize: 13, margin: '3px 0 0' }}>{profile?.player ? `Уровень игрока ${profile.player.level} · ${profile.player.xp_in_level}/${profile.player.xp_for_level} XP` : ''}</div>
            </div>
          </div>
          <Week streak={profile?.streak ?? 0} doneToday={!!profile?.studied_today} />
        </div>

        {due > 0 && (
          <button className="card glow tap" style={{ width: '100%', textAlign: 'left', marginTop: 12, display: 'flex', gap: 12, alignItems: 'center', cursor: 'pointer', color: 'var(--text)' }} onClick={() => { sfx.pop(); onReview() }}>
            <span className="loc-em" style={{ background: 'var(--g-sky)', width: 46, height: 46 }}><Icon name="repeat" size={22} /></span>
            <span style={{ flex: 1 }}><b>Повторение · {due} {due === 1 ? 'слово' : due < 5 ? 'слова' : 'слов'}</b><br /><span className="muted" style={{ fontSize: 13 }}>Самое время — пока не забыл</span></span>
            <Icon name="right" size={20} />
          </button>)}
      </div>

      <div className="chip-row" style={{ marginTop: 18 }}>
        {data.levels.map((l) => (
          <button key={l.id} className={`fchip tap ${lvl === l.id ? 'on' : ''} ${l.state === 'locked' ? 'lock' : ''}`} onClick={() => { setLvl(l.id); sfx.tap() }}>
            {l.state === 'locked' && <Icon name="lock" size={14} />}{l.id} <span style={{ opacity: .8, fontWeight: 650 }}>{l.title}</span></button>))}
      </div>

      <div className={`lvl-banner ${level.state === 'locked' ? 'locked' : ''}`}>
        <span className="big">{level.id}</span>
        <div style={{ flex: 1 }}><b>{level.emoji} {level.title}</b><small>{level.desc}</small></div>
        <span style={{ fontWeight: 850 }}>{level.units_done}/{level.units.length}</span>
      </div>

      {level.units.map((u) => <Unit key={u.topic} u={u} lv={level} onOpen={openUnit} />)}
      <div style={{ height: 20 }} />

      <Sheet open={!!sheet} onClose={() => setSheet(null)}>
        {sheet && (
          <div className="center">
            <div style={{ fontSize: 64 }}>{sheet.u.emoji}</div>
            <h2 style={{ margin: '4px 0 2px' }}>{sheet.u.topic}</h2>
            <p className="muted" style={{ margin: 0 }}>{sheet.lv.id} · {sheet.u.words} слов · {sheet.u.done}/{sheet.u.lessons} уроков</p>
            {sheet.u.goal_pick && <p style={{ margin: '8px 0 0', fontSize: 13, fontWeight: 700, color: 'var(--p1)' }}>Тема выбрана под твою цель</p>}
            <div className="wchips" style={{ justifyContent: 'center', maxWidth: '100%', margin: '14px 0' }}>
              {sheet.u.all_words.map((w) => <span key={w.en} className="chip" style={{ animation: 'none', padding: '6px 12px', fontSize: 13.5 }}>{w.emoji || '✨'} {w.en}</span>)}
            </div>
            {sheet.st === 'done'
              ? <><button className="btn" onClick={() => { setSheet(null); onStart({ mode: 'practice', level: sheet.lv.id, topic: sheet.u.topic }) }}><Icon name="repeat" size={19} />{sheet.k < sheet.u.done && sheet.u.status !== 'done' ? `Повторить: урок ${sheet.k + 1}` : 'Повторить тему'}</button></>
              : <button className="btn gold shine" onClick={() => { setSheet(null); onStart({ mode: 'path', level: sheet.lv.id, topic: sheet.u.topic }) }}><Icon name="play" size={18} />Урок {sheet.u.done + 1}</button>}
            <button className="btn link" onClick={() => setSheet(null)}>Закрыть</button>
          </div>)}
      </Sheet>
      {toast && <div className="toast">{toast}</div>}
    </div>
  )
}

function Unit({ u, lv, onOpen }) {
  const n = u.lessons, H = n * STEP + 28
  const pts = Array.from({ length: n }, (_, k) => [50 + OFF[k % 4] * (lv.units.indexOf(u) % 2 ? -1 : 1), 46 + k * STEP])
  const curve = (arr) => arr.reduce((s, [x, y], k) => k === 0 ? `M${x} ${y}` : `${s} C${arr[k - 1][0]} ${(arr[k - 1][1] + y) / 2} ${x} ${(arr[k - 1][1] + y) / 2} ${x} ${y}`, '')
  const doneN = u.status === 'done' ? n : u.done
  return (
    <div>
      <div className={`unit-head ${u.status === 'done' ? 'done' : u.status === 'locked' ? 'locked' : ''}`}>
        <span className="ub">{u.status === 'locked' ? '🔒' : u.emoji}</span>
        <div style={{ flex: 1 }}><b>{u.topic}</b>{u.goal_pick && u.status !== 'done' && <span className="goal-chip">для твоей цели</span>}<small>{u.words} слов · {doneN}/{n} уроков</small></div>
        {u.status === 'done' && <Icon name="check" size={22} stroke={3} style={{ color: '#12c98a' }} />}
      </div>
      <div className="track" style={{ height: H }}>
        <svg viewBox={`0 0 100 ${H}`} preserveAspectRatio="none">
          <defs><linearGradient id="tg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#ffd35a" /><stop offset="1" stopColor="#ff9f43" /></linearGradient></defs>
          {n > 1 && <path className="base" d={curve(pts)} />}
          {doneN > 1 && <path className="prog" d={curve(pts.slice(0, doneN))} />}
        </svg>
        {pts.map(([x, y], k) => {
          const st = u.status === 'locked' ? 'locked' : k < doneN ? 'done' : k === doneN ? (u.status === 'current' ? 'current' : 'open') : 'locked'
          return (
            <button key={k} className={`node ${st}`} style={{ left: `${x}%`, top: y - 34 }} onClick={() => onOpen(u, lv, st, k)} aria-label={`${u.topic}, урок ${k + 1}`}>
              {st === 'current' && <span className="start">СТАРТ</span>}
              <span className="disc"><Icon name={st === 'done' ? 'check' : st === 'locked' ? 'lock' : 'star'} size={st === 'locked' ? 24 : 30} stroke={st === 'done' ? 3.4 : 2.2} fill={st === 'current' || st === 'open' ? 'currentColor' : 'none'} /></span>
            </button>)
        })}
      </div>
    </div>
  )
}
