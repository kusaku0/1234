import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { speak, ttsAvailable } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import TopBar from '../components/TopBar.jsx'

const DRILLS = [
  { kind: 'listen', t: 'Аудирование', s: 'Слушай и выбирай', i: 'headphones', c: '#43c6ff' },
  { kind: 'type_word', t: 'Правописание', s: 'Собери слово из букв', i: 'pencil', c: '#ff9f43' },
  { kind: 'pick_emoji', t: 'Угадай картинку', s: 'Слово → картинка', i: 'image', c: '#2fe0a3' },
  { kind: 'match', t: 'Найди пару', s: 'Слово ↔ перевод', i: 'blocks', c: '#7c5cff' },
  { kind: 'ru_en', t: 'Переведи', s: 'С русского на английский', i: 'translate', c: '#a35cff' },
  { kind: 'scramble', t: 'Собери фразу', s: 'Слова → предложение', i: 'sliders', c: '#ff6b7d' },
]
const plural = (n, a, b, c) => (n % 10 === 1 && n % 100 !== 11 ? a : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? b : c)

/* Практика: два понятных блока — «Повторение» (главное) и «Тренировки». Доступность тренировок считает сервер,
   поэтому кнопка активна ровно тогда, когда тренировку можно собрать. */
export default function Practice({ profile, theme, sound, toggleSound, onDrill, onReview, onVocab, onFlash }) {
  const [wod, setWod] = useState(null)
  const [info, setInfo] = useState(null)
  useEffect(() => { api.get('/api/wordofday').then(setWod).catch(() => {}); api.get('/api/practice').then(setInfo).catch(() => {}) }, [])
  const c = info?.counts || { due: profile?.srs?.due ?? 0, new: 0, learning: 0, mastered: 0 }
  const need = info?.need ?? 3
  const total = c.new + c.learning + c.mastered
  return (
    <div>
      <TopBar profile={profile} theme={theme} sound={sound} toggleSound={toggleSound} sub="тренируй навыки" />
      <div className="stagger">
        <div className="sect">Повторение</div>
        <button className={`mrow tap main ${c.due ? '' : 'off'}`} disabled={!c.due} onClick={() => { sfx.pop(); onReview() }}>
          <span className="mi" style={{ '--c': '#7c5cff' }}><Icon name="repeat" size={22} /></span>
          <span className="mt"><b>{c.due ? `Пора повторить: ${c.due} ${plural(c.due, 'слово', 'слова', 'слов')}` : 'Пока всё свежо'}</b><small>{c.due ? 'Бесплатно · займёт пару минут' : 'Слова вернутся, когда придёт время'}</small></span>
          {c.due > 0 && <span className="go">Повторить</span>}
        </button>

        <div className="vstats">
          {[['new', 'Новые', '#43c6ff'], ['learning', 'Учу', '#ffb347'], ['mastered', 'Знаю', '#2fe0a3']].map(([k, t, col]) => <div key={k}><b style={{ color: col }}>{c[k]}</b><small>{t}</small></div>)}
        </div>

        <div className="sect">Тренировки</div>
        {DRILLS.map((x) => {
          const n = info?.drills?.[x.kind] ?? 0, ok = n >= need
          return (
            <button key={x.kind} className={`mrow tap ${ok ? '' : 'off'}`} disabled={!ok} onClick={() => { sfx.pop(); onDrill(x.kind) }}>
              <span className="mi" style={{ '--c': x.c }}><Icon name={x.i} size={21} /></span>
              <span className="mt"><b>{x.t}</b><small>{ok ? `${x.s} · ${n} ${plural(n, 'слово', 'слова', 'слов')}` : `Нужно ${need}+ подходящих слов (сейчас ${n})`}</small></span>
              <Icon name={ok ? 'right' : 'lock'} size={18} />
            </button>)
        })}

        <div className="sect">Словарь</div>
        <button className="mrow tap" onClick={() => { sfx.pop(); onVocab() }}><span className="mi" style={{ '--c': '#ffb347' }}><Icon name="book" size={21} /></span><span className="mt"><b>Мой словарь</b><small>{total} {plural(total, 'слово', 'слова', 'слов')} · поиск и озвучка</small></span><Icon name="right" size={18} /></button>
        <button className={`mrow tap ${total >= need ? '' : 'off'}`} disabled={total < need} onClick={() => { sfx.pop(); onFlash() }}><span className="mi" style={{ '--c': '#43c6ff' }}><Icon name="cards" size={21} /></span><span className="mt"><b>Карточки</b><small>Листай и проверяй себя</small></span><Icon name={total >= need ? 'right' : 'lock'} size={18} /></button>

        {wod && (
          <div className="card" style={{ marginTop: 18 }}>
            <div className="row">
              <div style={{ flex: 1 }}>
                <div className="muted" style={{ fontSize: 12, fontWeight: 800 }}>Слово дня · {wod.level}</div>
                <div style={{ fontSize: 24, fontWeight: 900, margin: '4px 0 2px' }} className="grad-text">{wod.en}</div>
                <div style={{ fontWeight: 700 }}>{wod.ru}</div>
                <div className="muted" style={{ fontSize: 13.5, marginTop: 6 }}><i>{wod.phrase}</i></div>
              </div>
              {ttsAvailable && <button className="icon-btn tap" onClick={() => { speak(wod.en, .85); sfx.tap() }} aria-label="Озвучить"><Icon name="volume" size={22} /></button>}
            </div>
          </div>)}
        {total < need && <div className="tip" style={{ marginTop: 14 }}><Icon name="info" size={18} />Тренировки откроются, когда в словаре будет {need}+ слов — пройди первый урок на «Пути».</div>}
      </div>
    </div>
  )
}
