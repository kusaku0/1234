import { useEffect, useState } from 'react'
import { api } from '../api.js'
import { Icon } from '../components/icons.jsx'
import { ErrorBox } from '../components/ui.jsx'

/* ================= РАЗБОР ОШИБОК (1 бесплатно в день) ================= */
export default function Mistakes({ profile, refresh, showPaywall, onBack }) {
  const [data, setData] = useState(null)
  const [used, setUsed] = useState(false)
  const [loading, setLoading] = useState(true)
  const [failed, setFailed] = useState(false)

  useEffect(() => {
    api.post('/api/mistakes/analysis').then((d) => { setData(d); setUsed(d.free_used) })
      .catch((e) => { if (e.status === 402) setUsed(true); else setFailed(true) })
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="skel" style={{ height: 220 }} />

  if (!data && used) {
    return (
      <div>
        <div className="topbar"><button className="icon-btn tap" onClick={onBack} aria-label="Назад"><Icon name="left" size={22} /></button><h2>Разбор ошибок</h2></div>
        <div className="card center" style={{ padding: 26 }}>
          <div style={{ fontSize: 40 }}>🔒</div>
          <h3 style={{ margin: '8px 0 6px' }}>Бесплатный разбор на сегодня использован</h3>
          <p className="muted" style={{ fontSize: 14 }}>Следующий — завтра. С подпиской разборы безлимитные: смотри слабые места после каждого урока.</p>
          <button className="btn gold" style={{ marginTop: 12 }} onClick={showPaywall}>🔓 Открыть безлимит — от 49 ⭐</button>
        </div>
      </div>
    )
  }
  if (!data) return (
    <div>
      <div className="topbar"><button className="icon-btn tap" onClick={onBack} aria-label="Назад"><Icon name="left" size={22} /></button><h2>Разбор ошибок</h2></div>
      <ErrorBox text={failed ? 'Не удалось загрузить разбор. Бесплатная попытка на сегодня не потрачена.' : undefined} onRetry={onBack} />
    </div>)

  const acc = data.accuracy != null ? Math.round(data.accuracy * 100) : 0
  return (
    <div>
      <div className="topbar">
        <button className="icon-btn tap" onClick={onBack} aria-label="Назад"><Icon name="left" size={22} /></button>
        <h2>Разбор ошибок</h2>
        {data.premium && <span className="pill gold">⭐ безлимит</span>}
      </div>

      <div className="card">
        <div className="kv"><span>Ответов всего</span><b>{data.answered}</b></div>
        <div className="kv"><span>Точность</span><b style={{ color: acc >= 80 ? 'var(--mint)' : 'var(--amber)' }}>{acc}%</b></div>
        <div className="kv"><span>Ошибок</span><b>{data.answered - data.correct}</b></div>
      </div>

      {data.by_mode.length > 0 && (
        <div className="card" style={{ marginTop: 10 }}>
          <b style={{ fontSize: 14 }}>По типам заданий</b>
          {data.by_mode.map((m, k) => (
            <div className="kv" key={k}>
              <span>{m.mode}</span>
              <b style={{ color: (m.accuracy ?? 1) < 0.7 ? 'var(--coral)' : 'var(--text)' }}>
                {m.accuracy != null ? Math.round(m.accuracy * 100) + '%' : '—'} <span className="muted" style={{ fontWeight: 400, fontSize: 12 }}>· {m.answered}</span>
              </b>
            </div>
          ))}
        </div>
      )}

      {data.srs && (
        <div className="card" style={{ marginTop: 10 }}>
          <b style={{ fontSize: 14 }}>Память (интервальные повторения)</b>
          <div className="kv"><span>Слов в изучении</span><b>{data.srs.total}</b></div>
          <div className="kv"><span>Выучено (интервал ≥ 21 дня)</span><b style={{ color: 'var(--mint)' }}>{data.srs.mastered}</b></div>
          <div className="kv"><span>Ждут повторения</span><b>{data.srs.due}</b></div>
          {data.srs.leeches > 0 && <div className="kv"><span>🩸 Трудные слова</span><b style={{ color: 'var(--coral)' }}>{data.srs.leeches}</b></div>}
        </div>
      )}

      <div className="card" style={{ marginTop: 10 }}>
        <b style={{ fontSize: 14 }}>Слабые места — повтори их</b>
        {data.weak.length === 0 && <p className="muted" style={{ margin: '8px 0 0', fontSize: 14 }}>Ошибок пока нет — так держать! 🎉</p>}
        <div style={{ display: 'grid', gap: 8, marginTop: 10 }}>
          {data.weak.map((w, k) => (
            <div key={k} className="topic" style={{ alignItems: 'flex-start' }}>
              <div>
                <b>{w.leech ? '🩸 ' : ''}{w.en || '—'}</b>{w.ru && <> — {w.ru}</>}
                <br /><span>{w.phrase ? <i>{w.phrase}</i> : ''} {w.level && `· ${w.level} · ${w.topic}`}</span>
              </div>
              <span className="pill" style={{ background: 'var(--bad-bg)', borderColor: 'var(--coral)', color: 'var(--coral)' }}>×{w.n}</span>
            </div>
          ))}
        </div>
      </div>

      {!data.premium && (
        <div className="card" style={{ marginTop: 10, borderColor: 'rgba(255,179,71,.45)' }}>
          <b>🔓 Разбор без лимита</b>
          <p className="muted" style={{ margin: '6px 0 10px', fontSize: 13.5 }}>Сегодня бесплатный разбор использован. С подпиской — после каждого урока, плюс безлимит заданий.</p>
          <button className="btn" onClick={showPaywall}>От 49 ⭐ за 7 дней</button>
        </div>
      )}
    </div>
  )
}

