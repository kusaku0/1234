import { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { haptic, speak, ttsAvailable } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'
import { ErrorBox, Skel } from '../components/ui.jsx'

const FILTERS = [['all', 'Все'], ['new', 'Новые'], ['learning', 'Учу'], ['mastered', 'Выучены']]
const ST = { new: ['Новое', '#43c6ff'], learning: ['Учу', '#ffb347'], mastered: ['Выучено', '#2fe0a3'] }

/* Словарь: все слова пользователя с картинками, поиск, фильтры, озвучка. */
export function Vocab({ onBack, onFlash }) {
  const [data, setData] = useState(null)
  const [err, setErr] = useState(false)
  const [f, setF] = useState('all')
  const [q, setQ] = useState('')
  useEffect(() => { api.get('/api/vocab').then(setData).catch(() => setErr(true)) }, [])
  const list = useMemo(() => (data?.cards || []).filter((c) => (f === 'all' || c.status === f) && (!q || (c.en + c.ru).toLowerCase().includes(q.toLowerCase()))), [data, f, q])
  return (
    <div>
      <div className="topbar"><button className="icon-btn tap" onClick={onBack} aria-label="Назад"><Icon name="left" size={22} /></button><h2>Мой словарь</h2>
        <button className="icon-btn brand tap" onClick={onFlash} aria-label="Карточки"><Icon name="cards" size={21} /></button></div>
      {err ? <ErrorBox /> : !data ? <Skel h={300} /> : <>
        <div className="search"><Icon name="search" size={19} /><input placeholder="Найти слово…" value={q} onChange={(e) => setQ(e.target.value)} /></div>
        <div className="chip-row">{FILTERS.map(([k, t]) => <button key={k} className={`fchip tap ${f === k ? 'on' : ''}`} onClick={() => { setF(k); sfx.tap() }}>{t}{k !== 'all' && <span style={{ opacity: .75 }}>{data.counts[k]}</span>}</button>)}</div>
        {list.length === 0 && <div className="card center" style={{ padding: 26 }}><Mascot mood="think" size={90} /><p className="muted" style={{ margin: '6px 0 0' }}>{data.cards.length ? 'Ничего не нашлось' : 'Словарь пуст — пройди первый урок, и слова появятся здесь'}</p></div>}
        {list.map((c) => (
          <button key={c.en} className="vrow tap" onClick={() => { if (ttsAvailable) speak(c.en, .85); sfx.tap(); haptic.soft() }}>
            <span className="em">{c.emoji || '✨'}</span>
            <span style={{ flex: 1, minWidth: 0 }}><b>{c.en}</b>{c.leech && ' 🩸'}<small>{c.ru}</small></span>
            <span style={{ textAlign: 'right' }}><span className="qchip" style={{ background: `${ST[c.status][1]}26`, color: ST[c.status][1] }}>{ST[c.status][0]}</span>
              <div className="progress thin" style={{ width: 54, marginTop: 7 }}><i style={{ width: `${Math.max(6, c.strength * 100)}%`, background: ST[c.status][1] }} /></div></span>
          </button>))}
      </>}
    </div>
  )
}

/* Карточки: переворот, «знаю / ещё раз». Локально, без начисления XP. */
export function Flashcards({ onBack }) {
  const [deck, setDeck] = useState(null)
  const [i, setI] = useState(0)
  const [flip, setFlip] = useState(false)
  const [again, setAgain] = useState([])
  const [known, setKnown] = useState(0)
  useEffect(() => {
    api.get('/api/vocab').then((d) => {
      const c = d.cards.filter((x) => x.status !== 'mastered'); const pool = (c.length >= 3 ? c : d.cards)
      setDeck([...pool].sort(() => Math.random() - 0.5).slice(0, 15))
    }).catch(() => setDeck([]))
  }, [])
  if (!deck) return <Skel h={400} />
  if (deck.length === 0) return <div className="card center" style={{ padding: 26 }}><Mascot mood="think" size={100} /><p className="muted">Пока нет слов для карточек</p><button className="btn" onClick={onBack}>Назад</button></div>
  const c = deck[i]
  const fin = i >= deck.length
  const go = (ok) => { sfx[ok ? 'pair' : 'tap'](); haptic.soft(); if (!ok) setAgain((a) => [...a, c]); else setKnown((k) => k + 1); setFlip(false); setTimeout(() => setI((x) => x + 1), 120) }
  return (
    <div>
      <div className="lhead"><button className="icon-btn sm tap" onClick={onBack}><Icon name="x" size={20} /></button><div className="progress"><i style={{ width: `${(i / deck.length) * 100}%` }} /></div><span className="pill" style={{ padding: '6px 11px' }}>{Math.min(i + 1, deck.length)}/{deck.length}</span></div>
      {fin ? (
        <div className="card center fade-up" style={{ padding: 28 }}><Mascot mood="cheer" size={120} float />
          <h2 style={{ margin: '8px 0 4px' }}>Колода пройдена!</h2><p className="muted">Знаешь: {known} · повторить: {again.length}</p>
          {again.length > 0 && <button className="btn" onClick={() => { setDeck(again); setAgain([]); setKnown(0); setI(0) }}>Ещё раз — только трудные</button>}
          <button className="btn ghost" style={{ marginTop: 10 }} onClick={onBack}>Готово</button></div>
      ) : (
        <>
          <div className={`flip ${flip ? 'on' : ''}`} onClick={() => { setFlip(!flip); sfx.flip() }}>
            <div className="flip-in">
              <div className="face"><div className="qemoji">{c.emoji || '✨'}</div><div className="qword">{c.en}</div>
                {ttsAvailable && <button className="sound-btn" onClick={(e) => { e.stopPropagation(); speak(c.en, .85) }}><Icon name="volume" size={24} /></button>}
                <p className="muted" style={{ marginTop: 12, fontSize: 13 }}>Нажми, чтобы перевернуть</p></div>
              <div className="face back"><div className="qword">{c.ru}</div><p style={{ opacity: .92, margin: '10px 8px 0', fontStyle: 'italic' }}>{c.phrase}</p><p style={{ opacity: .75, fontSize: 14, margin: '4px 0 0' }}>{c.phrase_ru}</p></div>
            </div>
          </div>
          <div className="foot"><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
            <button className="btn bad" onClick={() => go(false)}><Icon name="repeat" size={19} />Ещё раз</button>
            <button className="btn ok" onClick={() => go(true)}><Icon name="check" size={20} stroke={3} />Знаю</button></div></div>
        </>)}
    </div>
  )
}
