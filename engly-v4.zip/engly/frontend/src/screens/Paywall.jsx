import { useEffect, useRef, useState } from 'react'
import { api } from '../api.js'
import { haptic } from '../tg.js'
import { sfx } from '../sfx.js'
import { Icon } from '../components/icons.jsx'
import Mascot from '../components/Mascot.jsx'

/* Premium в Engly — это ровно две вещи, и экран говорит только о них:
   1) задания без дневного лимита; 2) разбор ошибок без ограничений. Разовая оплата Stars, без автопродления. */
const benefits = (profile) => [
  ['bolt', 'Без дневного лимита', `Учись сколько хочешь, а не ${profile?.free_limit ?? 12} заданий в день`],
  ['search', 'Разбор ошибок без ограничений', 'Слабые места — после любого урока, а не раз в день'],
  ['repeat', 'Продление не сжигает остаток', 'Новые дни добавляются к тем, что уже оплачены'],
]
const dayWord = (n) => (n % 10 === 1 && n % 100 !== 11 ? 'день' : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 'дня' : 'дней')
const fmtDate = (iso) => { try { return new Date(iso).toLocaleDateString('ru-RU', { day: 'numeric', month: 'long', year: 'numeric' }) } catch { return '' } }

export default function Paywall({ onClose, refresh, reason, profile }) {
  const [plans, setPlans] = useState(null)
  const [sel, setSel] = useState(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [phase, setPhase] = useState('choose')      // choose → confirming → done | slow
  const alive = useRef(true)
  useEffect(() => () => { alive.current = false }, [])

  const load = () => { setError(''); api.get('/api/plans').then((d) => { setPlans(d); setSel(d.best) }).catch(() => setError('Не удалось загрузить тарифы. Проверь соединение.')) }
  useEffect(load, [])

  const price = (p) => (p?.first_price != null ? p.first_price : p?.stars)
  const base = plans?.plans[0]
  const perDay = (p) => price(p) / p.days
  const saving = (p) => (base && p.id !== base.id ? Math.round((1 - perDay(p) / perDay(base)) * 100) : 0)

  /* Telegram сообщает «оплачено» раньше, чем бот получает платёж, поэтому доступ подтверждаем по серверу, а не по ответу окна оплаты */
  const waitForPremium = async (wasUntil) => {
    setPhase('confirming')
    for (let i = 0; i < 12 && alive.current; i++) {
      const p = await refresh?.()
      if (p?.is_premium && p.premium_until !== wasUntil) { haptic.ok(); sfx.done(); setPhase('done'); return }
      await new Promise((r) => setTimeout(r, 1500))
    }
    if (alive.current) setPhase('slow')
  }

  const buy = async () => {
    if (!sel || busy) return
    setBusy(true); setError('')
    try {
      const { link } = await api.post('/api/invoice', { plan: sel })
      const status = await api.openInvoice(link)
      if (status === 'paid') await waitForPremium(profile?.premium_until ?? null)
      else if (status === 'failed') setError('Платёж не прошёл. Звёзды не списаны.')
    } catch (e) { setError(e.status === 0 ? 'Нет связи. Звёзды не списаны.' : 'Не получилось открыть оплату. Попробуй ещё раз.') }
    finally { setBusy(false) }
  }

  const chosen = plans?.plans.find((p) => p.id === sel)
  const active = profile?.is_premium

  return (
    <>
      <div className="backdrop" onClick={phase === 'confirming' ? undefined : onClose} />
      <div className="sheet paywall" role="dialog" aria-modal="true">
        <div className="grab" />
        {phase === 'confirming' && (
          <div className="center" style={{ padding: '24px 0' }}>
            <Mascot mood="think" size={96} float /><h3 style={{ marginTop: 8 }}>Подтверждаем оплату…</h3>
            <p className="muted">Обычно это занимает несколько секунд. Не закрывай окно.</p>
          </div>)}
        {phase === 'done' && (
          <div className="center" style={{ padding: '14px 0' }}>
            <Mascot mood="cheer" size={110} float /><h3 style={{ marginTop: 8 }}>Premium активен</h3>
            <p className="muted">Дневной лимит снят{profile?.premium_until ? ` до ${fmtDate(profile.premium_until)}` : ''}.</p>
            <button className="btn" onClick={onClose}>Продолжить</button>
          </div>)}
        {phase === 'slow' && (
          <div className="center" style={{ padding: '14px 0' }}>
            <Mascot mood="happy" size={96} /><h3 style={{ marginTop: 8 }}>Платёж принят</h3>
            <p className="muted">Доступ откроется в течение минуты — мы пришлём сообщение в чат с ботом. Если этого не случилось, напиши /paysupport.</p>
            <button className="btn ghost" onClick={async () => { await refresh?.(); onClose() }}>Закрыть</button>
          </div>)}
        {phase === 'choose' && (
          <>
            <div className="pw-head">
              <Mascot mood="cheer" size={64} />
              <div>
                <h3>{reason === 'analysis' ? 'Разбор ошибок без ограничений' : 'Engly без дневного лимита'}</h3>
                <p className="muted">{active ? `Сейчас Premium активен до ${fmtDate(profile.premium_until)}. Новые дни добавятся к текущим.` : 'Оплата один раз на выбранный срок. Автопродления нет.'}</p>
              </div>
            </div>
            <ul className="benefits">
              {benefits(profile).map(([i, t, s]) => <li key={t}><span className="bi"><Icon name={i} size={19} /></span><span><b>{t}</b><small>{s}</small></span></li>)}
            </ul>
            {!plans && !error && <div className="skel" style={{ height: 150, margin: '14px 0' }} />}
            {plans && (
              <div className="plans" role="radiogroup" aria-label="Тариф">
                {plans.plans.map((p) => (
                  <button key={p.id} role="radio" aria-checked={sel === p.id} className={`plan tap ${sel === p.id ? 'sel' : ''}`} onClick={() => { setSel(p.id); haptic.tap() }}>
                    {p.id === plans.best && <span className="plan-flag">Выгоднее всего</span>}
                    <span className="plan-d">{p.days}<small>{dayWord(p.days)}</small></span>
                    <span className="plan-p">{p.first_price != null && <s>{p.stars}</s>}{price(p)} <Icon name="star" size={14} fill="currentColor" stroke={1.5} /></span>
                    <span className="plan-s">{perDay(p).toFixed(1)} в день{saving(p) > 0 ? ` · −${saving(p)}%` : ''}</span>
                  </button>))}
              </div>)}
            {plans?.plans.some((p) => p.first_price != null) && <p className="muted center" style={{ fontSize: 13, margin: '8px 0 0' }}>Скидка 20% на первую покупку 30 дней — цена уже учтена.</p>}
            {error && <p className="err" role="alert">{error} {!plans && <button className="btn link" style={{ display: 'inline', padding: 0 }} onClick={load}>Повторить</button>}</p>}
            <button className="btn gold" style={{ marginTop: 14 }} disabled={!sel || busy} onClick={buy}>
              {busy ? 'Открываю оплату…' : chosen ? `${active ? 'Продлить' : 'Оформить'} на ${chosen.days} ${dayWord(chosen.days)} · ${price(chosen)} ⭐` : 'Выбери тариф'}
            </button>
            <button className="btn link" onClick={onClose}>Не сейчас</button>
            <p className="muted center fine">Оплата Telegram Stars. Вопросы и возврат — команда /paysupport в боте.</p>
          </>)}
      </div>
    </>
  )
}
