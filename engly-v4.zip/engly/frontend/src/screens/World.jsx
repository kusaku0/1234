import { useEffect, useMemo, useState } from 'react'
import { api } from '../api.js'
import { haptic } from '../tg.js'
import { sfx } from '../sfx.js'
import Globe from '../components/Globe.jsx'
import { Icon } from '../components/icons.jsx'
import TopBar from '../components/TopBar.jsx'
import { ErrorBox, Skel } from '../components/ui.jsx'

const Stars = ({ n }) => <span style={{ display: 'inline-flex', gap: 2, color: '#ffc03a' }}>{[0, 1, 2].map((k) => <Icon key={k} name="star" size={15} fill={k < n ? 'currentColor' : 'none'} stroke={2} style={{ opacity: k < n ? 1 : .35 }} />)}</span>
const grad = (l) => `linear-gradient(145deg, ${l.theme.a}, ${l.theme.b})`

/* «Мир»: глобус и 10 локаций-диалогов. A1/A2 открываются после тем пути — новичка не бросают в диалог без слов. */
export default function World({ profile, theme, sound, toggleSound, onFly }) {
  const [data, setData] = useState(null)
  const [err, setErr] = useState(false)
  const [sel, setSel] = useState(null)
  const load = () => { setErr(false); api.get('/api/locations').then((d) => { setData(d); setSel((s) => s || d.recommended || d.locations[0].id) }).catch(() => setErr(true)) }
  useEffect(load, [])
  const pins = useMemo(() => (data?.locations || []).map((l) => ({ id: l.id, lat: l.lat, lon: l.lon, emoji: l.emoji, label: l.city, locked: !l.unlocked, done: l.runs > 0, pulse: l.id === data.recommended, selected: l.id === sel })), [data, sel])
  const cur = data?.locations.find((l) => l.id === sel)
  return (
    <div>
      <TopBar profile={profile} theme={theme} sound={sound} toggleSound={toggleSound} sub="путешествуй и говори" />
      {err ? <ErrorBox onRetry={load} /> : !data ? <Skel h={420} /> : (
        <div className="stagger">
          <div className="globe-wrap">
            <Globe pins={pins} height={310} focus={cur} onPinClick={(id) => { setSel(id); sfx.pop(); haptic.tap() }} />
            <div className="globe-hint">Крути глобус · нажми на метку</div>
          </div>
          {cur && (
            <div className="loc-card fade-up" key={cur.id} style={{ marginTop: 12, background: grad(cur) }}>
              <div className="props">{cur.props.map((p, i) => <span key={i} style={{ right: `${6 + i * 22}%`, top: `${8 + (i % 2) * 38}%`, animationDelay: `${i * .8}s` }}>{p}</span>)}</div>
              <span className="lvl-badge">{cur.level}</span><span style={{ fontSize: 13, fontWeight: 700, opacity: .95 }}>{cur.city} · {cur.country}</span>
              <h3 style={{ margin: '8px 0 4px' }}>{cur.emoji} {cur.title}</h3>
              <p style={{ margin: 0, fontSize: 14, opacity: .95 }}>{cur.goal}</p>
              {cur.runs > 0 && <div style={{ marginTop: 8, fontSize: 13.5, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}><Stars n={cur.stars} />пройдено {cur.runs}×</div>}
              <button className={`btn ${cur.unlocked ? 'gold' : 'lockcta'}`} style={{ marginTop: 14 }} disabled={!cur.unlocked} onClick={() => onFly(cur)}>
                {cur.unlocked ? <><Icon name="plane" size={19} />{cur.runs ? 'Лететь снова' : 'Лететь'}</> : <><Icon name="lock" size={18} />{cur.lock_hint}</>}
              </button>
            </div>)}
          <h3 style={{ margin: '22px 2px 4px' }}>Все локации</h3>
          {data.locations.map((l) => (
            <button key={l.id} className={`loc-row tap ${l.unlocked ? '' : 'locked'} ${l.id === sel ? 'sel' : ''}`} onClick={() => { setSel(l.id); sfx.tap(); window.scrollTo({ top: 0, behavior: 'smooth' }) }}>
              <span className="loc-em" style={{ background: l.unlocked ? grad(l) : 'var(--track)' }}>{l.unlocked ? l.emoji : <Icon name="lock" size={22} />}</span>
              <span style={{ flex: 1 }}><b>{l.city}</b> <span className="lvl-badge dk">{l.level}</span><br /><span className="muted" style={{ fontSize: 13 }}>{l.unlocked ? l.title : l.lock_hint}</span></span>
              {l.runs > 0 && <Stars n={l.stars} />}
            </button>))}
        </div>)}
    </div>
  )
}
