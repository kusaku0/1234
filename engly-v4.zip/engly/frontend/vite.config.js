import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: '/engly/',
  server: {
    proxy: { '/api': 'http://localhost:8002' },
  },
})
